--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,mesh)
	mesh=mesh or {}
	mesh.oven=oven
	
	mesh.modname=M.modname

	local cake=oven.cake
	local opts=oven	.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
		
	local gui=oven.rebake(oven.modname..".gui")
	local main=oven.rebake(oven.modname..".main")
	local poly=oven.rebake(oven.modname..".main_poly")

	
	local geom=oven.rebake("wetgenes.gamecake.spew.geom")
	local geom_dae=oven.rebake("wetgenes.gamecake.spew.geom_dae")

	
	mesh.setup=function()
	
		mesh.geoms={geom.icosahedron():build_normals():flip():adjust_scale(128)}
		
--		mesh.geoms[1]:mask_select_all_verts()

		return mesh
	end


	mesh.draw=function()

--		gl.Enable(gl.DEPTH_TEST)
--		gl.Enable(gl.CULL_FACE)
		gl.state.set({
			[gl.CULL_FACE]					=	gl.TRUE,
			[gl.DEPTH_TEST]					=	gl.TRUE,
		})
		gl.Color(1,1,1,1)

		for i,v in ipairs(mesh.geoms) do

--			gl.Enable(gl.POLYGON_OFFSET_FILL);
--			gl.PolygonOffset(1.0,-1.0);
			gl.state.set({
				[gl.POLYGON_OFFSET_FILL]					=	gl.TRUE,
				[gl.POLYGON_OFFSET_FACTOR]		=	1.0,
				[gl.POLYGON_OFFSET_UNITS]		=	-1.0,
			})
   			gl.Color(1,1,1,1)
			v:draw_flatpolys("xyz_normal_light",function(p)
				gl.Uniform3f( p:uniform("light_normal"), poly.light[1],poly.light[2],poly.light[3] )
				gl.Uniform4f( p:uniform("light_color"), 1,1,1,0.25 )
			end)
--			gl.Disable(gl.POLYGON_OFFSET_FILL);
			gl.state.set({
				[gl.POLYGON_OFFSET_FILL]					=	gl.FALSE,
			})

			gl.Color(0,0,0,0.5)
			v:draw_lines("xyz",function(p)end)

		end

		gl.Disable(gl.DEPTH_TEST)
		gl.Disable(gl.CULL_FACE)

		gl.Color(1,1,0,1)
		for i,v in ipairs(mesh.geoms) do
			if v:mask_count_polys()>0 then
				v:draw_polys_mask("xyz_mask",function(p)end)
			end
			if v:mask_count_lines()>0 then
				v:draw_lines_mask("xyz_mask",function(p)end)
			end
			if v:mask_count_verts()>0 then
				v:draw_verts_mask("xyz_mask",function(p)end)
			end
		end

	end

	return mesh
end
