--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")

	local gui=oven.rebake(oven.modname..".gui")
	local main=oven.rebake(oven.modname..".main")
	local poly=oven.rebake(oven.modname..".main_poly")
	
	local mkeys=oven.rebake("wetgenes.gamecake.mods.keys")

gui.infos={

	{
		id="zoom",
		user="in",
		help="Zoom in",
		key=">",
	},

	{
		id="zoom",
		user="out",
		help="Zoom out",
		key=">",
	},

	{
		id="zoom",
		user="all",
		help="Zoom to fit all geometry",
		key="?",
	},
}

gui.lookup={
}

for i,v in ipairs(gui.infos) do
	if v.user then
		gui.lookup[v.id]=gui.lookup[v.id] or {}
		gui.lookup[v.id][v.user]=v
	else
		gui.lookup[v.id]=v
	end
end

gui.lookup_keys={
}
for i,v in ipairs(gui.infos) do
	if v.key then
		gui.lookup_keys[v.key]=v
	end
end

gui.get_list=function(name)		
	local ret=gui.data and gui.data[name] and gui.data[name]:value() 
	if ret then ret=gui.data[name].list[ret] end
	if ret then ret=ret.str end
	return ret
end
				
gui.data_refresh=function()
	if not gui.data then return end
end

gui.data_setup=function()
	if not gui.data then
		gui.data={}
		
		if oven.console then
			oven.console.data.data=gui.data -- put here for easy console access to data
		end
		
		gui.data.set=function(data,v)
			data[v.id]=v
		end

		gui.data:set(wdata.new_data({id="zoom_idx",class="number",hooks=gui.hooks,num=0,min=-8,max=8,tostring=function(dat,num) return tostring(math.floor(num*10)/10) end}))

-- refresh all data values and ranges, this will not trigger value changed messages
		
	end
end




function gui.hooks(act,w,dat)

	if not gui.active then return end

--print(act)

	if act=="active" then
		if w.id=="view" then
			poly.view_drag=w
		end
	end

	if act=="value" then
	end
--print(act)
	if act=="active" or ( act=="over" and w.master.press ) then
		if w.id=="popmenu" or w.id=="topmenu" then
			local px,py=w:get_master_xy(0,w.hy)
			gui.popmenu(w,{
				px=px,
				py=py,
			})
		end
	end
	
	if act=="over" then
		gui.over=w
		gui.infomode="over"
		
		if w.id=="infobar" then
			local t=w.master.ids.menubar
			if t then
				t.hidden=false
				t.hide_when_not_over=true
				gui.master:layout()
			end
		end

	end

	if act=="update" then
	end

	if act=="click" then
		if w.id then
			if     w.id=="quit" then
				oven.next=true
			elseif w.id=="about" then
				oven.next=oven.rebake(gui.about or "wetgenes.gamecake.spew.about.sinescroll")
			elseif w.id=="mouse1" then -- change mouse1 mode
				poly.mouse1=w.user
				gui.fixbuts()
			elseif w.id=="edit" then -- change edit mode
				poly.edit=w.user
				gui.fixbuts()
			end
		end
	end
end

function gui.fixbuts()
	if not gui.active then return end

	gui.master:call_descendents(function(w)	
		if w.id=="mouse1" then
			if poly.mouse1==w.user then w.state="selected" else w.state="none" end
		elseif w.id=="edit" then
			if poly.edit==w.user then w.state="selected" else w.state="none" end
		elseif w.id=="edit_count" then
			local s
			if poly.edit=="verts" then
				s="#"..poly.mask_count_verts()
			elseif poly.edit=="lines" then
				s="#"..poly.mask_count_lines()
			elseif poly.edit=="polys" then
				s="#"..poly.mask_count_polys()
			end
			if s and w.text~=s then
				w.text=s
				w:set_dirty()
			end
		end
	end)

end

gui.msg=function(m)
	
	if not gui.master.focus then -- ignore keys when typing into an input box

		if m.class=="key" then
			if m.action==1 then
				if m.keyname=="space" then
				end
			end
			if m.action==-1 then
				if m.keyname=="space" then
				elseif m.keyname=="tab" then
				end
			end
		end
		
		if m.class=="key" and m.action==1 then
		
			local it=gui.lookup_keys[m.ascii]
			if it then
				gui.hooks("click",it)
				return -- handled
			end
		end
		
		do
			if gui.active then
				gui.master:msg(m)
				if m.class=="mouse" then
					if gui.master.over~=gui.master then return true end
					if gui.master.focus then return true end -- a text input has focus
				end
			end
			return
		end
	end
end

	return gui
end
