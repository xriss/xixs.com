--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,gui)
	local gui=gui or {}
	gui.oven=oven
	
	gui.modname=M.modname

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")

--	local gui=oven.rebake(oven.modname..".gui")
	local main=oven.rebake(oven.modname..".main")
	local poly=oven.rebake(oven.modname..".main_poly")

	local mkeys=oven.rebake("wetgenes.gamecake.mods.keys")

	gui.master=oven.rebake("wetgenes.gamecake.widgets").setup({font="Vera"})

	require(oven.modname..".gui_data").fill(gui)
	require(oven.modname..".gui_page").fill(gui)

	local swversion=oven.opts.version.." "..(oven.opts.bake and oven.opts.bake.smell or ""):upper()
	local about=oven.rebake("wetgenes.gamecake.spew.about.sinescroll")
	about.title="Swanky Poly ( "..swversion.." ) "
	about.text=[[
*SKIP*
**WARNING** This is an Alpha build and may be borken...
*SKIP*
]]


gui.loads=function()
	oven.rebake("wetgenes.gamecake.widgets").loads()
end

gui.setup=function()

	gui.loads()

	gui.infomode="hello"
	gui.infostring=""

	gui.showkeys=false

	gui.base_idx=0

	gui.mx=0
	gui.my=0

	gui.scale=1
	gui.size_x=128
	gui.size_y=128
	
	gui.slide=0
	gui.active=false

	gui.data_setup()

	gui.page("base")
	gui.side_page("tools")
	gui.top_page("bar")
	
	gui.active=true
	gui.fixbuts()
	gui.data_refresh()
	
	return gui
end

gui.clean=function()

end

gui.update=function()

	if gui.side_page_next then
		gui.side_page( gui.side_page_next )
		gui.side_page_next=nil
	end

	gui.master:update({hx=oven.win.width,hy=oven.win.height})

--[[
	local w=gui.master.ids and gui.master.ids["quicksave"]
	if w then
		if images.is_modified() then
			w.color=0xffffcccc
		else
			w.color=0xffccffcc
		end
	end
]]
	local w=gui.master.ids and gui.master.ids["infobar"]
	if w then
		local s=w.text
		if gui.infomode=="mouse" then
			s=string.format("%3dx %3dy %3dz",poly.xyz[1],poly.xyz[2],poly.xyz[3])
		end
		w.text=s
		w:set_dirty()
	end
	
--	gui.update_thumb()
end

gui.draw=function()

	if not gui.active and gui.slide==0 then return end

	oven.gl.PushMatrix()
	gui.master:draw()		
	oven.gl.PopMatrix()

end


function gui.side_page(pname)
	local w=gui.master.ids["pages_side"]
	w:clean_all()
	if pname then
		local f=gui.side_pages[pname]
		if f then
			f(w) -- pass in the master so we could fill up other widgets
		end
	end
	gui.master:layout()
	gui.fixbuts()
	gui.master.focus=nil
end

function gui.top_page(pname)
	local w=gui.master.ids["pages_top"]
	w:clean_all()
	if pname then
		local f=gui.top_pages[pname]
		if f then
			f(w) -- pass in the master so we could fill up other widgets
		end
	end
	gui.master:layout()
	gui.fixbuts()
	gui.master.focus=nil
end

function gui.page(pname)
	local ret=false
	local w=gui.master
	w:clean_all()
	if pname then
		local f=gui.pages[pname]
		if f then
			f(w) -- pass in the master so we could fill up other widgets
			ret=true
--			gui.active=true
		end
	else
--		gui.active=false
	end

	w:layout()
	gui.fixbuts()
	gui.master.focus=nil
	
	return ret
end


	return gui
end
