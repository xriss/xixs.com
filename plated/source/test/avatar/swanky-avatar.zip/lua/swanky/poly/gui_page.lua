--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")

	local gui=oven.rebake(oven.modname..".gui")
	local main=oven.rebake(oven.modname..".main")
	local poly=oven.rebake(oven.modname..".main_poly")
	
	local mkeys=oven.rebake("wetgenes.gamecake.mods.keys")

	local swversion=oven.opts.version.." "..(oven.opts.bake and oven.opts.bake.smell or ""):upper()


gui.pages={}
gui.side_pages={}
gui.top_pages={}


gui.pages.base=function(master)

	local ID=function(id) return gui.master.ids[id] end

	local w=master:add({id="pages_base",size="full",class="split",split_axis="x",split_fit={1,1},split_fmax=1/8})

	master:add({id="pages_menu",class="menu",color=0xffaaaaaa,style="flat",skin=1,solid=true,highlight="none" })


	w:add({class="panel",panel_mode="scale"}):add({id="pages_side",hx=128,hy=1024,text_size=16,color=0xffaaaaaa,class="fill",fbo=true,smode="topleft",style="flat",skin=1,solid=true,highlight="none"})
	w:add({class="split",split_axis="y",split_fmax=1/8,split_fit={1,1}})

	w[2]:add({class="panel",panel_mode="scale"}):add({id="pages_top",hx=1024,hy=32,text_size=16,color=0xffaaaaaa,class="fill",fbo=nil,smode="topleft",style="flat",skin=1,solid=true,highlight="none"})
	w[2]:add({class="split",split_axis="y",split_fnum=1/2})

	w[2][2]:add({class="split",split_axis="x",split_fnum=1/2})
	w[2][2]:add({class="split",split_axis="x",split_fnum=1/2})

	w[2][2][1]:add({id="view",user="xz",hz=1,style="flat",skin=1,solid=true,color=0xff262626,fbo=true,fbo_fov=0,highlight="none",draw=poly.drawview,hooks=gui.hooks})
	w[2][2][1]:add({id="view",user="pp",hz=1,style="flat",skin=1,solid=true,color=0xff222222,fbo=true,fbo_fov=nil,highlight="none",draw=poly.drawview,hooks=gui.hooks})

	w[2][2][2]:add({id="view",user="xy",hz=1,style="flat",skin=1,solid=true,color=0xff222222,fbo=true,fbo_fov=0,highlight="none",draw=poly.drawview,hooks=gui.hooks})
	w[2][2][2]:add({id="view",user="zy",hz=1,style="flat",skin=1,solid=true,color=0xff262626,fbo=true,fbo_fov=0,highlight="none",draw=poly.drawview,hooks=gui.hooks})

	gui.view_widgets={
		w[2][2][1][1],
		w[2][2][1][2],
		w[2][2][2][1],
		w[2][2][2][2],
	}
	
	for i,v in ipairs(gui.view_widgets) do
--		v.fbo_batch_draw_disable=true
	end
	
-- auto add the draging button as a child
	do
		local p=w[2][2]
		local t=p:add({style="button",class="drag",hx=16,hy=16,color=0xff888888,solid=true})
		t.drag_data={}
		local dd=t.drag_data

		w.master.timehooks[p]=0 -- schedule a p.timedelay callback next frame

		p.update=function(w)
		
			if dd.px and dd.hx and p.hx>0 and p.hy>0 then

				if dd.hx~=p.hx or dd.hy~=p.hy then

					t.px=(p.hx*(t.px+(t.hx/2))/dd.hx)-(t.hx/2)
					t.py=(p.hy*(t.py+(t.hx/2))/dd.hy)-(t.hy/2)
					if t.px<0 then t.px=0 end
					if t.py<0 then t.py=0 end
					dd.px=t.px
					dd.py=t.py

					dd.hx=p.hx
					dd.hy=p.hy

					w.master.timehooks[p]=0 -- schedule a p.timedelay callback next frame

				end

			end

			return w.meta.update(w)
		end

		p.class_hooks=function(h,w)
			if h=="timedelay" then

				if not dd.px or not dd.hx then
					if p.hx>0 and p.hy>0 then
					
						t.px=p[2][2].px-(t.hx/2)
						t.py=p[2].py-(t.hy/2)

						dd.px=t.px
						dd.py=t.py

						dd.hx=p.hx
						dd.hy=p.hy

					end
				end
				
				w.master:layout()
				for i,v in ipairs(gui.view_widgets) do v:set_dirty() end
				t:set_dirty()
				return true
			end
		end
		
		t.update=function(w)

			if dd.px and dd.hx then

				if dd.px~=t.px or dd.py~=t.py then -- draged
				
					if p.hx>0 and p.hy>0 then

						local fy=(t.py+(t.hy/2))/(p.hy)
						local fx=(t.px+(t.hx/2))/(p.hx)
						
						if fx<0 then fx=0 end
						if fx>1 then fx=1 end
						if fy<0 then fy=0 end
						if fy>1 then fy=1 end
						
						p.split_fnum=fy
						p[1].split_fnum=fx
						p[2].split_fnum=fx

						dd.px=t.px
						dd.py=t.py


					end

					w.master.timehooks[p]=0 -- schedule a p.timedelay callback next frame
					
				end

			end

			return w.meta.update(w)
		end
	end
	
end



gui.side_pages.tools=function(top)

	top.hx=64*2
	top.hy=64*12
	
	local top=top:add({hx=top.hx,hy=top.hy,class="fill",text_size=16})

--	top:add_border({hx=64,hy=64,px=4,py=4,color=0xffcccccc,text="Menu",id="page",user="menu",hooks=gui.hooks})

	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,solid=true,text="Verts",id="edit",user="verts",hooks=gui.hooks})
	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,solid=true,text="Lines",id="edit",user="lines",hooks=gui.hooks})
	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,solid=true,text="Polys",id="edit",user="polys",hooks=gui.hooks})

	top:add({hx=128,hy=32,text="0",id="edit_count",hooks=gui.hooks})

	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,solid=true,text="Pan",id="mouse1",user="pan",hooks=gui.hooks})
--	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,solid=true,text="Light",id="mouse1",user="light",hooks=gui.hooks})
	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,solid=true,text="Select",id="mouse1",user="select",hooks=gui.hooks})
	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,solid=true,text="Box",id="mouse1",user="box",hooks=gui.hooks})
	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,solid=true,text="Move",id="mouse1",user="move",hooks=gui.hooks})
	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,solid=true,text="Rotate",id="mouse1",user="rotate",hooks=gui.hooks})
	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,solid=true,text="Scale",id="mouse1",user="scale",hooks=gui.hooks})

--[[

	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,text="Move",id="mode",user="select",hooks=gui.hooks})
	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,text="Scale",id="mode",user="select",hooks=gui.hooks})
	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,text="Rotate",id="mode",user="select",hooks=gui.hooks})
	
	top:add_border({hx=64,hy=64,px=4,py=4,color=0xffcccccc,text="Menu",id="page",user="menu",hooks=gui.hooks})

	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,text="Poly",id="pmode",user="poly",hooks=gui.hooks})
	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,text="Edge",id="pmode",user="edge",hooks=gui.hooks})
	top:add_border({hx=128,hy=32,px=4,py=4,color=0xffcccccc,text="Point",id="pmode",user="point",hooks=gui.hooks})
]]

end

gui.top_pages.bar=function(top)

	top.hx=128*8
	top.hy=32*1

	top:add({hx=top.hx-64,hy=32,color=0xffcccccc,style="flat",text="Welcome to Swanky Poly ( "..swversion.." )",id="infobar",skin=1,text_size=24,hooks=gui.hooks})
	top:add({hx=64,hy=32,color=0xffccffcc,style="button",id="quicksave",skin=1,text_size=24,text="Save",hooks=gui.hooks})

--	gui.master.ids.infobar:add({hx=top.hx-64,hy=32,class="menubar",color=0xffaaaaaa,style="flat",highlight="none",id="menubar",skin=1,text_size=24})
--	gui.setmenu()

end

gui.side_pages.hide=function(top)
	top.hx=1
	top.hy=1024
end

gui.side_pages.menu=function(top)

	top.hx=64*2
	top.hy=64*12
	local top=top:add({hx=top.hx,hy=top.hy,class="fill",text_size=16})

	top:add_border({hx=64,hy=64,px=4,py=4,color=0xffcccccc,text="Tools"	,hooks=gui.hooks,id="page",user="tools"})

end

	return gui
end
