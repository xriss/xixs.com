--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local _,lfs=pcall( function() return require("lfs") end ) ; lfs=_ and lfs
local wjson=require("wetgenes.json")

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local bitsynth=require("wetgenes.gamecake.fun.bitsynth")

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")
	local widgets_menuitem=oven.rebake("wetgenes.gamecake.widgets.menuitem")

--	gui.pages=gui.pages or {}

	gui.plan_windows=function(master)	
		master=master or gui.master

		local gsiz=master.grid_size or 24

		local def_window=function(parent,it)
			for n,v in pairs{
				class="window",
				hx=128,
				hy=128,
				px=0,
				py=0,
				solid=true,
			} do it[n]=it[n] or v end
			
			return parent.windows:add(it)
		end

		local def_title=function(parent,it)
			for n,v in pairs{
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
--				color=0,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local def_button=function(parent,it)
			for n,v in pairs{
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
				solid=true,
				hooks=gui.hooks,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local def_menudrop=function(parent,it)
			for n,v in pairs{
				class="menudrop",
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		local def_xslide=function(parent,it)
			for n,v in pairs{
				class="slide",
				hooks=gui.hooks,
				datx=it.data,
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end
		
		local def_texteditor=function(parent,it)
			for n,v in pairs{
				class="texteditor",
				hooks=gui.hooks,
				hx=gsiz*16,
				hy=gsiz*12,
				px=0,
				py=0,
				color=0,
			} do it[n]=it[n] or v end
			return parent:add(it)
		end
		
		local def_tree=function(parent,it)
			for n,v in pairs{
				class="treefile",
				size="full",
				hooks=gui.hooks,
				hx=gsiz*16,
				hy=gsiz*12,
				px=0,
				py=0,
				color=0,
			} do it[n]=it[n] or v end
			return parent:add(it)
		end
		

		gui.screen=gui.master:add({size="full",class="screen",id="screen",solid=true})

		local split=gui.screen:add({class="split",size="full",split_axis="y"})
		local top=split:add({size="fullx fity",fbo=true,style="flat",highlight="none",color=0})
--		local bot=split:add({style="flat",highlight="none",color=0})

		local bot=split:add({class="split",split_axis="x"})
		local left=bot:add({size="fully",hx=200,style="flat",highlight="none",color=0})
		local right=bot:add({style="flat",highlight="none",color=0})

-- build an invisible dragbar so we can drag to resize left and right
		do
			local dragbar=bot:add({style="button",class="drag",px=200-4,hx=8,size="fully",solid=true,cursor="sizewe"})
			local clampit=function()
				if gui.screen.hx < left.hx*2 then
					left.hx=math.ceil(gui.screen.hx/2)
					dragbar.px=left.hx-4
					bot.master.request_layout=true -- need layout
				end
			end
			dragbar.class_hooks=function(h,w)
				if h=="slide" then
					left.hx=dragbar.px+4
					clampit()
				end
			end
			local resize_old=left.resize -- cached upvalue
			left.resize=function(widget) -- super custom layout
				clampit()
				resize_old(widget)
			end
		end
		
		
		local topbar=top:add({size="minmax",smode="topleft",hx_min=gsiz*60,hy_max=gsiz*1,class="fill"})
		local three=topbar:add({hx=gsiz*30,hy=gsiz*1,class="three"})
		local menu =three:add({hx=gsiz*4,hy=gsiz*1,class="menubar",id="menubar",always_draw=true})
		local title=three:add({hx=gsiz*1,hy=gsiz*1,text="Welcome to swanky text",id="infobar",solid=true})
		local buttons=topbar:add({px=0,py=0,hx=gsiz*30,hy=gsiz*1,class="fill",id="infobar_part2"})


		gui.menu_datas={
			font_size={
				{id="font_size",user=1.00,text="Font Size 16px"},
				{id="font_size",user=1.25,text="Font Size 20px"},
				{id="font_size",user=1.50,text="Font Size 24px"},
				{id="font_size",user=1.75,text="Font Size 28px"},
				{id="font_size",user=2.00,text="Font Size 32px"},
			},
		}

		widgets_menuitem.menu_add(menu,{top=menu,menu_data={
			menu_px=0,menu_py=1,
	--		func_text=func_text,
			hooks=gui.hooks,
			inherit=true,

			{id="topmenu",text="File",top_only=true,menu_data={
				{id="load",user="load",text="Load"},
				{id="save",user="save",text="Save"},
				{id="quit",user="quit",text="Quit"},
			}},
			{id="topmenu",text="Windows",top_only=true,menu_data={
				{id="dialog",user="1",text="Dialogue 1"},
			}},
			{id="topmenu",text="Font",top_only=true,menu_data=gui.menu_datas.font_size},
		}})

--[[
		def_title(buttons,{hx=gsiz*6,text="bar2"})
		def_title(buttons,{hx=gsiz*6,text="test"})
]]


-- add super resize hook
		do
			local resize_old=top.resize
			top.resize=function(widget) -- super custom layout
				if gui.screen.hx < gsiz*30 then
--print("double bar")
					topbar.hx_min=gsiz*30
					topbar.hy_max=gsiz*2
				else
--print("single bar")
					topbar.hx_min=gsiz*60
					topbar.hy_max=gsiz*1
				end
				resize_old(widget)
			end
		end


		gui.font_size=1.25
		gui.texteditor=def_texteditor(right,{id="text",hx=gsiz*24,hy=gsiz*16,color=0,fbo=true,
		hook_resize=function(it)
			local ss=gui.font_size
			it.smode="topleft"
			it.hx=it.parent.hx/ss
			it.hy=it.parent.hy/ss
			it.sx=ss
			it.sy=ss
		end})

		gui.treefile=def_tree(left,{id="treefile",color=0,fbo=true})

--		local canvas=def_window(gui.screen,{px=gsiz*4,py=gsiz*4,hx=gsiz*8,hy=gsiz*8,size="fit",id="window_test",title="test",panel_mode="fill"}).win_canvas


--		bot:insert(gui.screen.windows)

		gui.screen:windows_reset()





	end

	return gui
end
