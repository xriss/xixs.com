--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local wgrd   =require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")

local wzips=require("wetgenes.zips")


local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,uvmap)
	local uvmap=uvmap or {}
	uvmap.oven=oven
	
	uvmap.modname=M.modname

--do return uvmap end

	local cake=oven.cake
	local win=oven.win
	local opts=oven.opts
	local canvas=cake.canvas
	local images=cake.images
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	local framebuffers=cake.framebuffers

	local main=oven.rebake(oven.modname..".main")
	local gui=oven.rebake(oven.modname..".gui")
	local textures=oven.rebake(oven.modname..".textures")
	
	local geom_dae=oven.rebake("wetgenes.gamecake.spew.geom_dae")
	local geom=oven.rebake("wetgenes.gamecake.spew.geom")

uvmap.loads=function()

	local filename="lua/"..(oven.modname..".uvmap"):gsub("%.","/")..".glsl"
	gl.shader_sources( wzips.readfile(filename) , filename )

end

uvmap.setup=function()
	uvmap.loads()
	
	uvmap.radius=0
--	uvmap.change("art/dae/carwrap.dae")
end

uvmap.clean=function()
end

uvmap.change=function(name)
	print("loading uvmap object "..name)
	
	uvmap.geoms=geom_dae.load({filename=name})
--	uvmap.geoms:call("build_tangents")
--	uvmap.geoms:call("flipaxis",2)
--	for i,v in ipairs(uvmap.geoms) do v:flipaxis(2) end
	
	uvmap.radius=0
	
	for i,v in ipairs(uvmap.geoms) do
		local r=geom.max_radius(v)
		if r>uvmap.radius then uvmap.radius=r end
	end
	
end

uvmap.draw=function(view,a)
end


	return uvmap
end
