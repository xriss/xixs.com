--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local wgrd   =require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")
local wzips=require("wetgenes.zips")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,bloom)
	local bloom=bloom or {}
	bloom.oven=oven
	
	bloom.modname=M.modname

--do return bloom end

	local cake=oven.cake
	local win=oven.win
	local opts=oven.opts
	local canvas=cake.canvas
	local images=cake.images
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	local framebuffers=cake.framebuffers
	local views=cake.views

	local main=oven.rebake(oven.modname..".main")
	local gui=oven.rebake(oven.modname..".gui")
	


bloom.loads=function()

	local filename="lua/"..(oven.modname..".bloom"):gsub("%.","/")..".glsl"
	gl.shader_sources( wzips.readfile(filename) , filename )

end

bloom.setup=function()
	bloom.loads()
	bloom.fbos={}
	bloom.fbos[1]=framebuffers.create(0,0,0)
	bloom.fbos[2]=framebuffers.create(0,0,0)
end

bloom.clean=function()
	for i,v in ipairs(bloom.fbos) do
		v:clean()
	end
end

bloom.set_size=function(w,h)
	local hack=gui.get_list("hack")

	if bloom.fbos[1].w ~= w or bloom.fbos[1].h ~= h then
		bloom.fbos[1]:resize(w,h, hack=="qube" and 1 or 0)
		bloom.fbos[2]:resize(w,h,0)
	end

end

-- get fbo to draw into, you can mask and apply colors into this one
bloom.get_input_fbo=function()
	return bloom.fbos[1]
end
-- get fbo result, draw the texture as an adative overlay to apply to the view
bloom.get_output_fbo=function()
	return bloom.fbos[1]
end

-- perform a blur to the input fbo, after this you may grab the outpub fbo and draw it
bloom.process=function()

	local fbos=bloom.fbos

	bloom.set_size(fbos[2].w , fbos[2].h)

	fbos[2]:bind_frame()
	cake.views.push_and_apply_fbo(fbos[2])

	local data={
		-1,	-1,		0,		0,			0,
		 1,	-1,		0,		fbos[2].uvw,	0,
		-1,	 1,		0,		0,			fbos[2].uvh,
		 1,	 1,		0,		fbos[2].uvw,	fbos[2].uvh,
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p
	p=gl.program("swpaint_bloom1")
	gl.UseProgram( p[0] )

	local vertexarray
	if gl.BindVertexArray then
		vertexarray=gl.GenVertexArray()
		gl.BindVertexArray(vertexarray)
	end

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE0)
	fbos[1]:bind_texture()

	gl.Uniform4f( p:uniform("pix_siz"), fbos[2].uvw/fbos[2].w,0,0,gui.data.bloom:value() )
	
	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)


	fbos[1]:bind_frame()
	fbos[2]:bind_texture()
	gl.Uniform4f( p:uniform("pix_siz"), 0,fbos[2].uvh/fbos[2].h,0,gui.data.bloom:value() )
	gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)

	if gl.BindVertexArray then
		gl.BindVertexArray(0)
		gl.DeleteVertexArray(vertexarray)
	end


	fbos[1].bind_frame() -- restore old frame
	cake.views.pop_and_apply()
end


	return bloom
end
