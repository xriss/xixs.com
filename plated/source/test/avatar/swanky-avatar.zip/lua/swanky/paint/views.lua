--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local wgrd   =require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")


local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,views)
	local views=views or {}
	views.oven=oven
	
	views.modname=M.modname

	local cake=oven.cake
	local win=oven.win
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")

	local gui=oven.rebake(oven.modname..".gui")

	local paint=oven.rebake(oven.modname..".main_paint")
	local images=oven.rebake(oven.modname..".images")


views.loads=function()

end
		
views.setup=function()

	views.loads()
	
	views[1]={}
	require(oven.modname..".view").bake(oven,views[1])	
	views[1].setup(1)

	views[2]={}
	require(oven.modname..".view").bake(oven,views[2])
	views[2].setup(2)
--	views[2].grid=0
--	views[2].scale=2

	return views
end

views.clean=function()
--[[
	for i,v in ipairs(views) do
		v.clean()
		views[i]=nil
	end
]]
end

views.msg=function(m)

	if views.grabmouse then -- first view only
		local v=views[1]
		v.msg(m)
	else
		for i=#views,1,-1 do local v=views[i]
			if v.msg(m) then break end
		end
	end

end

views.update=function()

	local img=images.get()
	local g=img.grd

--	local lw,lh=img.grd.layers.size()
	local _,_,_,lw,lh,_=img.grd.layers:area()


	local view=views[1]

	local xmin=-math.floor((view.csiz[1]/view.scalex)/2)
	local xmax= math.floor((view.csiz[1]/view.scalex)/2)
	local ymin=-math.floor((view.csiz[2]/view.scaley)/2)
	local ymax= math.floor((view.csiz[2]/view.scaley)/2)
	
	if xmin > -lw/2 then xmin=-lw/2 end
	if xmax <  lw/2 then xmax= lw/2 end
	if ymin > -lh/2 then ymin=-lh/2 end
	if ymax <  lh/2 then ymax= lh/2 end

	local fx=gui.data.focus_x:value()
	local fy=gui.data.focus_y:value()
	if fx<xmin then gui.data.focus_x:value(xmin) end
	if fx>xmax then gui.data.focus_x:value(xmax) end
	if fy<ymin then gui.data.focus_y:value(ymin) end
	if fy>ymax then gui.data.focus_y:value(ymax) end


	local hack=gui.get_list("hack")
	
	for i=1,2 do local v=views[i]
		if v.scale<=0 or i==2 then v.scale=1 end
		if v.scale>1 then v.grid=gui.data.grid:value() else v.grid=0 end
		
		v.scalex=gui.data.fatpix:value()*v.scale
		v.scaley=gui.data.fatpiy:value()*v.scale
	end

	local v=views[1]
--	v.pos[1]=math.floor(paint.area.x)
--	v.pos[2]=math.floor(paint.area.y)
--	v.siz[1]=math.floor(paint.area.w)
--	v.siz[2]=math.floor(paint.area.h)

	v.pos[1]=gui.screen.px -- 0
	v.pos[2]=gui.screen.py -- 0
	v.siz[1]=gui.screen.hx -- math.floor(paint.area.w)+math.floor(paint.area.x)
	v.siz[2]=gui.screen.hy -- math.floor(paint.area.h)+math.floor(paint.area.y)

	if hack=="qube" then
		v.hack="slice"
	end

	local v=views[2]
	local img=images.get()
	if v then
		if hack=="qube" then
			v.siz[1]=math.floor(paint.area.w/2)
			v.siz[2]=math.floor(paint.area.h/2)
			
			if v.siz[1] < v.siz[2] then v.siz[2]=v.siz[1] end
			if v.siz[2] < v.siz[1] then v.siz[1]=v.siz[2] end
			
			v.pos[1]=math.floor(paint.area.x+paint.area.w-v.siz[1])
			v.pos[2]=math.floor(paint.area.y+paint.area.h-v.siz[2])
			v.hack=hack
		else

			local win=gui.get_list("win")

			v.hack=nil
			
			if win=="top_left" or win=="left" or win=="bottom_left" then
				v.siz[1]=math.floor(paint.area.w*gui.data.winx:value())
			end
			if win=="top" or win=="bottom" then
				v.siz[1]=math.floor(paint.area.w)
			end
			if win=="top_right" or win=="right" or win=="bottom_right" then
				v.siz[1]=math.floor(paint.area.w*(1-gui.data.winx:value()))
			end

			if win=="top_left" or win=="top" or win=="top_right" then
				v.siz[2]=math.floor(paint.area.h*gui.data.winy:value())
			end
			if win=="left" or win=="right" then
				v.siz[2]=math.floor(paint.area.h)
			end
			if win=="bottom_left" or win=="bottom" or win=="bottom_right" then
				v.siz[2]=math.floor(paint.area.h*(1-gui.data.winy:value()))
			end
			
			if (views[1].scale<=1 and (gui.data.uvmap_active:value()==0)) or win=="none" then
				v.siz[1]=0
				v.siz[2]=0
				gui.size_knob.hidden=true
			else
				if gui.size_knob.hidden then
					gui.size_knob.hidden=false
					gui.size_knob:set_fxy(gui.data.winx:get_pos(1,0),gui.data.winy:get_pos(1,0))
					gui.master:layout()
				end
			end
			
--[[
			if img then
				if v.siz[1] > img.grd.width*gui.data.fatpix:value()  then v.siz[1]=img.grd.width*gui.data.fatpix:value()  end
				if v.siz[2] > img.grd.height*gui.data.fatpiy:value() then v.siz[2]=img.grd.height*gui.data.fatpiy:value() end
			end
]]

			if win=="top_left" or win=="left" or win=="bottom_left" then
				v.pos[1]=math.floor(paint.area.x)
			end
			if win=="top" or win=="bottom" then
				v.pos[1]=math.floor(paint.area.x+((paint.area.w-v.siz[1])/2))
			end
			if win=="top_right" or win=="right" or win=="bottom_right" then
				v.pos[1]=math.floor(paint.area.x+paint.area.w-v.siz[1])
			end

			if win=="top_left" or win=="top" or win=="top_right" then
				v.pos[2]=math.floor(paint.area.y)
			end
			if win=="left" or win=="right" then
				v.pos[2]=math.floor(paint.area.y+((paint.area.h-v.siz[2])/2))
			end
			if win=="bottom_left" or win=="bottom" or win=="bottom_right" then
				v.pos[2]=math.floor(paint.area.y+paint.area.h-v.siz[2])
			end

--			v.pos[1]=math.floor(paint.area.x+paint.area.w-v.siz[1])
--			v.pos[2]=math.floor(paint.area.y+paint.area.h-v.siz[2])
		end
	end
	v.csiz[1]=v.siz[1]
	v.csiz[2]=v.siz[2]

	local v=views[1]

--	v.csiz[1]=v.siz[1]-views[2].siz[1]
--	v.csiz[2]=v.siz[2]-views[2].siz[2]
	v.csiz[1]=v.siz[1]
	v.csiz[2]=v.siz[2]
	
	for i,v in ipairs(views) do
		v.update()
	end

end

views.draw=function()

	for i,v in ipairs(views) do
		v.draw()
	end
	
end

	return views
end
