--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local lfs ; pcall( function() lfs=require("lfs") end ) -- may not have a filesystem
local wjson=require("wetgenes.json")

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local bitsynth=require("wetgenes.gamecake.fun.bitsynth")

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")
	local widgets_menuitem=oven.rebake("wetgenes.gamecake.widgets.menuitem")

--	gui.pages=gui.pages or {}

	gui.def_windows=function(master)
		master=master or gui.master

		local gsiz=master.grid_size or 24
		
		local def={}

		def.window=function(parent,it)
			for n,v in pairs{
				class="window",
				hx=128,
				hy=128,
				px=0,
				py=0,
				solid=true,
			} do it[n]=it[n] or v end
			
			return parent.windows:add(it)
		end

		def.title=function(parent,it)
			for n,v in pairs{
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
--				color=0,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		def.button=function(parent,it)
			for n,v in pairs{
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
				solid=true,
				hooks=gui.hooks,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		def.menudrop=function(parent,it)
			for n,v in pairs{
				class="menudrop",
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		def.xslide=function(parent,it)
			for n,v in pairs{
				class="slide",
				hooks=gui.hooks,
				datx=it.data,
				hx=gsiz*5,
				hy=gsiz,
				px=2,
				py=2,
				color=0,
			} do it[n]=it[n] or v end
			return parent:add_border(it)
		end

		def.quad=function(parent,it)
			for n,v in pairs{
				class="quad",
				hooks=gui.hooks,
				datx=it.datx,
				daty=it.daty,
				data=it.data,
				hx=gsiz*16,
				hy=gsiz*16,
				px=0,
				py=0,
				color=0,
			} do it[n]=it[n] or v end
			return parent:add(it)
		end

		return def
	end


	gui.plan_windows=function(master)	
		master=master or gui.master

		local gsiz=master.grid_size or 24
		
		local def=gui.def_windows(master)

		local screen=gui.master:add({size="full",class="screen",id="screen",solid=true})

		local split=screen:add({class="split",size="full",split_axis="y"})
		local top=split:add({size="fullx fity",fbo=true,style="flat",highlight="none",color=0})
		split:insert(screen.windows)

		local topbar=top:add({size="minmax",smode="topleft",hx_min=gsiz*60,hy_max=gsiz*1,class="fill"})
		local three=topbar:add({hx=gsiz*30,hy=gsiz*1,class="three"})
		local menu =three:add({hx=gsiz*4,hy=gsiz*1,class="menubar",id="menubar",always_draw=true})
		local title=three:add({hx=gsiz*1,hy=gsiz*1,text="Welcome to swanky test",id="infobar",solid=true})
		local buttons=topbar:add({px=0,py=0,hx=gsiz*30,hy=gsiz*1,class="fill",id="infobar_part2"})

		widgets_menuitem.menu_add(menu,{top=menu,menu_data={
			menu_px=0,menu_py=1,
	--		func_text=func_text,
			hooks=gui.hooks,
			{id="topmenu",text="~",menu_data=function() return screen:screen_menu() end},
			{id="topmenu",text="File",menu_data={
				{id="quit",user="quit",text="Quit"},
			}},
			{id="topmenu",text="Windows",menu_data=function() return screen:window_menu() end},
		}})

		def.title(buttons,{hx=gsiz*6,text="bar2"})
		def.title(buttons,{hx=gsiz*6,text="test"})


-- add super resize hook
		screen.hook_resize=function(widget) -- change when the screen resizes
			if screen.hx < gsiz*30 then
--print("double bar")
				topbar.hx_min=gsiz*30
				topbar.hy_max=gsiz*2
			else
--print("single bar")
				topbar.hx_min=gsiz*60
				topbar.hy_max=gsiz*1
			end
			topbar:set_dirty() 
		end


		local canvas=def.window(screen,{px=gsiz*1,py=gsiz*1,hx=gsiz*16,size="fit",id="window_slide",title="Slide"}).win_canvas

		def.title(canvas,{hx=gsiz*6,text="MenuDrop"})
		def.menudrop(canvas,{hx=gsiz*5,data=gui.datas.get("list_wave")})
		def.menudrop(canvas,{hx=gsiz*5,data=gui.datas.get("list_wave")})

		def.title(canvas,{hx=gsiz*6,text="1"})
		def.xslide(canvas,{hx=gsiz*10,data=gui.datas.get("number_1")})

		def.title(canvas,{hx=gsiz*6,text="1step"})
		def.xslide(canvas,{hx=gsiz*10,data=gui.datas.get("number_1step")})

		def.title(canvas,{hx=gsiz*6,text="100"})
		def.xslide(canvas,{hx=gsiz*10,data=gui.datas.get("number_100")})

		def.title(canvas,{hx=gsiz*6,text="pow"})
		def.xslide(canvas,{hx=gsiz*10,data=gui.datas.get("number_pow")})


		local canvas=def.window(screen,{px=gsiz*2,py=gsiz*2,hx=gsiz*16,hy=gsiz*16,panel_mode="fill",id="window_resize_quad",title="Resize Quad"}).win_canvas
		canvas.size=nil -- stop resizing

		local quad=def.quad(canvas,{size="full"})
		quad[1]:add{size="full",color=0x22ff0000}
		quad[2]:add{size="full",color=0x2200ff00}
		quad[3]:add{size="full",color=0x220000ff}
		quad[4]:add{size="full",color=0x22ffff00}
		quad[5].color=0xff000000

--		def.title(canvas,{hx=gsiz*6,text="1"})
--		def.xslide(canvas,{hx=gsiz*10,data=gui.datas.get("number_1")})

		screen:windows_reset()

	end

	return gui
end
