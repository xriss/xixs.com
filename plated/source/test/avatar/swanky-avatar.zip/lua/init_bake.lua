{
["smell"]="thin",
["version"]=20.738,
["stamp"]=1601238853,
}
