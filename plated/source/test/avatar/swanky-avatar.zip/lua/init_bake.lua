{
["smell"]="thin",
["version"]=20.727,
["stamp"]=1600881949,
}
