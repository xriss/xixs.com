{
["smell"]="thin",
["version"]=20.861,
["stamp"]=1605131860,
}
