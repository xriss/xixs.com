{
["smell"]="thin",
["version"]=20.81,
["stamp"]=1603503997,
}
