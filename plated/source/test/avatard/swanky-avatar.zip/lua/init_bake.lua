{
["smell"]="thin",
["version"]=20.85,
["stamp"]=1604765686,
}
