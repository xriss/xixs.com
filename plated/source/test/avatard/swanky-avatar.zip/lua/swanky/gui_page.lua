--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local _,lfs=pcall( function() return require("lfs") end )

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")
	local wmenuitem=oven.rebake("wetgenes.gamecake.widgets.menuitem")

	gui.pages=gui.pages or {}

	gui.pages.test=function(master)

		gui.master:add({size="fullx",hy=24,class="menubar",color=0xffaaaaaa,style="flat",highlight="none",id="menubar",skin=1,text_size=16,always_draw=true})

		gui.setmenu()

	end

	gui.top_menu_data={
		menu_px=0,menu_py=1,
--		func_text=func_text,
		hooks=gui.hooks,
		{id="topmenu",text="Panel",menu_data={
			{id="page",user="tools",text="Tools"},
			{id="page",user="prefs",text="Prefs"},
			{id="page",user="new",text="New"},
			{id="page",user="load",text="Load"},
			{id="page",user="save",text="Save"},
			{id="page",user="export",text="Export"},
			{id="page",user="edit_colors",text="Palette Editor"},
			{id="page",user="colors",text="Palette"},
			{id="page",user="paint",text="Paint"},
			{id="page",user="quit",text="Quit"},
		}},
		{id="topmenu",text="Panel"},
		{id="topmenu",text="Panel"},
		{id="topmenu",text="Panel"},
		{id="topmenu",text="Panel"},
		{id="topmenu",text="Panel"},
		{id="topmenu",text="Panel"},
		{id="topmenu",text="Panel"},
		{id="topmenu",text="Panel"},
		{id="topmenu",text="Panel"},
		{id="topmenu",text="Panel"},
		{id="topmenu",text="Panel"},
	}
	gui.setmenu=function(d,opts)
		opts=opts or {}
		d=d or gui.top_menu_data
		
		local top=gui.master.ids.menubar
		top:clean_all()

		top.menu_px=0
		top.menu_py=0
		
		wmenuitem.menu_add(top,{top=top,menu_data=d,text_size=16})

		top.px=opts.px or 0
		top.py=opts.py or 0
		
		gui.master:layout()
		gui.fixbuts()
		gui.master.focus=nil

	end

	function gui.page(pname)
	--	pname=pname or "base"
		local ret=false

		gui.master:clean_all()
		
		if pname then
			local f=gui.pages[pname]
			if f then
				f(gui.master) -- pass in the master so we could fill up other widgets
				ret=true
			end
		else
		end

		gui.master:layout()

		gui.fixbuts()
		gui.master.focus=nil
		
		return ret
	end

	return gui
end
