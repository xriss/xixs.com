--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local wgrd   =require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")


local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,images)
	local images=images or {}
	images.oven=oven
	
	images.modname=M.modname

	local cake=oven.cake
	local win=oven.win
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")

	local textures=oven.rebake(oven.modname..".textures")
	local gui=oven.rebake(oven.modname..".gui")
--	local main=oven.rebake(oven.modname..".main")
	local paint=oven.rebake(oven.modname..".main_paint")
--	local gfile=oven.rebake("swanky.gui_file")

images.swanky32_colors={
	0x00,0x00,0x00,0x00,
	0x33,0x66,0x22,0xff,
	0x44,0x88,0x22,0xff,
	0x66,0xaa,0x33,0xff,
	0x66,0xbb,0x77,0xff,
	0x66,0xcc,0xcc,0xff,
	0x55,0x99,0xcc,0xff,
	0x55,0x77,0xcc,0xff,
	0x44,0x55,0x99,0xff,
	0x33,0x33,0x66,0xff,
	0x33,0x22,0x44,0xff,
	0x44,0x22,0x33,0xff,
	0x66,0x33,0x33,0xff,
	0x88,0x44,0x33,0xff,
	0xbb,0x77,0x66,0xff,
	0xee,0xaa,0x99,0xff,
	0xee,0x88,0xbb,0xff,
	0xdd,0x66,0x66,0xff,
	0xcc,0x33,0x33,0xff,
	0xdd,0x55,0x33,0xff,
	0xdd,0x77,0x33,0xff,
	0xdd,0xaa,0x33,0xff,
	0xdd,0xdd,0x44,0xff,
	0x88,0x88,0x33,0xff,
	0x00,0x00,0x00,0xff,
	0x22,0x22,0x22,0xff,
	0x44,0x44,0x44,0xff,
	0x66,0x66,0x66,0xff,
	0x88,0x88,0x88,0xff,
	0xaa,0xaa,0xaa,0xff,
	0xcc,0xcc,0xcc,0xff,
	0xff,0xff,0xff,0xff,
}
images.swanky32_grd=assert(wgrd.create("U8_RGBA",256,1,1))
images.swanky32_grd:pixels(0,0,0,32,1,1,images.swanky32_colors)

images.load_grd=function(filename)
	images[images.idx].get_json_data() -- make sure the current image has a recent json dump
print("load",filename)
	for i,v in ipairs(images) do
		if v.filename==filename then --already loaded just select
			images.select(i)
			return
		end
	end
	images.new_grd()
	images[images.idx].load_grd(filename) -- and load into it
	images.select() -- fixpath

	images[images.idx].set_json_data() -- make sure the gui reflects the images settings

end

images.get_filename=function()
	return images[images.idx].filename
end

images.save_grd=function(...)
	images[images.idx].get_json_data() -- make sure the image has a recent json dump
	return images[images.idx].save_grd(...)
end

images.export_grd=function(...)
	return images[images.idx].export_grd(...)
end

images.resize=function(w,h,d)
	local image=images.get()
	image.resize(w,h,d)
	images.select()
end

images.relayer=function(x,y,count)
	local image=images.get()
	image.layers_config({x=x,y=y,count=count})
	images.select()
end


images.new_grd=function(...)
	local repme
	for i,v in ipairs(images) do
		if type(v.modified)=="string" and v.modified=="repme" then repme=repme or i end -- can replace this one
	end
	if repme then
		images.select(repme) -- replace the splashscreen
	else
		images.select(images.create()) -- make a new image
	end
	images[images.idx].new_grd(...)
	images.select() -- update settings
end

images.is_modified=function()
	if type(images[images.idx].modified)=="boolean" and images[images.idx].modified==true then
		return true
	else
		return false
	end
end

images.set_modified=function(b)
	images[images.idx].modified=b
end

images.loads=function()

end

images.make_spare=function()
	images.spare_idx=images.create(0)
	local image=images[images.spare_idx]
	image.spare=true
	image.filename="spare.png"
end

images.get_spare=function()
	if not images.spare_idx then images.make_spare() end
	local image=images[images.spare_idx]
	return image
end

images.get=function(n)
	return images[n or images.idx]
end

images.select_next=function()
	local idx=images.idx+1
	if idx>#images then idx=0 end
	if not images[idx] then idx=idx+1 end -- skip spare if not there
	images.select(idx)
end
images.select_prev=function()
	local idx=images.idx-1
	if not images[idx] then idx=idx-1 end -- skip spare if not there
	if idx<0 then idx=#images end
	images.select(idx)
end

-- swap too or from the spare image
images.select_spare=function(gotospare,copypixels)

	if type(gotospare)=="boolean" then -- requesting a forced jump to spare or from spare
		if gotospare then -- we want to goto spare
			if images.idx==images.spare_idx then return end -- already on spare so nothing to do
		else -- we want to return from spare
			if images.idx~=images.spare_idx then return end -- already not on spare so nothing to do
		end
	end
	
-- if we got past the above function then we need to jump to swap to or from the spare
	
	if images.spare_idx==images.idx  then -- already on spare

		if images.spare_idx_back then -- we have an image to return to, just switch to it

			images.select(images.spare_idx_back)
			images.spare_idx_back=false

		end

	else -- we want to jump to the spare

		images.spare_idx_back=images.idx -- remember where to return

		local image_spare=images.get_spare()
		local image=images.get()

		local jd=image.get_json_data() --  we need to copy json data across

		image_spare.grd:palette(0,256,image.grd:palette(0,256,"")) -- force copy entire palette

		if image_spare.grd.width<image.grd.width or image_spare.grd.height<image.grd.height then

			local w=image_spare.grd.width
			local h=image_spare.grd.height
			local d=image_spare.grd.depth
			
			if image.grd.width  > w then w=image.grd.width end
			if image.grd.height > h then h=image.grd.height end

			image_spare.resize(w,h,1) -- resize upwards only

--			image_spare.resize(image.grd.width,image.grd.height,1) -- the spare is only ever 1 frame and has a forced resize
		
		end
		
-- at this point spare is at least as large us image so we have space to copy pixels if requested

		if copypixels then -- also copy pixels when swapping to the spare
			local w=image.grd.width
			local h=image.grd.height
			image_spare.grd:pixels(0,0,0,w,h,1,image.grd:pixels(0,0,0,w,h,1,"")) -- force copy frame
-- force removal of all undo history
			image_spare.history:reset()
		end

		images.select(images.spare_idx)
		images.get().set_json_data( jd ) -- copy setting into spare
	end
end

images.select=function(n)
	local oldidx=images.idx
	if n then images.idx=n end
	if not images[images.idx] then images.idx=1 end

-- keep gui synced
	if gui.data then
		if images[0] then gui.data.image_idx.min=0 end --make spare available
		gui.data.image_idx.max=#images -- keep max in sync

		gui.data.image_idx:value(n)
	end

	if images.idx~=oldidx then -- save old and load new
	
		if images[oldidx] then
			images[oldidx].get_json_data()
		end
		
		gui.data_refresh() -- fix data bounds for newly selected image
	
		if images[images.idx] then
			images[images.idx].set_json_data()
		end

	end


	if gui.master and gui.master.ids and gui.master.ids.file_save and images[images.idx].filename then
		gui.master.ids.file_save:path( images[images.idx].filename )
		if gui.master.ids.file_export then
			gui.master.ids.file_export:path( gui.file_name_fix(images[images.idx].filename,"export"))
		end
	end
		


	gui.image_refresh_required=true
	gui.data_refresh_required=true
	gui.widget_refresh_required=true

	gui.set_infostring(images[images.idx].filename) -- display filename as we switch

	return images.get()
end

images.select_layer=function(idx)
	gui.image_refresh_required=true
	local img=images.get()
	local g=img.grd
	if not idx then return img.grd.layers.index,img.grd.layers.count end
	img.grd.layers.index=idx
	if img.grd.layers.index<0       			then img.grd.layers.index=0 end
	if img.grd.layers.index>img.grd.layers.count	then img.grd.layers.index=img.grd.layers.count end
	return img.grd.layers.index , img.grd.layers.count
end

images.select_frame=function(idx)
	gui.image_refresh_required=true
	local img=images.get()
	local g=img.grd
	if not idx then return img.grd.layers.frame+1,g.depth end
	img.grd.layers.frame=idx-1
	if img.grd.layers.frame<0        then img.grd.layers.frame=0 end
	if img.grd.layers.frame>=g.depth then img.grd.layers.frame=g.depth-1 end
end

images.create=function(idx)
	local idx=idx or #images+1
	images[idx]={}
	require(oven.modname..".image").bake(oven,images[idx])
	images[idx].setup()
	return idx
end

images.delete=function(n)
print("delete image")
	if n then images.idx=n end
	if not images[images.idx] then images.idx=1 end

	if images[images.idx] then
		images[images.idx].clean()
		table.remove(images,images.idx)
	end
	
	if #images==0 then
		images.create()
	end
	
	images.select(images.idx)
end

images.setup=function()

	images.loads()
	
	if not images[1] then -- add an images
		images.select(images.create())
	end
	
	return images
end


images.clean=function()
--[[
	for i,v in ipairs(images) do
		v.clean()
		images[i]=nil
	end
]]
end

images.msg=function(m)

end

images.update=function()

	for i,v in ipairs(images) do
		v.update()
	end

end

images.draw=function(t)

	
end

	return images
end
