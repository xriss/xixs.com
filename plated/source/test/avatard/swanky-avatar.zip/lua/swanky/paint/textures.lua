--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local wgrd   =require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")


local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,textures)
	local textures=textures or {}
	textures.oven=oven
	
	textures.modname=M.modname

	local cake=oven.cake
	local win=oven.win
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	

textures.loads=function()
	for i,v in ipairs(textures) do
		v.loads()
	end
end

textures.get=function(n)
	return textures[n or textures.idx]
end

textures.select=function(n)
	if n then textures.idx=n end
	if not textures[textures.idx] then textures.idx=1 end
end

textures.setup=function()

	
	textures[1]={}
	require(oven.modname..".texture").bake(oven,textures[1])
	textures[1].setup()	

	textures.select(1)

	textures.loads()

	return textures
end

textures.clean=function()
--[[
	for i,v in ipairs(textures) do
		v.clean()
		textures[i]=nil
	end
]]
end

textures.msg=function(m)

end

textures.update=function()

	for i,v in ipairs(textures) do
		v.update()
	end

end

textures.draw=function(t)

	
end

	return textures
end
