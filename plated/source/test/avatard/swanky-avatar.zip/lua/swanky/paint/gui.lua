--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,gui)
	local gui=gui or {}
	gui.oven=oven
	
	gui.modname=M.modname

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")

	local gui=oven.rebake(oven.modname..".gui")
	local main=oven.rebake(oven.modname..".main")
	local paint=oven.rebake(oven.modname..".main_paint")
	local images=oven.rebake(oven.modname..".images")
	local textures=oven.rebake(oven.modname..".textures")
	local views=oven.rebake(oven.modname..".views")
--	local gfile=oven.rebake("swanky.gui_file")
	
	local mkeys=oven.rebake("wetgenes.gamecake.mods.keys")

	gui.master=gui.master or oven.rebake("wetgenes.gamecake.widgets").setup({font="FiraSans-Regular",text_size=16,grid_size=32,skin=0})

	require(oven.modname..".gui_data").fill(gui)
	require(oven.modname..".gui_page").fill(gui)
	require(oven.modname..".gui_config").fill(gui)

	gui.swversion=oven.opts.version.." "..(oven.opts.bake.smell or ""):upper()
	local about=oven.rebake("wetgenes.gamecake.spew.about.sinescroll")
	about.title="Swanky Paint ( "..gui.swversion.." ) "
	about.text=[[
*SKIP*
**WARNING** This is an Alpha build and may be borken...
*SKIP*
]]



gui.loads=function()
	oven.rebake("wetgenes.gamecake.widgets").loads()
end


gui.update=function()

	if gui.side_page_next then
		gui.side_page( gui.side_page_next )
		gui.side_page_next=nil
	end

	gui.master:update({hx=oven.win.width,hy=oven.win.height})

	local w=gui.master.ids and gui.master.ids["quicksave"]
	if w then
		if images.is_modified() then
			w.color=0x3fff0000
		else
			w.color=0x3f00ff00
		end
	end
	local w=gui.master.ids and gui.master.ids["infobar"]
	if w then
		local s=w.text
		if gui.infotime>os.time() then -- show this string for a little while
			s=gui.infostring
		elseif gui.infomode=="mouse" then
			local img=images.get()
			s=string.format("%3dx %3dy",paint.x,paint.y)
--			if img.grd.layers.count and img.grd.layers.count > 1 then
--				s=s..string.format(" %3dz",img.grd.layers.index)
--			end
			if paint.inside then
				pcall(function()
					local idx=images.get().layers_grd():pixels(paint.x,paint.y,1,1)[1]
					s=s..string.format(" = $%02x",idx)
					local rgba=images.get().grd:palette(idx,1)
					s=s..string.format(" #%02x%02x%02x%02x",rgba[4],rgba[1],rgba[2],rgba[3])
				end)
			end
--			if images.get().grd.depth > 1 then
--				s=s..string.format(" : frame %d/%d",images.get().frame+1,images.get().grd.depth)
--			end
			s=s.." ("..paint.mode..")"
		elseif gui.infomode=="over" then
			s=""
			local w=gui.over
			if w and w.id then
				local it=gui.lookup[w.id]
				if it and w.user and it[w.user] then it=it[w.user] end
				if it then
					s=it.help or ""
					if it.key then
						if type(it.key)=="table" then
							s=s.." ( "..table.concat(it.key," ").." )"
						elseif it.key then
							s=s.." ("..it.key..")"
						end
					end
				end
			end
--print(gui.over,gui.over.info,s)
		end
		w.text=s
		w:set_dirty()
	end
	
-- display cursor	
	if gui.cursor ~= gui.master.cursor then
		gui.cursor = gui.master.cursor
		wwin.cursor( gui.cursor or "arrow" )
	end

--	gui.update_thumb()
end

gui.draw=function()

	oven.gl.PushMatrix()
	gui.master:draw()		

--	oven.gl.Translate(gui.gui_side.px,gui.gui_side.py,0)
--	oven.gl.Scale(gui.gui_side.sx,gui.gui_side.sy,1)

	oven.gl.PopMatrix()

end


	return gui
end
