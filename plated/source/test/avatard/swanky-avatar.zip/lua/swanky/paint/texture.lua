--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local wgrd   =require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")
local wzips=require("wetgenes.zips")


local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,texture)
	local texture=texture or {}
	texture.oven=oven
	
	texture.modname=M.modname

	local cake=oven.cake
	local win=oven.win
	local opts=oven.opts
	local canvas=cake.canvas
	local images=cake.images
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets

-- GLES needs luminance but this is depreciated so we need to hack this
	local GL_LUMINANCE=gl.LUMINANCE
	if gl.BindVertexArray then GL_LUMINANCE=0x1903 end

	local main=oven.rebake(oven.modname..".main")
	local gui=oven.rebake(oven.modname..".gui")

	local paint=oven.rebake(oven.modname..".main_paint")

	local bloom=oven.rebake(oven.modname..".bloom")

	local swimages=oven.rebake(oven.modname..".images")

texture.check_size=function(grd)
	
	if	( texture.width == grd.width and texture.height == grd.height ) and -- new size
		( ( grd.cmap and true or false)  == texture.rgba ) -- or new palette
		then return end -- nothing to fix

	texture.width=grd.width
	texture.height=grd.height
	
	texture.texture_width=images.uptwopow(texture.width)
	texture.texture_height=images.uptwopow(texture.height)

	if grd.cmap then
		texture.rgba=false

		gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
		gl.TexImage2D(
			gl.TEXTURE_2D,
			0,
			gl.RGBA,
			256,
			1,
			0,
			gl.RGBA,
			gl.UNSIGNED_BYTE,
			string.rep(string.char(0), 256 * 1 * 4) ) --blank the texture	


		gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )
		gl.TexImage2D(
			gl.TEXTURE_2D,
			0,
			GL_LUMINANCE,
			texture.texture_width,
			texture.texture_height,
			0,
			GL_LUMINANCE,
			gl.UNSIGNED_BYTE,
			string.rep(string.char(0), texture.texture_width * texture.texture_height) ) --blank the texture

		gl.BindTexture( gl.TEXTURE_2D , texture.norm_id )
		gl.TexImage2D(
			gl.TEXTURE_2D,
			0,
			gl.RGB,
			texture.texture_width,
			texture.texture_height,
			0,
			gl.RGB,
			gl.UNSIGNED_BYTE,
			string.rep(string.char(128,128,255), texture.texture_width * texture.texture_height ) )

		else
		
-- prepare RGBA textures
		texture.rgba=true

		gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
		gl.TexImage2D(
			gl.TEXTURE_2D,
			0,
			gl.RGBA,
			256,
			1,
			0,
			gl.RGBA,
			gl.UNSIGNED_BYTE,
			string.rep(string.char(0), 256 * 1 * 4) ) --blank the texture	

		gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )
		gl.TexImage2D(
			gl.TEXTURE_2D,
			0,
			gl.RGBA,
			texture.texture_width,
			texture.texture_height,
			0,
			gl.RGBA,
			gl.UNSIGNED_BYTE,
			string.rep(string.char(0), texture.texture_width * texture.texture_height * 4 ) ) --blank the texture

	end


end


texture.loads=function()
--	print(wstr.dump(texture.grd))

	texture.width=0
	texture.height=0

	texture.cmap_id=assert(gl.GenTexture())
	texture.bmap_id=assert(gl.GenTexture())
	texture.norm_id=assert(gl.GenTexture())
	
	gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )	
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE)
	
	gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE)
	
	gl.BindTexture( gl.TEXTURE_2D , texture.norm_id )
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE)
	gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE)

	gl.CheckError()

	local filename="lua/"..(oven.modname..".texture"):gsub("%.","/")..".glsl"
	gl.shader_sources( wzips.readfile(filename) , filename )

--	gl.CheckError()

end

texture.upload=function(grd,f)

	texture.check_size(grd)
	
	texture.layers=grd.image and grd.image.grd.layers
	
	local w=gui.master and gui.master.ids and gui.master.ids.process_show
	if w and w.state=="selected" and gui.data and gui.data.attr_redux and gui.data.attr_redux.num<256 then -- perform attr clash
		local image=grd.image
		grd=grd:duplicate()
		grd.image=image
		grd:attr_redux(gui.data.attr_width.num,gui.data.attr_height.num,gui.data.attr_redux.num,gui.data.attr_sub.num,gui.data.attr_back.num)
	end

	f=f or 0
	if f <  0 then f=0 end
	if f >= grd.depth then f=grd.depth-1 end

	if grd.cmap then
	
		texture.rgba=false
	
		gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )
		gl.TexSubImage2D(
			gl.TEXTURE_2D,
			0,
			0,0,
			grd.width,
			grd.height,
			GL_LUMINANCE,
			gl.UNSIGNED_BYTE,
			pack.tolightuserdata( grd.data , grd.width*grd.height*f ) )
			
		gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
		gl.TexSubImage2D(
			gl.TEXTURE_2D,
			0,
			0,0,
			256,
			1,
			gl.RGBA,
			gl.UNSIGNED_BYTE,
			pack.tolightuserdata( grd.cmap , 0 ) )

	else
	
		texture.rgba=true

		gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )
		gl.TexSubImage2D(
			gl.TEXTURE_2D,
			0,
			0,0,
			grd.width,
			grd.height,
			gl.RGBA,
			gl.UNSIGNED_BYTE,
			pack.tolightuserdata( grd.data , grd.width*grd.height*4*f ) )

		gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
		gl.TexSubImage2D(
			gl.TEXTURE_2D,
			0,
			0,0,
			256,
			1,
			gl.RGBA,
			gl.UNSIGNED_BYTE,
			pack.tolightuserdata( swimages.swanky32_grd.data , 0 ) )

	end

	if f==1 and gui.data.uvmap_active:value()>0 then -- convert and upload the normal bumpmap

		local g=grd:clip(0,0,1,grd.width,grd.height,1)
		g=assert(g:create_convert(wgrd.FMT_U8_LUMINANCE))
		g=assert(g:create_normal())
--		g:save("_norm.png")
--		print(g.data)

		gl.BindTexture( gl.TEXTURE_2D , texture.norm_id )
		gl.TexSubImage2D(
			gl.TEXTURE_2D,
			0,
			0,0,
			g.width,
			g.height,
			gl.RGB,
			gl.UNSIGNED_BYTE,
			pack.tolightuserdata( g.data , 0 ) )
		
	end

	gl.Flush()
end

texture.setup=function()

	texture.width=0
	texture.height=0
	

--	texture.loads()
	
	return texture
end

texture.clean=function()

--print("del text")
	gl.DeleteTexture(texture.bmap_id) texture.bmap_id=nil
	gl.DeleteTexture(texture.cmap_id) texture.cmap_id=nil
	gl.DeleteTexture(texture.cmap_id) texture.norm_id=nil

end

texture.msg=function(m)

end


texture.update=function()
end

texture.p_layer=function(p,i)
	i=i or texture.layers and texture.layers.index
	if texture.layers and i~=0 then -- layer 0 is the whole image
		if not i then i=1 end
		if i<1 then i=1 end
		if i>texture.layers.count then i=texture.layers.count end
		local lw,lh=texture.layers:size()
		local lx=lw*math.floor((i-1)%texture.layers.x)
		local ly=lh*math.floor((i-1)/texture.layers.x)
		gl.Uniform4f( p:uniform("img_siz"), lw,lh,texture.texture_width,texture.texture_height )
		gl.Uniform4f( p:uniform("img_off"), lx,ly,0,0 )
	else
		gl.Uniform4f( p:uniform("img_siz"), texture.width,texture.height,texture.texture_width,texture.texture_height )
		gl.Uniform4f( p:uniform("img_off"), 0,0,0,0 )
	end
end

texture.draw=function(view)

	if not view then return end

	local data={
		view.pos[1],				view.pos[2],				0,		0,				0,
		view.pos[1]+view.siz[1],	view.pos[2],				0,		view.siz[1],	0,
		view.pos[1],				view.pos[2]+view.siz[2],	0,		0,				view.siz[2],
		view.pos[1]+view.siz[1],	view.pos[2]+view.siz[2],	0,		view.siz[1],	view.siz[2],
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local s8="8"
	local sopts=""
	if texture.rgba then -- not an indexed image
--		local d=gui.data and gui.data.dither_patterns and gui.data.dither_patterns:value()  or 4
		s8="32"
--		sopts="?DITHER="..d.."&COLORS="..32
	end
	

	local p=gl.program("swpaint_image"..s8..sopts)	
	local e=gui.data and gui.data.escher and gui.data.escher:value() 
	if e then e=gui.data.escher.list[e] end
	if e then
		if     e.str=="pixel" then
			p=gl.program("swpaint_image"..s8..sopts)
		elseif e.str=="scan" then
			p=gl.program("swpaint_image"..s8.."_scan"..sopts)
		elseif e.str=="bleed" then
			p=gl.program("swpaint_image"..s8.."_bleed"..sopts)
		elseif e.str=="escher" then
			p=gl.program("swpaint_image"..s8.."_escher1"..sopts)
		elseif e.str=="trixel" then
			p=gl.program("swpaint_image"..s8.."_escher2"..sopts)
		end
	end

	gl.UseProgram( p[0] )

	local vertexarray
	if gl.BindVertexArray then
		vertexarray=gl.GenVertexArray()
		gl.BindVertexArray(vertexarray)
	end

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE1)
	gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
	gl.ActiveTexture(gl.TEXTURE0)
	gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )

	gl.Uniform1i( p:uniform("tex0"), 0 )
	gl.Uniform1i( p:uniform("tex1"), 1 )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

	gl.Uniform4f( p:uniform("color"), 1,1,1,1 )
	
	gl.Uniform4f( p:uniform("img_pos"), view.offset[1],view.offset[2],view.scalex,view.scaley )
	gl.Uniform4f( p:uniform("img_flags"),view.grid,gui.data.snapx:value(),gui.data.snapy:value(),(main.drawframe%4096)/4096 )
	gl.Uniform4f( p:uniform("img_lines"), view.lines[1],view.lines[2],view.lines[3],view.lines[4] )

	local img_wrap_active=(gui.data and gui.data.wrap_active and gui.data.wrap_active:value() or 0)
	gl.Uniform4f( p:uniform("img_wrap"), img_wrap_active,0,0,0 )
	
	local c=math.abs((main.drawframe%64)-32)/32
	c=((c*c)/2)+0.25
	gl.Uniform4f( p:uniform("img_line_color"), c,c,c,1 )


	local ah=(gui.data and gui.data.dither_adjust_hue and gui.data.dither_adjust_hue:value() or 0)/360
	local as=(gui.data and gui.data.dither_adjust_sat and gui.data.dither_adjust_sat:value() or 0)/100
	local av=(gui.data and gui.data.dither_adjust_val and gui.data.dither_adjust_val:value() or 0)/100
	gl.Uniform3f( p:uniform("adjust_hsv"), ah,as,av )

	local ar=(gui.data and gui.data.dither_adjust_red and gui.data.dither_adjust_red:value() or 0)/100
	local ag=(gui.data and gui.data.dither_adjust_grn and gui.data.dither_adjust_grn:value() or 0)/100
	local ab=(gui.data and gui.data.dither_adjust_blu and gui.data.dither_adjust_blu:value() or 0)/100
	gl.Uniform3f( p:uniform("adjust_rgb"), ar,ag,ab )
	
	if view.export then
		gl.Uniform4f( p:uniform("img_alpha_color"), 0.0,0.0,0.0,1.0 )	
	else
		local br=(gui.data and gui.data.back_r and gui.data.back_r:value() or 0)/100
		local bg=(gui.data and gui.data.back_g and gui.data.back_g:value() or 0)/100
		local bb=(gui.data and gui.data.back_b and gui.data.back_b:value() or 0)/100
		local ba=(gui.data and gui.data.back_a and gui.data.back_a:value() or 0)/100
		gl.Uniform4f( p:uniform("img_alpha_color"), br,bg,bb,ba )
	end


	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	texture.p_layer(p)
	gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)

	if gl.BindVertexArray then
		gl.BindVertexArray(0)
		gl.DeleteVertexArray(vertexarray)
	end

end


texture.build_bloom=function()

	bloom.set_size(texture.width,texture.height)
	local fbo=bloom.get_input_fbo()
	fbo:bind_frame()
	cake.views.push_and_apply_fbo(fbo)

	local data={
		-1,	-1,		0,		0,										0,
		 1,	-1,		0,		texture.width/texture.texture_width,	0,
		-1,	 1,		0,		0,										texture.height/texture.texture_height,
		 1,	 1,		0,		texture.width/texture.texture_width,	texture.height/texture.texture_height,
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p
	local s8="8"
	local sopts=""
	if texture.rgba then -- not an indexed image
--		local d=gui.data and gui.data.dither_patterns and gui.data.dither_patterns:value()  or 4
		s8="32"
--		sopts="?DITHER="..d.."&COLORS="..32
	end
	p=gl.program("swpaint_image"..s8.."_writebloom"..sopts)
	gl.UseProgram( p[0] )

	local vertexarray
	if gl.BindVertexArray then
		vertexarray=gl.GenVertexArray()
		gl.BindVertexArray(vertexarray)
	end

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE1)
	gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
	gl.ActiveTexture(gl.TEXTURE0)
	gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )

	gl.Uniform1i( p:uniform("tex0"), 0 )
	gl.Uniform1i( p:uniform("tex1"), 1 )

--	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
--	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

--	gl.Uniform4f( p:uniform("color"), 1,1,1,1 )

	
	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	local ah=(gui.data and gui.data.dither_adjust_hue and gui.data.dither_adjust_hue:value() or 0)/360
	local as=(gui.data and gui.data.dither_adjust_sat and gui.data.dither_adjust_sat:value() or 0)/100
	local av=(gui.data and gui.data.dither_adjust_val and gui.data.dither_adjust_val:value() or 0)/100
	gl.Uniform3f( p:uniform("adjust_hsv"), ah,as,av )

	local ar=(gui.data and gui.data.dither_adjust_red and gui.data.dither_adjust_red:value() or 0)/100
	local ag=(gui.data and gui.data.dither_adjust_grn and gui.data.dither_adjust_grn:value() or 0)/100
	local ab=(gui.data and gui.data.dither_adjust_blu and gui.data.dither_adjust_blu:value() or 0)/100
	gl.Uniform3f( p:uniform("adjust_rgb"), ar,ag,ab )

	gl.Uniform4f( p:uniform("img_alpha_color"), 0,0,0,1 )
	texture.p_layer(p)
	gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)
	if gl.BindVertexArray then
		gl.BindVertexArray(0)
		gl.DeleteVertexArray(vertexarray)
	end

	fbo.bind_frame() -- restore old frame
	cake.views.pop_and_apply()
	
	bloom.process()
	
end

texture.draw_bloom=function(view)

	if not view then return end

	local fbo=bloom.get_output_fbo()

	local data={
		view.pos[1],				view.pos[2],				0,		0,				0,
		view.pos[1]+view.siz[1],	view.pos[2],				0,		view.siz[1],	0,
		view.pos[1],				view.pos[2]+view.siz[2],	0,		0,				view.siz[2],
		view.pos[1]+view.siz[1],	view.pos[2]+view.siz[2],	0,		view.siz[1],	view.siz[2],
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p
	p=gl.program("swpaint_drawbloom")
	gl.UseProgram( p[0] )

	local vertexarray
	if gl.BindVertexArray then
		vertexarray=gl.GenVertexArray()
		gl.BindVertexArray(vertexarray)
	end

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE0)
	fbo:bind_texture()
	gl.Uniform1i( p:uniform("tex0"), 0 )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

	local t=gui.data.bloom:value()	--/texture.layers.count
	gl.Uniform4f( p:uniform("color"), 0.5*t,0.5*t,0.5*t,0 )
	
	local img_wrap_active=(gui.data and gui.data.wrap_active and gui.data.wrap_active:value() or 0)
	gl.Uniform4f( p:uniform("img_wrap"), img_wrap_active,0,0,0 )

	gl.Uniform4f( p:uniform("img_pos"), view.offset[1],view.offset[2],view.scalex,view.scaley )

	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	gl.Uniform4f( p:uniform("img_alpha_color"), 0,0,0,1 )
	texture.p_layer(p)
	gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)

	if gl.BindVertexArray then
		gl.BindVertexArray(0)
		gl.DeleteVertexArray(vertexarray)
	end

end


texture.draw_qube=function(view)


	if not view then return end
	if not texture.layers then return end

	local lw,lh=texture.layers:size()

	local	qubesize=                                               lw
			qubesize=qubesize>lh                    and qubesize or lh
			qubesize=qubesize>texture.layers.count  and qubesize or texture.layers.count
	
	local fbosize=qubesize*8

	bloom.set_size(fbosize,fbosize)
	local fbo=bloom.get_input_fbo()
	fbo:bind_frame()
	gl.Viewport( 0 , 0 , fbosize , fbosize )


	gl.ClearColor(pack.argb4_pmf4(0xf000))
	gl.Clear(gl.COLOR_BUFFER_BIT+gl.DEPTH_BUFFER_BIT)

	gl.Scale(6,6,6)

	gl.Rotate(paint.x*2,0,1,0);
	gl.Rotate(paint.y*2,1,0,0);
	



	if not texture.vb then
	
		texture.vb=gl.GenBuffer()	-- hack please do this better
		
		local data={
		}
		local p=function(d)
			data[#data+1]=d
		end
		local lw,lh=texture.layers:size()
		for x=0,lw-1 do
			for y=0,lh-1 do
				for z=0,texture.layers.count-1 do
					local xb=lw*math.floor(z%texture.layers.x)
					local yb=lh*math.floor(z/texture.layers.x)
					p(x-(qubesize/2))
					p(y-(qubesize/2))
					p(z-(qubesize/2))
					p((x+xb)/texture.texture_width)
					p((y+yb)/texture.texture_height)
				end
			end
		end

		local datalen=#data
		local datasize=datalen*4 -- we need this much vdat memory
		canvas.vdat_check(datasize) -- make sure we have space in the buffer
		pack.save_array(data,"f32",0,datalen,canvas.vdat)
		
		gl.BindBuffer(gl.ARRAY_BUFFER,texture.vb)
		gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.STATIC_DRAW)
		texture.vb_len=datalen

	end
	
	local p
	local s8="8"
	if texture.rgba then s8="32" end-- not an indexed image
	p=gl.program("swpaint_image"..s8.."_writeqube")
	gl.UseProgram( p[0] )

	local vertexarray
	if gl.BindVertexArray then
		vertexarray=gl.GenVertexArray()
		gl.BindVertexArray(vertexarray)
	end

	gl.BindBuffer(gl.ARRAY_BUFFER,texture.vb)
--	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE1)
	gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
	gl.ActiveTexture(gl.TEXTURE0)
	gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )

	gl.Uniform1i( p:uniform("tex0"), 0 )
	gl.Uniform1i( p:uniform("tex1"), 1 )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )
	
--	gl.Uniform4f( p:uniform("img_siz"), texture.width,texture.height,texture.texture_width,texture.texture_height )
	
	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))
	
--	gl.Enable(gl.DEPTH_TEST)
	gl.state.set({
		[gl.DEPTH_TEST]					=	gl.TRUE,
	})
	gl.DrawArrays(gl.POINTS,0,texture.vb_len)
--	gl.Disable(gl.DEPTH_TEST)
	gl.state.set({
		[gl.DEPTH_TEST]					=	gl.FALSE,
	})

	if gl.BindVertexArray then
		gl.BindVertexArray(0)
		gl.DeleteVertexArray(vertexarray)
	end

	fbo.bind_frame() -- restore old frame
	
--	gl.MatrixMode(gl.PROJECTION)
--	gl.PopMatrix()
--	gl.MatrixMode(gl.MODELVIEW)
--	gl.PopMatrix()

--	bloom.process()


--	local fbo=bloom.get_output_fbo()

	local data={
		view.pos[1],				view.pos[2],				0,		0,				0,
		view.pos[1]+view.siz[1],	view.pos[2],				0,		fbosize,	0,
		view.pos[1],				view.pos[2]+view.siz[2],	0,		0,			fbosize,
		view.pos[1]+view.siz[1],	view.pos[2]+view.siz[2],	0,		fbosize,	fbosize,
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p
	p=gl.program("swpaint_drawbloom")
	gl.UseProgram( p[0] )

	local vertexarray
	if gl.BindVertexArray then
		vertexarray=gl.GenVertexArray()
		gl.BindVertexArray(vertexarray)
	end

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE0)
	fbo:bind_texture()
	gl.Uniform1i( p:uniform("tex0"), 0 )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

	gl.Uniform4f( p:uniform("color"), 1,1,1,1 )

	gl.Uniform4f( p:uniform("img_siz"), fbosize,fbosize,fbosize,fbosize )
	gl.Uniform4f( p:uniform("img_off"), 0,0,0,0 )
	gl.Uniform4f( p:uniform("img_wrap"), 0,0,0,0 )
	
	gl.Uniform4f( p:uniform("img_pos"), 0,0,1,1 )

	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)

	if gl.BindVertexArray then
		gl.BindVertexArray(0)
		gl.DeleteVertexArray(vertexarray)
	end

	bloom.process()


	local fbo=bloom.get_output_fbo()

	local data={
		view.pos[1],				view.pos[2],				0,		0,				0,
		view.pos[1]+view.siz[1],	view.pos[2],				0,		fbosize,	0,
		view.pos[1],				view.pos[2]+view.siz[2],	0,		0,			fbosize,
		view.pos[1]+view.siz[1],	view.pos[2]+view.siz[2],	0,		fbosize,	fbosize,
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p
	p=gl.program("swpaint_drawbloom")
	gl.UseProgram( p[0] )

	local vertexarray
	if gl.BindVertexArray then
		vertexarray=gl.GenVertexArray()
		gl.BindVertexArray(vertexarray)
	end

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.ActiveTexture(gl.TEXTURE0)
	fbo:bind_texture()
	gl.Uniform1i( p:uniform("tex0"), 0 )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

	gl.Uniform4f( p:uniform("color"), 1,1,1,1 )

	gl.Uniform4f( p:uniform("img_siz"), fbosize,fbosize,fbosize,fbosize )
	gl.Uniform4f( p:uniform("img_off"), 0,0,0,0 )
	gl.Uniform4f( p:uniform("img_wrap"), 0,0,0,0 )
	
	gl.Uniform4f( p:uniform("img_pos"), 0,0,1,1 )

	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)
		
	if gl.BindVertexArray then
		gl.BindVertexArray(0)
		gl.DeleteVertexArray(vertexarray)
	end

end


	return texture
end
