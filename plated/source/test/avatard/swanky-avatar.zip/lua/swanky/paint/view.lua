--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local wgrd   =require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")


local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,view)
	local view=view or {}
	view.oven=oven
	
	view.modname=M.modname

	local cake=oven.cake
	local win=oven.win
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")

	local gui=oven.rebake(oven.modname..".gui")
	local views=oven.rebake(oven.modname..".views")
	local images=oven.rebake(oven.modname..".images")
	local paint=oven.rebake(oven.modname..".main_paint")
	local textures=oven.rebake(oven.modname..".textures")
	local trace=oven.rebake(oven.modname..".trace")

	local uvmap=oven.rebake(oven.modname..".uvmap")
	local geom=oven.rebake("wetgenes.gamecake.spew.geom")



view.is_uvmap=function()
	return gui.data.uvmap_active:value()>0 and view.idx>1 and uvmap.geoms
end



view.loads=function()

end
		
view.setup=function(idx)

	view.loads()

	view.idx=idx or 0

--	view.imgid=1
	view.scale=1
	view.scalex=1
	view.scaley=1
	view.grid=1
--	view.focus={0,0}
	view.offset={0,0}
	view.pos={0,0}
	view.siz={128,128}
	view.csiz={128,128}
	
	view.lines={-1,-1,-1,-1}
	
	view.rot={0,0}
	view.posfix={0,0,0}
	view.sizfix=1

end

view.clean=function()

end

view.msg=function(m)


	local img=images.get()

	if m.class=="mouse" then

		if  (	m.x >= view.pos[1] and
				m.y >= view.pos[2] and
				m.x < view.pos[1]+view.siz[1] and
				m.y < view.pos[2]+view.siz[2] ) or view.grab_mouse or ( view==views[1] ) then

			local x=math.floor((m.x-view.pos[1]+view.offset[1])/view.scalex)
			local y=math.floor((m.y-view.pos[2]+view.offset[2])/view.scaley)

--dprint(m)

if view.is_uvmap() then -- grab all mouse msgs

	if m.keyname=="left" and m.action==1 and (not view.grab_mouse) then
		view.grab_mouse={x=x,y=y,mode="left",xraw=m.xraw,yraw=m.yraw}
	end

	if m.keyname=="right" and m.action==1 and (not view.grab_mouse) then
		view.grab_mouse={x=x,y=y,mode="right",xraw=m.xraw,yraw=m.yraw}
	end

	if m.keyname=="wheel_sub" and m.action==-1 then
		view.sizfix=view.sizfix*(31/32)
		return true
	end

	if m.keyname=="wheel_add" and m.action==-1 then
		view.sizfix=view.sizfix/(31/32)
		return true
	end

	if view.grab_mouse and view.grab_mouse.mode=="left" then
		local ps=view.grab_mouse
		local dx=x-ps.x
		local dy=y-ps.y
		if not win:warp_mouse(ps.xraw,ps.yraw) then -- warp back if we can
			ps.x=x
			ps.y=y
		end
		view.rot[1]=view.rot[1]+dx
		view.rot[2]=view.rot[2]-dy

		if m.action==-1 then
			view.grab_mouse=nil
		end

		return true
	end

	if view.grab_mouse and view.grab_mouse.mode=="right" then
		local ps=view.grab_mouse
		local dx=x-ps.x
		local dy=y-ps.y
		if not win:warp_mouse(ps.xraw,ps.yraw) then -- warp back if we can
			ps.x=x
			ps.y=y
		end
		if uvmap.radius>1 then
			view.posfix[1]=view.posfix[1]+dx/100
			view.posfix[2]=view.posfix[2]+dy/100
		end

		if m.action==-1 then
			view.grab_mouse=nil
		end

		return true
	end

end

			
--			if 	x>=0 and
--				y>=0 and
--				x<img.width and
--				y<img.height then
				
				paint.msg_mouse(m,{x=x,y=y,view=view,m=m})
				
				return true -- was for us
--			end
		end
		
	end

end

view.ii=0
view.update=function()

	view.ii=(view.ii+1)%65536

	local img=images.get()
	
--	local lw,lh=img.grd.layers:size()
	local _,_,_,lw,lh,_=img.grd.layers:area()
	local w=lw*view.scalex
	local h=lh*view.scaley

	if view.hack=="qube" then
	else

		local fx=gui.data.focus_x:value()
		local fy=gui.data.focus_y:value()
		view.offset[1]=math.floor( (view.csiz[1]-w) * -0.5 + (( fx*view.scalex)) )
		view.offset[2]=math.floor( (view.csiz[2]-h) * -0.5 + (( fy*view.scaley)) )


		if view==views[1] then -- recenter dependng on 
		
			view.offset[1]=view.offset[1]-math.floor(paint.area.x/2)
			view.offset[2]=view.offset[2]-math.floor(paint.area.y/2)

			local v2=views[2]
			local win=gui.get_list("win")
			
			local ddx=(view.siz[1]-v2.siz[1])*view.siz[2]
			local ddy=view.siz[1]*(view.siz[2]-v2.siz[2])

			if win=="top_left" or win=="left" or win=="bottom_left" then
				if win=="left" or ddx>=ddy then
					view.offset[1]=math.floor(view.offset[1]-v2.siz[1]/2)
				end
			end
			if win=="top" or win=="bottom" then
			end
			if win=="top_right" or win=="right" or win=="bottom_right" then
				if win=="right" or ddx>=ddy then
					view.offset[1]=math.floor(view.offset[1]+v2.siz[1]/2)
				end
			end

			if win=="top_left" or win=="top" or win=="top_right" then
				if win=="top" or ddy>=ddx then
					view.offset[2]=math.floor(view.offset[2]-v2.siz[2]/2)
				end
			end
			if win=="left" or win=="right" then
			end
			if win=="bottom_left" or win=="bottom" or win=="bottom_right" then
				if win=="top" or ddy>=ddx then
					view.offset[2]=math.floor(view.offset[2]+v2.siz[2]/2)
				end
			end
		
		else -- check if we fit in the area given and auto center if we do
		
			if view.csiz[1] > w then view.offset[1]=math.floor( (view.csiz[1]-w) * -0.5) end
			if view.csiz[2] > h then view.offset[2]=math.floor( (view.csiz[2]-h) * -0.5) end
		
		end

		if view.offset[1]<-paint.area.w then view.offset[1]=-paint.area.w end
		if view.offset[1]>w then view.offset[1]=w end
		
		if view.offset[2]<-paint.area.h then view.offset[2]=-paint.area.h end
		if view.offset[2]>h then view.offset[2]=h end
		
	end

end


view.draw=function()

	if view.hack=="qube" then
	
		gl.Color(0,0,0,1)
		flat.quad( view.pos[1]-6 , view.pos[2]-6, view.pos[1]+view.siz[1]+6 , view.pos[2]+view.siz[2]+6 )
		gl.Color(1,1,1,1)

		textures.get().draw_qube(view)

	else

		if view.siz[1]>0 and view.siz[2]>0 then
	--		local g=gui.color_bg
	--		gl.Color(g.r/255,g.g/255,g.b/255,1)
			gl.Color(0,0,0,1)
			flat.quad( view.pos[1]-8 , view.pos[2]-8, view.pos[1]+view.siz[1]+8 , view.pos[2]+view.siz[2]+8 )
			gl.Color(1,1,1,1)
		end
		
		if view.is_uvmap() then

			local texture=textures.get()
			
			gl.PushMatrix()
			
			gl.Translate(view.pos[1]+view.siz[1]*0.5,view.pos[2]+view.siz[2]*0.5,0)
		
			local ss=view.siz[1]/2
			if view.siz[2] < view.siz[1] then
				ss=view.siz[2]/2
			end
			if uvmap.radius>0 then
				ss=ss/uvmap.radius
			end
			
			gl.Scale(view.sizfix*ss,view.sizfix*ss,view.sizfix*ss)
--			gl.Rotate(180,0,0,1)

			gl.Translate(view.posfix[1],view.posfix[2],view.posfix[3])

			gl.Rotate(view.rot[1],0,1,0)
			gl.Rotate(view.rot[2],1,0,0)
			
--			gl.Enable(gl.DEPTH_TEST)
			gl.state.set({
				[gl.DEPTH_TEST]					=	gl.TRUE,
			})
--			gl.Enable(gl.CULL_FACE)

			gl.Color(1,1,1,1)
			for i,v in ipairs(uvmap.geoms) do
				geom.draw(v,"swpaint_uvmap",function(p)

						gl.ActiveTexture(gl.TEXTURE2)
						gl.BindTexture( gl.TEXTURE_2D , texture.norm_id )
						gl.ActiveTexture(gl.TEXTURE1)
						gl.BindTexture( gl.TEXTURE_2D , texture.cmap_id )
						gl.ActiveTexture(gl.TEXTURE0)
						gl.BindTexture( gl.TEXTURE_2D , texture.bmap_id )

						gl.Uniform1i( p:uniform("tex0"), 0 )
						gl.Uniform1i( p:uniform("tex1"), 1 )
						gl.Uniform1i( p:uniform("tex2"), 2 )

						gl.Uniform4f( p:uniform("tex_siz"),
							texture.width/texture.texture_width,
							texture.height/texture.texture_height,
							0,0)
	
						gl.Uniform4f( p:uniform("lighting"),
							gui.data.uvmap_dark:value(),
							gui.data.uvmap_light:value(),
							gui.data.uvmap_bump:value(),
							2)
							
--						local t=textures.get()
--						local w=t.width
--						local h=t.height

						
					end)
					
			end

--			gl.Disable(gl.DEPTH_TEST)
			gl.state.set({
				[gl.DEPTH_TEST]					=	gl.FALSE,
			})
--			gl.Disable(gl.CULL_FACE)
			
			gl.PopMatrix()

		else

			trace.draw_under(view,gui.data.trace_alpha:value()) -- background image and stripes
			
			textures.get().draw(view)

			if gui.data.bloom:value() > 0 then -- add bloom effect
				textures.get().build_bloom()
				textures.get().draw_bloom(view)
			end

			trace.draw_over(view,gui.data.trace_alpha:value()) -- maybe draw background image over the top

			trace.draw_grid(view) -- draw grid and cursor lines over the top
			
		end
		
	end
	
end

	return view
end
