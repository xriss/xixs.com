--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local wstring=wstr
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wgrdpaint=require("wetgenes.grdpaint")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local _,lfs=pcall( function() return require("lfs") end )

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")

	local gui=oven.rebake(oven.modname..".gui")
	local main=oven.rebake(oven.modname..".main")
	local paint=oven.rebake(oven.modname..".main_paint")
	local images=oven.rebake(oven.modname..".images")
	local textures=oven.rebake(oven.modname..".textures")
	local views=oven.rebake(oven.modname..".views")
--	local gfile=oven.rebake("swanky.gui_file")
	local trace=oven.rebake(oven.modname..".trace")
	local uvmap=oven.rebake(oven.modname..".uvmap")
	
	local mkeys=oven.rebake("wetgenes.gamecake.mods.keys")

-- load scraped data from the data dir, allow for adding new files just by putting them in the right dir
	pcall(function() gui.presets=require("swanky.paint.scrape").presets(true) end) -- try a live update
	gui.presets=gui.presets or wzips.readlson("data/presets/scrape.lua") -- or just use the cache


gui.infos={

--[[
	{
		id="page",
		user="trace",
		idx=33,
		help="Load and View a high resolution trace image",
	},

	{
		id="page",
		user="layers",
		idx=34,
		help="Manage layers",
	},

	{
		id="page",
		user="frames",
		idx=35,
		help="Manage frames",
	},

	{
		id="page",
		user="uvmap",
		idx=36,
		help="Load and View a textured uvmapped 3D object",
	},

	{
		id="page",
		user="hide",
		idx=1,
		help="Hide menu panel",
	},
	{
		id="page",
		user="menu",
		idx=1,
		help="Show the main menu panel",
	},
]]
	{
		id="snap",
		idx=2,
		help="Snap drawing tools too a grid",
		key="g",
	},
	{
		id="magnify",
		idx=3,
		help="Zoom into the image",
		key=">",
	},
	{
		id="paint",
		idx=4,
		help="Paint using a custom brush",
		key="B",
	},
--[[
	{
		id="page",
		user="paint",
		idx=29,
		help="Show the paint panel",
	},
]]
	{
		id="paint_circle",
		idx=5,
		help="Paint using a circular brush",
	},
	{
		id="clear",
		idx=6,
		help="Clear the image to the background color",
	},
	{
		id="scroll",
		idx=39,
		help="Enter scroll mode",
	},
	{
		id="pickup",
		idx=8,
		help="Pickup a brush from the image",
		key="b",
	},
	{
		id="paint_dot",
		idx=9,
		help="Paint using a single dot brush",
		key=".",
	},
	{
		id="frame_swap",
		idx=10,
		text="Swap with Spare",
		help="Swap frame with the spare page",
		key="j",
	},
	{
		id="frame_copy",
		idx=10,
		text="Copy to Spare",
		help="Copy frame to the spare page",
		key="J",
	},
	{
		id="redoundo",
		idx=11,
		help="redo/undo the last image change",
		key="u",
	},
	{
		id="undo",
		idx=11,
		help="Undo the last image change",
		key="U",
	},
--[[
	{
		id="page",
		user="edit_colors",
		idx=12,
		help="Show the palette editor panel",
	},
	{
		id="page",
		user="tools",
		idx=13,
		help="Show the tools panel",
	},
	{
		id="page",
		user="file",
		idx=14,
		help="Show the file panel",
	},
	{
		id="page",
		user="prefs",
		idx=15,
		help="Show the preference panel",
	},
	{
		id="page",
		user="colors",
		idx=16,
		help="Show the color panel",
	},
]]
	{
		id="about",
		idx=17,
		help="About Swanky Paint",
	},
	{
		id="paint_line",
		idx=18,
		help="Paint using a vertical line brush",
	},
	{
		id="paint_block",
		idx=20,
		help="Paint using a square brush",
	},
	{
		id="paint_dash",
		idx=21,
		help="Paint using a horizontal line brush",
	},
	{
		id="paint_shrink",
		idx=19,
		help="Shrink the brush by 1 pixel",
		key="-",
	},
	{
		id="paint_grow",
		idx=22,
		help="Grow the brush by 1 pixel",
		key="=",
	},
	{
		id="paint_brush_prev",
		idx=19,
		help="Select previous brush",
		key="_",
	},
	{
		id="paint_brush_next",
		idx=22,
		help="Select next brush",
		key="+",
	},
	{
		id="brushmode",
		user="paint",
		idx=23,
		help="Set paint mode to normal",
		key="f1",
	},
	{
		id="brushmode",
		user="replace",
		idx=24,
		help="Set paint mode to no transparent pixels",
		key="f3",
	},
	{
		id="magnify_right",
		idx=25,
		help="Zoom out of the image",
		key="<",
	},
--[[
	{
		id="page",
		user="new",
		idx=26,
		help="Create a new image",
	},
	{
		id="page",
		user="load",
		idx=27,
		help="Load a new image",
		key="l",
	},
	{
		id="page",
		user="save",
		idx=28,
		help="Save the current image",
		key="s",
	},
	{
		id="page",
		user="export",
		idx=30,
		help="Export the current image",
	},
]]
	{
		id="brushmode",
		user="color",
		idx=31,
		help="Set paint mode to single color mask",
		key="f2",
	},
	{
		id="quicksave",
		help="Quickly save over the current file",
	},
	{
		id="quit",
		text="Quit",
		help="Quit Swanky Paint, all unsaved work will be lost!",
	},

	{
		id="brush_skew",
		text="Skew",
		help="Skew the brush",
	},
	{
		id="brush_square_outline",
		text="Square Outline",
		help="Square Outline the brush",
	},
	{
		id="brush_outline",
		text="Outline",
		help="Outline the brush",
		key="o"
	},
	{
		id="brush_inline",
		text="Inline",
		help="Inline the brush",
		key="O"
	},
	{
		id="brush_flip_x",
		text="Flip X",
		help="Flip the brush horizontally",
		key="x"
	},
	{
		id="brush_flip_y",
		text="Flip Y",
		help="Flip the brush vertically",
		key="y"
	},
	{
		id="brush_half",
		text="Half",
		help="Half the brush size",
		key="h"
	},
	{
		id="brush_double",
		text="Double",
		help="Double the brush size",
		key="H"
	},
	{
		id="brush_double_x",
		text="Double X",
		help="Double the brush size horizontally",
		key="X"
	},
	{
		id="brush_double_y",
		text="Double Y",
		help="Double the brush size vertically",
		key="Y"
	},
	{
		id="brush_rotate",
		text="Rotate",
		help="Rotate the brush clockwise",
		key="z"
	},
	{
		id="brush_remap",
		text="Remap Brush",
		help="Apply the image palette to the brush",
	},
	{
		id="brush_remap_from",
		text="Remap Image",
		help="Apply the brush palette to the image",
	},
	{
		id="brush_pal_from",
		text="Palette from brush",
		help="Copy the brush palette to the image",
	},
	{
		id="bitdown_brush_to_clipboard",
		text="Brush to Clipboard",
		help="Copy the brush to the clipboard as bitdown text",
	},
	{
		id="bitdown_clipboard_to_brush",
		text="Clipboard to Brush",
		help="Copy bitdown text in the clipboard into the brush",
	},
	{
		id="fill",
		idx=32,
		text="Flood fill",
		help="Fill all connecting pixels of the same color with the foreground color",
		key="f"
	},

	{
		id="image_wrap_toggle",
		text="Toggle image wrapping",
		help="Toggle the display OF automatic wrapping at edges of image",
		key={"w"}
	},

	{
		id="frame_add",
		text="Add Frame",
		help="Insert a new frame here copying the current frame",
--		key={"@","\""}
	},
	{
		id="frame_del",
		text="Delete Frame",
		help="Delete this frame",
--		key="!"
	},

	{
		id="layer_add",
		text="Add Layer",
		help="Add a new layer here copying the current layer",
--		key="$"
	},
	{
		id="layer_del",
		text="Delete Layer",
		help="Delere this layer",
--		key="#"
	},

	{
		id="layer_chop",
		text="Chop Layers",
		help="Convert a single image into multiple layers",
--		key=""
	},

	{
		id="layer_rechop",
		text="ReChop Layers",
		help="ReConvert a single image into more or less layers",
--		key=""
	},

	{
		id="layer_join",
		text="Join Layers",
		help="Convert multiple layers into a single image",
--		key=""
	},

	{
		id="layer_flatten",
		text="Flatten Layers",
		help="Merge multiple layers into a single flat image",
--		key=""
	},
	
	{
		id="window",
		user="window_colors",
		idx=12,
		help="Show the palette editor panel",
	},
	{
		id="window",
		user="window_new",
		idx=26,
		help="Create a new image",
	},
	{
		id="window",
		user="window_load",
		idx=27,
		help="Load a new image",
		key="l",
	},
	{
		id="window",
		user="window_save",
		idx=27,
		help="Save the current image",
		key="s",
	},
	{
		id="process_show",
		idx=38,
		help="Auto process current image",
	},

}

gui.lookup={
}

for i,v in ipairs(gui.infos) do
	if v.user then
		gui.lookup[v.id]=gui.lookup[v.id] or {}
		gui.lookup[v.id][v.user]=v
	else
		gui.lookup[v.id]=v
	end
end

gui.lookup_keys={
}
for i,v in ipairs(gui.infos) do
	if v.key then
		local t=(type(v.key)=="table") and v.key or {v.key}
		for _,key in ipairs(t) do
			gui.lookup_keys[key]=v
		end
	end
end

gui.get_list=function(name)		
	local ret=gui.data and gui.data[name] and gui.data[name]:value() 
	if ret then ret=gui.data[name].list[ret] end
	if ret then ret=ret.str end
	return ret
end


gui.numlist=function(s)
	local nums={}
	for word in s:gmatch("[^0-9]*([0-9]+)[^0-9]*") do nums[#nums+1]=tonumber(word) end
	return nums
end

gui.data_setup=function()
	if not gui.data then
		gui.datas=gui.master.datas
		gui.data=gui.datas.ids -- quick lookup by id
		
		if oven.console then
			oven.console.data.data=gui.data -- put here for easy console access to data
		end
	
-- refresh all data values and ranges, this will not trigger value changed messages
		
		local fatdef=3
		gui.thumb_hidden=true				
		if wwin.flavour=="android" then -- android has high dpi and fat fingers, so use this default?
			gui.thumb_hidden=false
--			fatdef=8
		end
		
		gui.file_name_fix=function(s,mode,form)

			local img=images.get()		
			if not form then
				if img.grd.depth>1 then
					form="anim"
				else
					form="image"
				end
			end

--			local s=gui.data.file_name:value()
			local s2=s
			s2=s2:gsub("%.png$",""):gsub("%.gif$",""):gsub("%.jpg$",""):gsub("%.jpeg$","")
			s2=s2:gsub("%.fatpixel$",""):gsub("%.palette$",""):gsub("%.history$","")
			if mode=="export" then
				if s2~=s then
					s2=s2..".fatpixel"
					if form=="anim" then -- suggest gif as default animation export, but png is better
						s2=s2..".gif"
					elseif form=="cmap" then
						s2=s2..".palette.png"
					elseif form=="history" then -- animation of the drawing process
						s2=s2..".history.gif"
					else
						s2=s2..".png"
					end
				end
--				gui.data.file_name:value(s2)
				return s2
			else
				if s2~=s then
					if form=="anim" then -- png now handles anims :)
						s2=s2..".png"
					elseif form=="cmap" then
						s2=s2..".palette.png"
					else
						s2=s2..".png"
					end
				end
--				gui.data.file_name:value(s2)
				return s2
			end
		end
		
		local datas_new=function(d)
			d.hooks=gui.hooks
			return gui.master.datas.new(d)
		end

		gui.data.escher_list={
			{str="pixel"},
			{str="scan"},
			{str="bleed"},
			{str="escher"},
			{str="trixel"},
		}
		datas_new({id="escher",class="list",num=1,list=gui.data.escher_list})
		datas_new({id="grid",class="number",num=1,min=0,max=8,step=1})
		datas_new({id="bloom",class="number",num=1.0,min=0,max=4,step=1/16})
		
		gui.data.hack_list={
			{str="none"},
			{str="qube"},
		}
		datas_new({id="hack",class="list",num=1,list=gui.data.hack_list})

--[[
		gui.data.preset_list={
			{str="none"},
			{str="swanky16"},
			{str="swanky32"},
			{str="spectrum"},
			{str="c64"},
			{str="msx"},
			{str="ega"},
			{str="apple2"},
		}
		datas_new({id="preset",class="list",num=1,list=gui.data.preset_list})
]]

		gui.data.palettes_list={}
		for n,p in pairs( gui.presets.palettes ) do
			gui.data.palettes_list[ #gui.data.palettes_list + 1 ]={str=n}
		end
		table.sort(gui.data.palettes_list,function(a,b) return a.str<b.str end)
		datas_new({id="palettes",class="list",num=1,list=gui.data.palettes_list}):value("Swanky32",true)

		gui.data.presets_list={}
		for n,p in pairs( gui.presets.presets ) do
			gui.data.presets_list[ #gui.data.presets_list + 1 ]={str=n}
		end
		table.sort(gui.data.presets_list,function(a,b) return a.str<b.str end)
		datas_new({id="presets",class="list",num=1,list=gui.data.presets_list}):value("Swanky32",true)

		datas_new({id="snapx",class="number",num=8,min=2,max=64,step=1})
		datas_new({id="snapy",class="number",num=8,min=2,max=64,step=1})

		gui.data.win_list={
			{str="none"},
			{str="top_left"},
			{str="top"},
			{str="top_right"},
			{str="left"},
			{str="right"},
			{str="bottom_left"},
			{str="bottom"},
			{str="bottom_right"},
		}
		datas_new({id="win" ,class="list"  ,num=9,list=gui.data.win_list})
		datas_new({id="winx",class="number",num=0.70,min=0,max=1,tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})
		datas_new({id="winy",class="number",num=0.70,min=0,max=1,tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})

		datas_new({id="gui_scale",class="number",num=1,min=0.2,max=1,tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})

		gui.data.gui_theme_list={
			{str="dark"},
			{str="bright"},
		}
		datas_new({id="gui_theme",class="list",num=1,list=gui.data.gui_theme_list})

		datas_new({id="fatpix",class="number",num=fatdef,min=1,max=32,step=1})
		datas_new({id="fatpiy",class="number",num=fatdef,min=1,max=32,step=1})
		datas_new({id="width",class="number",num=64,min=1,max=4096,step=1})
		datas_new({id="height",class="number",num=64,min=1,max=4096,step=1})
		datas_new({id="depth",class="number",num=1,min=1,max=4096,step=1})

		local idx_tostring=function(dat,num)
			return num.."/"..dat.max
		end
		datas_new({id="frame_idx",class="number",num=1,min=1,max=1,step=1,size=0.4,tostring=idx_tostring})
		datas_new({id="layer_idx",class="number",num=0,min=0,max=0,step=1,size=0.4,tostring=idx_tostring})
		datas_new({id="image_idx",class="number",num=1,min=1,max=1,step=1,size=0.4,tostring=idx_tostring})
		datas_new({id="zoom_idx",class="number",num=0,min=-8,max=8,size=0.25,tostring=function(dat,num) return tostring(math.floor(num*10)/10) end})

		datas_new({id="layer_x",class="number",num=1,min=1,max=256,step=1})
		datas_new({id="layer_y",class="number",num=1,min=1,max=256,step=1})
		datas_new({id="layer_xy",class="number",num=1})
		datas_new({id="layer_w",class="number",num=64,tostring=function(dat,num) return tostring(math.floor(num*1000)/1000) end})
		datas_new({id="layer_h",class="number",num=64,tostring=function(dat,num) return tostring(math.floor(num*1000)/1000) end})
		datas_new({id="layer_n",class="number",num=1,min=1,max=65536,step=1})

-- frame order using keys for next/prev
		datas_new({id="frame_key_list",class="string",str=""})
		datas_new({id="layer_key_list",class="string",str=""})
		datas_new({id="frame_key_list_idx",class="number",num=1,min=1,max=256,step=1})
		datas_new({id="layer_key_list_idx",class="number",num=1,min=1,max=256,step=1})

		
		datas_new({id="focus_x",class="number",num=0,min=-0xffff,max=0xffff,step=1})
		datas_new({id="focus_y",class="number",num=0,min=-0xffff,max=0xffff,step=1})

		datas_new({id="colors",class="number",num=256,min=2,max=256,step=1})
		datas_new({id="attr_width",class="number",num=8,min=2,max=256,step=1})
		datas_new({id="attr_height",class="number",num=8,min=2,max=256,step=1})
		datas_new({id="attr_redux",class="number",num=256,min=2,max=256,step=1})
		datas_new({id="attr_sub",class="number",num=256,min=1,max=256,step=1})
		datas_new({id="attr_back",class="number",num=-1,min=-1,max=255,step=1})
		datas_new({id="attr_active",class="number",num=1,min=0,max=1,step=1})

		datas_new({id="wrap_active",class="number",num=0,min=0,max=1,step=1})

		local hex_tostring=function(dat,num) return string.format("%08x",num) end
		local hex_tonumber=function(dat,str) return tonumber(str,16) end
		
		datas_new({id="color",class="number",num=0,
			tonumber=hex_tonumber,tostring=hex_tostring})

		local hex_tostring=function(dat,num) return string.format("%02x",num) end
		local hex_tonumber=function(dat,str) return tonumber(str,16) end

		datas_new({id="cr",class="number",num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		datas_new({id="cg",class="number",num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		datas_new({id="cb",class="number",num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		datas_new({id="ca",class="number",num=0,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})

		datas_new({id="trace_alpha",class="number",num=0,min=0,max=2,step=1/16})

		datas_new({id="uvmap_active",class="number",num=0,min=0,max=1,step=1})
		datas_new({id="uvmap_light",class="number",num=1,min=0,max=1,step=1/255,tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})
		datas_new({id="uvmap_dark",class="number",num=1,min=0,max=1,step=1/255,tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})
		datas_new({id="uvmap_bump",class="number",num=1,min=0,max=1,step=1/255,tostring=function(dat,num) return tostring(math.floor(num*100)/100) end})


		datas_new({id="dither_patterns",class="number",num=4,min=0,max=6,step=1,tostring=function(dat,num)
			local s=tostring(math.pow(2,num)+1)
			if s=="2" then s="0" end -- special case, call it 0 as there is no dither
			return s
		end})

		datas_new({id="dither_colors",class="number",num=32,min=2,max=256,step=1})

		datas_new({id="dither_contrast",class="number",num=0,min=-100,max=100,step=1})

		datas_new({id="dither_adjust_red",class="number",num=0,min=-100,max=100,step=1})
		datas_new({id="dither_adjust_grn",class="number",num=0,min=-100,max=100,step=1})
		datas_new({id="dither_adjust_blu",class="number",num=0,min=-100,max=100,step=1})

		datas_new({id="dither_adjust_hue",class="number",num=0,min=-180,max=180,step=1})
		datas_new({id="dither_adjust_sat",class="number",num=0,min=-100,max=100,step=1})
		datas_new({id="dither_adjust_val",class="number",num=0,min=-100,max=100,step=1})

		datas_new({id="dither_scale",class="number",num=100,min=1,max=100,step=1})

		datas_new({id="undo_memory",class="string",str="Undo using 0k of memory"})
		datas_new({id="undo_index",class="number",num=1,min=1,max=10,step=1})
		datas_new({id="undo_kmax",class="number",num=1024*64,min=1,max=1024*64,step=1})

		datas_new({id="size_lx",class="number",num=1, min=1,max=256, step=1})
		datas_new({id="size_ly",class="number",num=1, min=1,max=256, step=1})
		datas_new({id="size_hx",class="number",num=64,min=1,max=16384,step=1})
		datas_new({id="size_hy",class="number",num=64,min=1,max=16384,step=1})
		datas_new({id="size_hz",class="number",num=1, min=1,max=4096, step=1})
		datas_new({id="size_fx",class="number",num=64,min=1,max=16384,step=1})
		datas_new({id="size_fy",class="number",num=64,min=1,max=16384,step=1})
		datas_new({id="size_colors",class="number",num=256,min=1,max=256,step=1})


		gui.data.gui_anchor_x_list={
			{str="left"},
			{str="centre"},
			{str="right"},
		}
		datas_new({id="anchor_x",class="list",num=2,list=gui.data.gui_anchor_x_list})

		gui.data.gui_anchor_y_list={
			{str="top"},
			{str="middle"},
			{str="bottom"},
		}
		datas_new({id="anchor_y",class="list",num=2,list=gui.data.gui_anchor_y_list})

		datas_new({id="back_r",class="number",num=64,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		datas_new({id="back_g",class="number",num=64,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		datas_new({id="back_b",class="number",num=64,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})
		datas_new({id="back_a",class="number",num=64,min=0,max=255,step=1,
			tonumber=hex_tonumber,tostring=hex_tostring})

		gui.data.gui_skew_type_list={
			{str="up and left"},
			{str="up and right"},
			{str="right and up"},
			{str="right and down"},
			{str="down and left"},
			{str="down and right"},
			{str="left and up"},
			{str="left and down"},
		}
		datas_new({id="skew_type",class="list",num=2,list=gui.data.gui_skew_type_list})

		datas_new({id="skew_ratio",class="number",num=0,min=-15,max=15,step=1,tostring=function(dat,num)
			if num<0 then
				return "1 to "..(-num+1)
			elseif num>0 then
				return (num+1).." to 1"
			else
				return "1 to 1"
			end
		end})

		gui.data.gui_text_font_type_list={
			{str="Builtin" },
		}
		datas_new({id="text_font_type",class="list",num=1,list=gui.data.gui_text_font_type_list})

		gui.data.gui_text_font_builtin_list={
			{str="FunFont64 4x8" },
			{str="FunFont64 8x8" },
			{str="FunFont64 8x16 Bold"},
			{str="FunFont64 8x16 Regular"},
			{str="FunFont64 8x16 Italic"},
		}
		datas_new({id="text_font_builtin",class="list",num=1,list=gui.data.gui_text_font_builtin_list})

		datas_new({id="text_string",class="string",str="Hello World!"})

	end
end

gui.set_infostring=function(s,t)
	gui.infostring=s
	gui.infotime=os.time()+(t or 5)
end

gui.setup=function()

	gui.loads()

	gui.infomode="hello"
	gui.set_infostring("Welcome to swanky paint ( "..gui.swversion.." )")

	gui.showkeys=false

	gui.base_idx=0

	gui.mx=0
	gui.my=0

	gui.scale=1
	gui.size_x=128
	gui.size_y=128
	
	gui.slide=0
--	gui.active=false

	gui.color_bg={i=0,a=1,r=0,g=0,b=0,argb=0xff000000}
	gui.color_fg={i=1,a=1,r=1,g=1,b=1,argb=0xffffffff}
	
	gui.data_setup()

	gui.setup_pages(gui.master)

	images.get().pick_fgbg()
	
	gui.side_page("tools")

	gui.data_refresh()
	gui.widget_refresh_required=true
	
	return gui
end

gui.clean=function()

end

gui.widgets_of_dat_id=function(id)
	local its={}
	local idx=0
	gui.master:call_descendents(function(w)
		if	( w.data and w.data.id==id ) or
			( w.datx and w.datx.id==id ) or
			( w.daty and w.daty.id==id ) then
			its[w]=w
		end
	end)
	return pairs(its)
end

function gui.hooks(act,w,dat)

--print(act,w.id)

	if w.id=="winx" or w.id=="winy" then

		if gui.size_knob then
			gui.size_knob:set_fxy(gui.data.winx:get_pos(1,0),gui.data.winy:get_pos(1,0))
			gui.master:layout()
--			print(act)
		end

	elseif w.id=="file_load" or w.id=="file_load_button" then

		if act=="file_name_click" or act=="click" then

			gui.load_grd( gui.master.ids.file_load:path() )
			
			gui.master.ids.window_load.window_hooks("win_hide")

		end

	elseif w.id=="file_trace" or w.id=="file_trace_button" then

		if act=="file_name_click" or act=="click" then

			xpcall(
				function()
					trace.change( gui.master.ids.file_trace:path() )
					if gui.data.trace_alpha:value()==0 then -- make visible
						gui.data.trace_alpha:value(0.5)
					end
				end,
				function(...) print(...,debug.traceback()) end
			)
			
			if act=="click" then
				gui.master.ids.window_trace.window_hooks("win_hide")
			end

		end

	elseif w.id=="file_uvmap" or w.id=="file_uvmap_button" then

		if act=="file_name_click" or act=="click" then

			xpcall(
				function()
					uvmap.change( gui.master.ids.file_uvmap:path() )
					if gui.data.uvmap_active:value()==0 then -- make visible
						gui.data.uvmap_active:value(1)
					end
				end,
				function(...) print(...,debug.traceback()) end
			)
			
			if act=="click" then
				gui.master.ids.window_uvmap.window_hooks("win_hide")
			end

		end

	elseif w.id=="file_save" or w.id=="file_save_button" then

		if act=="click" then

			gui.save_grd( gui.master.ids.file_save:path() )

			gui.master.ids.window_save.window_hooks("win_hide")

		end

	elseif w.id=="file_export" or w.id=="file_export_button" then

		if act=="click" then

			gui.export_grd( gui.master.ids.file_export:path() )

			gui.master.ids.window_export.window_hooks("win_hide")
			
		end

	elseif w.id=="palettes_remapto" then

		if act=="menudrop" then

			local str=w.data.list[ dat.value ].str
			local ps=gui.presets.palettes[str]
			
			if ps then

				print("remapto","palettes",str,#ps)

				local p=wgrd.create(wgrd.U8_INDEXED,0,0,0)
				p:palette(0,#ps/4,ps)
				
				local img=images.get()
				local gb=wgrdpaint.map8( img.grd:duplicate():convert(wgrd.U8_RGBA) ,p,#ps/4,0)

				paint.act_add({
					cmd="replace",
					args={gb},
				})

			end
		end
		
	elseif w.id=="palettes_replace" then

		if act=="menudrop" then

			local str=w.data.list[ dat.value ].str
			local ps=gui.presets.palettes[str]
			
			if ps then

				local p256={}
				for i=0,255 do -- fill in missing colors
				
					p256[i*4+1]=ps[i*4+1] or 0
					p256[i*4+2]=ps[i*4+2] or 0
					p256[i*4+3]=ps[i*4+3] or 0
					p256[i*4+4]=ps[i*4+4] or 0
				
				end

				print("replace","palettes",str,#ps)

				gui.data.dither_colors:value(math.ceil(#ps/4)) -- color count

				paint.act_add({
					cmd="pal_begin",
				},{
					cmd="pal_set",
					args={0,256,p256},
				},{
					cmd="pal_end",
				})
--[[
				local img=images.get()
				img.grd:palette(0,256,p256)

				gui.widget_refresh_required=true
]]
			end





		end
		
	end
	
	if act=="value" then
	
--print(act,w.id,w:value())

		if	w.id=="dither_adjust_red"	or
			w.id=="dither_adjust_grn"	or
			w.id=="dither_adjust_blu"	or
			w.id=="dither_adjust_hue"	or
			w.id=="dither_adjust_sat"	or
			w.id=="dither_adjust_val"	or
			w.id=="dither_patterns"		or
			w.id=="dither_contrast"		or
			w.id=="dither_scale"		then

			gui.image_refresh_required=true
				
		elseif w.id=="size_hx" or w.id=="size_hy" or w.id=="size_lx" or w.id=="size_ly" then

			gui.data.size_fx:value( gui.data.size_hx:value() * gui.data.size_lx:value() )
			gui.data.size_fy:value( gui.data.size_hy:value() * gui.data.size_ly:value() )

		elseif w.id=="layer_x" or w.id=="layer_y"  then

			local image=images.get()

			gui.data.layer_xy:value( gui.data.layer_x:value() * gui.data.layer_y:value() )

			gui.data.layer_w:value( image.grd.width  / gui.data.layer_x:value() )
			gui.data.layer_h:value( image.grd.height / gui.data.layer_y:value() )

		elseif	w.id=="undo_index" then
		
				paint.act_add({cmd="gotoundo",args={w:value()}})

		elseif	w.id=="fatpix" or w.id=="fatpiy" then
			gui.widget_refresh_required=true
		elseif w.id=="gui_theme" then

			local theme_name=gui.get_list("gui_theme")

			if     theme_name=="bright" then	gui.master.color_theme=gui.master.color_theme_bright
			elseif theme_name=="dark"   then	gui.master.color_theme=gui.master.color_theme_dark
			end
			
			gui.master:call_descendents(function(w) w:set_dirty() end)

		elseif w.id=="gui_scale" then
			gui.gui_top_wrap.split_scale=gui.data.gui_scale:value()
			gui.gui_side_wrap.split_scale=gui.data.gui_scale:value()
			gui.widget_refresh_required=true
		elseif w.id=="frame_idx" then
			images.select_frame(w:value())
		elseif w.id=="layer_idx" then
			images.select_layer(w:value())
		elseif w.id=="image_idx" then
			images.select(w:value())
		elseif w.id=="zoom_idx" then
			local v=views[1]
			v.scale=2^w:value()
		elseif     w.id=="presets" then

--			local preset=w.list[ w:value() ].str
			local preset_name=gui.get_list("presets")

			local preset=gui.presets.presets[preset_name]

			if preset then
				if preset.attr_width  then gui.data.attr_width:value(  preset.attr_width  ) end
				if preset.attr_height then gui.data.attr_height:value( preset.attr_height ) end
				if preset.attr_redux  then gui.data.attr_redux:value(  preset.attr_redux  ) end
				if preset.attr_sub    then gui.data.attr_sub:value(    preset.attr_sub    ) end
				if preset.attr_back   then gui.data.attr_back:value(   preset.attr_back   ) end
				
				if preset.colors      then gui.data.size_colors:value( preset.colors      ) end
				if preset.width       then gui.data.size_hx:value(     preset.width       ) end
				if preset.height      then gui.data.size_hy:value(     preset.height      ) end
				if preset.depth       then gui.data.size_hz:value(     preset.depth       ) end
				
				gui.data.palettes:value(preset_name)
			end
			
			gui.widget_refresh_required=true
		else
			if w.id=="cr" or w.id=="cg" or w.id=="cb" or w.id=="ca" or w.id=="color" then    
				local g=gui.color_fg
				if     w.id=="cr" then
					g.r=w:value()
					gui.data.color:value( g.a*0x1000000 + g.r*0x10000 + g.g*0x100 + g.b , true )
				elseif w.id=="cg" then
					g.g=w:value()
					gui.data.color:value( g.a*0x1000000 + g.r*0x10000 + g.g*0x100 + g.b , true )
				elseif w.id=="cb" then
					g.b=w:value()
					gui.data.color:value( g.a*0x1000000 + g.r*0x10000 + g.g*0x100 + g.b , true )
				elseif w.id=="ca" then
					g.a=w:value()
					gui.data.color:value( g.a*0x1000000 + g.r*0x10000 + g.g*0x100 + g.b , true )
				elseif w.id=="color" then
					local c=w:value()
					g.a=math.floor((c/0x1000000)%256)
					g.r=math.floor((c/  0x10000)%256)
					g.g=math.floor((c/    0x100)%256)
					g.b=math.floor((c          )%256)

					gui.data.cr:value(g.r,true)
					gui.data.cg:value(g.g,true)
					gui.data.cb:value(g.b,true)
					gui.data.ca:value(g.a,true)
				end
				gui.set_rgba(g.i,g.r,g.g,g.b,g.a)
--				gui.color_set(g,g.i)
				
				gui.image_refresh_required=true
			end
		end
	end
--print(act)
	if act=="active" or ( act=="over" and w.master.press ) then
		if w.id=="popmenu" or w.id=="topmenu" then
			local px,py=w:get_master_xy(0,w.hy)
			gui.popmenu(w,{
				px=px,
				py=py,
			})
		end
	end
	
	if act=="over" then
		gui.over=w
		gui.infomode="over"
		if w.id=="infobar" then
		end

	end

--print(w.id,act)
	if act=="update" then
		if     w.id=="color_hex" then
--			local s=gui.data.color.str
--			local n=tonumber(s,16)
--			gui.data.color.num=n
--			gui.data.color:value(n)
		end
	end

	if act=="click" then

--print(w.id)

		if w.id then
		
			if      w.id=="window" then
			
				local window=gui.master.ids[w.user]
				if window then				
					window.window_hooks("win_toggle")
				end
				
				
			elseif w.id=="export_history" then

				gui.master.ids.window_history.window_hooks("win_hide")
				gui.master.ids.file_export:path( gui.file_name_fix(paint.basepath,"export","history"))
				gui.master.ids.window_export.window_hooks("win_show")

			elseif  w.id=="thumb" then
				gui.thumb_hidden=not gui.thumb_hidden
				gui.gui_thumb.parent.hidden=not gui.thumb_hidden
			elseif w.id=="popmenu" or w.id=="topmenu" then
				local px,py=w:get_master_xy(0,w.hy)
				gui.popmenu(w,{
					px=px,
					py=py,
				})
			elseif w.id=="quit" then
				gui.show_quit_request()
--				oven.next=true
			elseif w.id=="about" then
				oven.next=oven.rebake(gui.about or "wetgenes.gamecake.spew.about.sinescroll")

			elseif w.id=="new_image" then

				images.new_grd( gui.data.size_hx:value()*gui.data.size_lx:value() , gui.data.size_hy:value()*gui.data.size_ly:value() , gui.data.size_hz:value() )
				images.get().grd.layers:config(gui.data.size_lx:value(),gui.data.size_ly:value())
				gui.full_refresh_required=true

			elseif w.id=="resize" then

				local nx=gui.data.size_hx:value()
				local ny=gui.data.size_hy:value()
				local lx=gui.data.size_lx:value()
				local ly=gui.data.size_ly:value()
				local ax=gui.data.anchor_x:value()
				local ay=gui.data.anchor_y:value()

				local g=images.get().grd			
				local ox,oy=g.layers:size()
				
				if g.layers.x~=lx or g.layers.y~=ly then -- new layers layout
					if g.layers.count > lx*ly then
						g.history:push_layers(lx*ly+1,lx*ly-g.layers.count) -- blank layers we are about to remove
					end
				end

				if ox~=nx or oy~=ny then -- new size
					g.history:push_layer_size(nx,ny,ax-2,ay-2)
				end
				
				if g.layers.x~=lx or g.layers.y~=ly then -- new layers layout
					g.history:push_rearrange(lx,ly,lx*ly)
				end

				gui.full_refresh_required=true

			elseif w.id=="resize_set" then
				
				if w.user=="brush" then -- use brush size
				
					local img=images.get()
					local brush=paint.brush
					local lx,ly=1,1
					if brush and brush.width>0 and brush.height>0 then
						lx=math.floor(img.grd.width/brush.width)
						ly=math.floor(img.grd.height/brush.height)
					end
					gui.data.size_lx:value( lx ,true)
					gui.data.size_ly:value( ly ,true)

				elseif w.user=="single_layer" then

					gui.data.size_lx:value( 1)
					gui.data.size_ly:value( 1)

				elseif w.user=="double_size" then

					gui.data.size_hx:value( gui.data.size_hx:value()*2 )
					gui.data.size_hy:value( gui.data.size_hy:value()*2 )

				elseif w.user=="half_size" then

					gui.data.size_hx:value( math.ceil(gui.data.size_hx:value()/2) )
					gui.data.size_hy:value( math.ceil(gui.data.size_hy:value()/2) )

				elseif w.user=="reset" then

					local image=images.get()
					local hx,hy=image.grd.layers:size()

					gui.data.size_hx:value(hx)
					gui.data.size_hy:value(hy)
					gui.data.size_lx:value(image.grd.layers.x)
					gui.data.size_ly:value(image.grd.layers.y)

				end

			elseif w.id=="layers_set" then
				
				if w.user=="single_layer" then

					gui.data.layer_x:value( 1 )
					gui.data.layer_y:value( 1 )

				elseif w.user=="double_x" then

					gui.data.layer_x:value( gui.data.layer_x:value()*2 )

				elseif w.user=="half_x" then

					gui.data.layer_x:value( math.ceil(gui.data.layer_x:value()/2) )

				elseif w.user=="double_y" then

					gui.data.layer_y:value( gui.data.layer_y:value()*2 )

				elseif w.user=="half_y" then

					gui.data.layer_y:value( math.ceil(gui.data.layer_y:value()/2) )

				elseif w.user=="reset" then

					local image=images.get()
					gui.data.layer_x:value( image.grd.layers.x )
					gui.data.layer_y:value( image.grd.layers.y )

				end

			elseif w.id=="frame_del" then
				paint.act_add({cmd="frame_del"})
			elseif w.id=="frame_add" then
				paint.act_add({cmd="frame_add"})
			elseif w.id=="layer_del" then
				paint.act_add({cmd="layer_del"})
			elseif w.id=="layer_add" then
				paint.act_add({cmd="layer_add"})
				
			elseif w.id=="layer_flatten" then
				local image=images.get()
				local dest=images.select(images.create())
				dest.force_grd( image.grd.layers:flatten_grd() )
				gui.full_refresh_required=true
			elseif w.id=="layer_rechop" then
				local image=images.get()
				
				local lx=gui.data.layer_x:value()
				local ly=gui.data.layer_y:value()
				local hx=math.floor(image.grd.width/lx)
				local hy=math.floor(image.grd.height/ly)
				
				if hx*lx ~= image.grd.width then

					gui.set_infostring("ERROR: Layer width is invalid multiple of image width.")

				elseif hy*ly ~= image.grd.height then

					gui.set_infostring("ERROR: Layer weight is invalid multiple of image height.")

				else
				
					image.grd.history:push_rechop( gui.data.layer_x:value() , gui.data.layer_y:value() )
					gui.full_refresh_required=true
					
				end					

			elseif w.id=="cancel" then
				gui.side_page_next="menu"
--			elseif w.id=="overwrite_no" then
--				gui.side_page_next="menu"
--			elseif w.id=="overwrite_yes" then
--				gui.save_grd( gui.data.file_path() , true )
--			elseif w.id=="overwrite_export_yes" then
--				gui.export_grd( gui.data.file_path() , true )
			elseif w.id=="load" then
				gui.side_page_next="load"
			elseif w.id=="save" then
				gui.side_page_next="save"
			elseif w.id=="quicksave" then
				paint.quicksave()
			elseif w.id=="info" then
				gui.side_page_next="about"
			elseif w.id=="new" then
				gui.side_page_next="new"
			elseif w.id=="colors" then
				gui.side_page_next="colors"
			elseif w.id=="snap" then
				paint.snap=not paint.snap
				gui.widget_refresh_required=true
			elseif w.id=="brushmode" then
				if w.user=="paint" then
					paint.brushmode="paint"
				elseif w.user=="color" then
					paint.brushmode="color"
				elseif w.user=="replace" then
					paint.brushmode="replace"
				end
				gui.widget_refresh_required=true
			elseif w.id=="pickup" then
				paint.mode="pickup"
				gui.widget_refresh_required=true
			elseif w.id=="paint" then
				paint.mode="brush"
				gui.widget_refresh_required=true
				gui.imnage_refresh_required=true
			elseif w.id=="paint_dot" then
				paint.set_pbrush("dot")
				gui.widget_refresh_required=true
			elseif w.id=="paint_circle" then
				paint.set_pbrush("circle")
				gui.widget_refresh_required=true
			elseif w.id=="paint_block" then
				paint.set_pbrush("block")
				gui.widget_refresh_required=true
			elseif w.id=="paint_dash" then
				paint.set_pbrush("dash")
				gui.widget_refresh_required=true
			elseif w.id=="paint_line" then
				paint.set_pbrush("line")
				gui.widget_refresh_required=true
			elseif w.id=="paint_grow" then
				paint.set_pbrush("grow")
				gui.widget_refresh_required=true
			elseif w.id=="paint_shrink" then
				paint.set_pbrush("shrink")
				gui.widget_refresh_required=true
			elseif w.id=="paint_brush_next" then
				paint.set_pbrush("next")
				gui.widget_refresh_required=true
			elseif w.id=="paint_brush_prev" then
				paint.set_pbrush("prev")
				gui.widget_refresh_required=true
			elseif w.id=="scroll" then
				paint.mode="scroll"
				gui.widget_refresh_required=true
			elseif w.id=="redoundo" then
				paint.act_add({cmd="redoundo"})
			elseif w.id=="undo" then
				paint.act_add({cmd="undo"})
			elseif w.id=="redo" then
				paint.act_add({cmd="redo"})
			elseif w.id=="frame_swap" then
				images.select_spare()
			elseif w.id=="frame_copy" then
				images.select_spare(nil,true)
			elseif w.id=="clear" then 
				paint.act_add({cmd="begin"})
				paint.act_add({cmd="clear"})
				paint.act_add({cmd="end"})
			elseif w.id=="color_copy" then
				gui.color_mode="copy"
				gui.widget_refresh_required=true
			elseif w.id=="color_swap" then
				gui.color_mode="swap"
				gui.widget_refresh_required=true
			elseif w.id=="color_blend" then
				gui.color_mode="blend"
				gui.widget_refresh_required=true
			elseif w.id=="color_select" then
				gui.color_mode="select"
				gui.widget_refresh_required=true
			elseif w.id=="color_pick" then

				local g=gui.color_fg
				
				if gui.color_mode=="select" then

					if dat and dat.keyname then
						if dat.keyname=="mouse_right" then
							g=gui.color_bg
						end
					end
					gui.color_set(g,w.user+gui.base_idx)

-- no change, but will end a previously in progress pal edit
					paint.act_add({
						cmd="pal_begin",
					},{
						cmd="pal_end",
					})

				else

					if gui.color_mode=="blend" then

						gui.color_mode="select"
						local frm=g.i
						local too=w.user
						if frm>too then frm,too=too,frm end
						
						local p=images.get().grd:palette(frm,1)
						local q=images.get().grd:palette(too,1)
						if p and q then -- make sure selection is in bounds
							q[1]=q[1]-p[1]
							q[2]=q[2]-p[2]
							q[3]=q[3]-p[3]
							q[4]=q[4]-p[4]
							local d=too-frm if d<=0 then d=1 end

							paint.act_add({
								cmd="pal_begin",
							})
							for i=frm,too do
								local t={	math.floor(p[1] + (q[1]*(i-frm)/d) ) ,
											math.floor(p[2] + (q[2]*(i-frm)/d) ) ,
											math.floor(p[3] + (q[3]*(i-frm)/d) ) ,
											math.floor(p[4] + (q[4]*(i-frm)/d) ) }
	--							gui.set_rgba(i,t[1],t[2],t[3],t[4])
								paint.act_add({
									cmd="pal_set",
									args={i,1,{t[1],t[2],t[3],t[4]}},
								})
							end
							paint.act_add({
								cmd="pal_end",
							})
						end

					elseif gui.color_mode=="copy" then

						gui.color_mode="select"
						local p=images.get().grd:palette(g.i,1)
--						gui.set_rgba(w.user,p[1],p[2],p[3],p[4])

						paint.act_add({
							cmd="pal_begin",
						},{
							cmd="pal_set",
							args={w.user,1,p},
						},{
							cmd="pal_end",
						})

					elseif gui.color_mode=="swap" then

						gui.color_mode="select"
						local p=images.get().grd:palette(g.i,1)
						local q=images.get().grd:palette(w.user,1)

						paint.act_add({
							cmd="pal_begin",
						},{
							cmd="pal_set",
							args={g.i,1,q},
						},{
							cmd="pal_set",
							args={w.user,1,p},
						},{
							cmd="pal_end",
						})
					end
				end

			elseif w.id=="color" then
				local g=gui.color_fg
				if dat and dat.keyname then
					if dat.keyname=="mouse_right" then
						g=gui.color_bg
					end
				end
				gui.color_set(g,w.user+gui.base_idx)
				gui.widget_refresh_required=true
			elseif w.id=="idx_sub" then
				gui.base_idx=gui.base_idx-8
				if gui.base_idx<0 then gui.base_idx=0 end
				gui.widget_refresh_required=true
			elseif w.id=="idx_add" then
				gui.base_idx=gui.base_idx+8
				if gui.base_idx>256-32 then gui.base_idx=256-32 end
				gui.widget_refresh_required=true
			elseif w.id=="magnify" or w.id=="magnify_right" then
				local v=views[1]

				if v.scale>=1 then
					v.scale=math.floor(v.scale+0.5)
					if (dat and dat.keyname=="mouse_right" ) or w.id=="magnify_right" then
						v.scale=v.scale-1
					else
						v.scale=v.scale+1
					end
					if v.scale<1 then v.scale=1 end
				else
					if (dat and dat.keyname=="mouse_right" ) or w.id=="magnify_right" then
						v.scale=v.scale/2
					else
						v.scale=v.scale*2
					end
				end

				main.remouse_fix=true
				gui.data.zoom_idx:value(math.log(v.scale)/math.log(2))
				
			elseif w.id=="bg_color" or w.id=="fg_color" then -- swap

				local fg_idx=gui.color_fg.i
				local bg_idx=gui.color_bg.i
				gui.color_set(gui.color_fg,bg_idx)
				gui.color_set(gui.color_bg,fg_idx)

			elseif w.id=="page" then
				gui.side_page_next=w.user
--				gui.side_page(w.user)
			elseif w.id=="keys" then
				gui.showkeys=not gui.showkeys
				gui.side_page_next=w.user

			elseif w.id=="brush_handle" then
				local yy=w.user:sub(1,1)
				local xx=w.user:sub(2,2)

				if xx=="l" then
					paint.hx=0
				elseif xx=="c" then
					paint.hx=0.5
				elseif xx=="r" then
					paint.hx=1
				end

				if yy=="t" then
					paint.hy=0
				elseif yy=="c" then
					paint.hy=0.5
				elseif yy=="b" then
					paint.hy=1
				end

			elseif w.id=="brush_skew" then
				local pb=paint.brush
				if pb then
					if pb.width<1024 and pb.height<1024 then
						paint.brush=wgrdpaint.skew(paint.brush , gui.color_bg.i , gui.data.skew_type:value() , gui.data.skew_ratio:value() )
					end
				end
			elseif w.id=="brush_text" then
			
				local f=gui.data.text_font_builtin:value()
				local s=gui.data.text_string:value()
	
				local fx,fy=8,8
				if f==1 then fx=fx/2 end
				if f>=3 then fy=fy*2 end

				local lines=wstring.split_lines(s)

				local hx,hy=1,#lines
								
				for i,s in ipairs(lines) do if #s>hx then hx=#s end end
							
				local img=images.get()

				paint.brush=assert(wgrd.create(wgrd.U8_INDEXED,hx*fx,hy*fy,1))
				paint.brush:palette(0,256,img.grd:palette(0,256)) -- copy pal from image
				paint.mode="brush"

				local c=wgrdpaint.canvas(paint.brush)
				c.color( gui.color_fg.i , gui.color_bg.i )
				c.set_font(f)
				for i,s in ipairs(lines) do
					c.text(s,0,(i-1)*fy)
				end

			elseif w.id=="brush_square_outline" then
				local pb=paint.brush
				if pb then
					if pb.width<1024 and pb.height<1024 then
						paint.brush=wgrdpaint.square_outline(paint.brush,gui.color_bg,gui.color_fg)
					end
				end
			elseif w.id=="brush_outline" then
				local pb=paint.brush
				if pb then
					if pb.width<1024 and pb.height<1024 then
						paint.brush=wgrdpaint.outline(paint.brush,gui.color_bg,gui.color_fg)
					end
				end
			elseif w.id=="brush_inline" then
				local pb=paint.brush
				if pb then
					paint.brush=wgrdpaint.inline(paint.brush,gui.color_bg,gui.color_fg)
				end
			elseif w.id=="brush_half" then
				local pb=paint.brush
				if pb then
					if pb.width>1 and pb.height>1 then
						pb:scale(math.ceil(pb.width/2),math.ceil(pb.height/2),1)
					end
				end
			elseif w.id=="brush_double" then
				local pb=paint.brush
				if pb then
					if pb.width<1024 and pb.height<1024 then
						pb:scale(pb.width*2,pb.height*2,1)
					end
				end
			elseif w.id=="brush_double_x" then
				local pb=paint.brush
				if pb then
					if pb.width<1024 then
						pb:scale(pb.width*2,pb.height,1)
					end
				end
			elseif w.id=="brush_double_y" then
				local pb=paint.brush
				if pb then
					if pb.height<1024 then
						pb:scale(pb.width,pb.height*2,1)
					end
				end
			elseif w.id=="brush_flip_x" then
				local pb=paint.brush
				if pb then
					paint.brush:flipx()
				end
			elseif w.id=="brush_flip_y" then
				local pb=paint.brush
				if pb then
					paint.brush:flipy()
				end
			elseif w.id=="brush_rotate" then
				local pb=paint.brush
				if pb then
					paint.brush=wgrdpaint.rotate(paint.brush,90)
				end
			elseif w.id=="brush_remap" then
				local pbrush=paint.brush
				local img=images.get()
				if pbrush then
					paint.brush=wgrdpaint.map8( pbrush:convert(wgrd.U8_RGBA) ,img.grd, img.grd.colors, 0)
				end
			elseif w.id=="brush_remap_from" then
				local pbrush=paint.brush
				local img=images.get()
				if pbrush then
					img.set_grd( wgrdpaint.map8( img.grd:convert(wgrd.U8_RGBA) ,pbrush) )
				end
			elseif w.id=="brush_pal_from" then
						paint.act_add({
							cmd="pal_begin",
						},{
							cmd="pal_set",
							args={0,256,paint.brush:palette(0,256)},
						},{
							cmd="pal_end",
						})
--				local pbrush=paint.brush
--				local img=images.get()
--				img.grd:palette(0,256,paint.brush:palette(0,256)) -- copy pal
--				gui.widget_refresh_required=true
			elseif w.id=="bitdown_brush_to_clipboard" then
				oven.win:set_clipboard( bitdown.grd_pix_idx(paint.brush) )
			elseif w.id=="bitdown_clipboard_to_brush" then
				if oven.win.has_clipboard() then
					local img=images.get()
					local s=oven.win:get_clipboard()
					if s then
--						print(s)
						local hx,hy=bitdown.pix_size(s)
						if hx and hy and hx>1 and hy>1 then
							paint.brush=assert(wgrd.create(wgrd.U8_INDEXED,hx,hy,1))
							paint.brush:palette(0,256,img.grd:palette(0,256)) -- copy pal from image
							bitdown.pix_grd_idx(s,bitdown.cmap,paint.brush,0,0,hx,hy)
							paint.mode="brush"
						end
					end
				end
			elseif w.id=="fill" then
				paint.mode="fill"
				gui.widget_refresh_required=true
			elseif w.id=="image_select" then
				images.select(w.user)
				gui.widget_refresh_required=true
			elseif w.id=="image_delete" then
				images.delete()
				gui.widget_refresh_required=true
			elseif w.id=="image_delete_other" then
				local idx=images.idx
				for i=#images,1,-1 do
					if i~=idx then
						images.delete(i)
					end
				end
				gui.widget_refresh_required=true
			elseif w.id=="image_delete_all" then
				for i=#images,1,-1 do
					images.delete(i)
				end
				gui.widget_refresh_required=true
			elseif w.id=="swap_frames_layers" then
			
				paint.act_add({cmd="swap_frames_layers"})

			elseif w.id=="anim_from_brushchop" then
--TODO: move to draw thread
				local image=images.get()
				local ga=image.grd
				local brush=paint.brush
				if brush and brush.width>0 and brush.height>0 then
					local dest=images.select(images.create())
					local gb=wgrd.duplicate(ga)
					gb:resize(brush.width,brush.height,1)
					local f=0
					for y=brush.y,ga.height,gb.height do
						for x=brush.x,ga.width,gb.width do
							if x+gb.width<=ga.width and y+gb.height<=ga.height then -- valid
								gb:resize(gb.width,gb.height,f+1) -- add a frame?
--print(x,y,gb.depth)
								gb:pixels(0,0,f,gb.width,gb.height,1,
									ga:pixels(x,y,0,gb.width,gb.height,1,""))
								f=f+1
							end
						end
					end
					dest.force_grd(gb)
					gui.full_refresh_required=true
				end
			elseif w.id=="image_from_anim" then
--TODO: move to draw thread
				local image=images.get()
				local ga=image.grd
				if ga.depth>1 then
					local dest=images.select(images.create())
					local gb=wgrd.duplicate(ga)
					gb:resize(ga.width*ga.depth,ga.height,1)
					for i=0,ga.depth-1 do
						gb:pixels(ga.width*i,0,ga.width,ga.height,
							ga:pixels(0,0,i,ga.width,ga.height,1,""))
					end
					dest.force_grd(gb)
					gui.widget_refresh_required=true
				end
			elseif w.id=="image_from_brush" then
				if paint.brush and paint.brush.width>0 and paint.brush.height>0 then
					images.select(images.create())
					local image=images.get()
					image.force_grd(wgrd.duplicate(paint.brush))
					gui.widget_refresh_required=true
				end
			elseif w.id=="image_to_brush" then
				local img=images.get()
				local w,h=img.grd.layers:size()
				paint.mode="brush"
				paint.hx=0.5
				paint.hy=0.5
				paint.act_add({cmd="begin"})
				paint.act_add({
					cmd="pickup",
					args={0,0,w,h,false},
					})
				paint.act_add({cmd="end"})
			elseif w.id=="layer_show" then
				-- toggle
				if w.state=="selected" then w.state="none" else w.state="selected" end
				gui.full_refresh_required=true
			elseif w.id=="frame_show" then
				-- toggle
--				if w.state=="selected" then w.state="none" else w.state="selected" end
			elseif w.id=="process_show" then
				-- toggle
				if w.state=="selected" then w.state="none" else w.state="selected" end
				gui.full_refresh_required=true
			elseif w.id=="config" then
				if     w.user=="load" then
					gui.config_load()
				elseif w.user=="save" then
					gui.config_save()
				elseif w.user=="reset" then
					gui.config_reset()
				elseif w.user=="reset_history" then
					gui.config_reset_history()
				elseif w.user=="reset_windows" then
					gui.config_reset_windows()
				end
				gui.widget_refresh_required=true
				
			elseif w.id=="dither_reset" then

				gui.data.dither_patterns:value(4)
				gui.data.dither_contrast:value(0)

				gui.data.dither_adjust_red:value(0)
				gui.data.dither_adjust_grn:value(0)
				gui.data.dither_adjust_blu:value(0)

				gui.data.dither_adjust_hue:value(0)
				gui.data.dither_adjust_sat:value(0)
				gui.data.dither_adjust_val:value(0)

				gui.image_refresh_required=true

			elseif w.id=="dither_colors" then -- pick a palette

				local image=images.get()
				image.adjust_pal( gui.data.dither_colors:value() )
				gui.image_refresh_required=true
				gui.widget_refresh_required=true
			

			elseif w.id=="convert_24bit" then

				local source=images.get()
				
				if source.grd then

					local dest=images.select(images.create())

					dest.grd=nil
					dest.grd_rgba=source.grd:duplicate():convert(wgrd.U8_RGBA)
					dest.adjust_pal(256)

					gui.full_refresh_required=true
				end

			elseif w.id=="dither_apply" then

				local image=images.get()
				image.adjust_grd("final")

				gui.master.ids.window_dither.window_hooks("win_hide") -- hide dither window
				
			elseif w.id=="image_wrap_toggle" then

				if gui.data.wrap_active:value()==0 then
					gui.data.wrap_active:value(1)
				else
					gui.data.wrap_active:value(0)
				end
				gui.widget_refresh_required=true

			end
			


		end
	end
end

gui.msg=function(m)


	
	if not gui.master.focus then -- ignore keys when typing into an input box

	if m.class=="key" then
		if m.action==1 then
			if m.keyname=="space" then
				if not paint.autohand then
					paint.autohand=true
					gui.widget_refresh_required=true
				end
			end
		end
		if m.action==-1 then
			if m.keyname=="space" then
				if paint.autohand then
					paint.autohand=false
					gui.widget_refresh_required=true
				end
			elseif m.keyname=="tab" then
				local g1=gui.gui_side
				local g2=gui.gui_top
				if g1 and g2 then
					g1=g1.parent
					g2=g2.parent
					if g1.hidden and g2.hidden then
						g1.hidden=false
						g2.hidden=false
					elseif g1.hidden then
						g1.hidden=false
						g2.hidden=true
					elseif g2.hidden then
						g1.hidden=true
						g2.hidden=true
					else
						g1.hidden=true
						g2.hidden=false
					end
				end
				gui.master:layout()
--				gui.active=not gui.active
				return
			end
		end
	end
	
	if m.class=="key" and m.action==1 and main.keys.control then

		if m.keyname=="z" then -- undo
--print("undo")
			paint.act_add({cmd="undo"})
			return
		elseif m.keyname=="y" then -- redo
--print("redo")
			paint.act_add({cmd="redo"})
			return
		end
		
	end

	if m.class=="text" then
		local it=gui.lookup_keys[m.text]
		if it then
			gui.hooks("click",it)
			return -- handled
		end

	end

	if m.class=="key" and m.action==1  and main.keys.shift then

		if m.keyname=="1" then
			paint.act_add({cmd="frame_del"})
		elseif m.keyname=="2" then
			paint.act_add({cmd="frame_add"})
		elseif m.keyname=="3" then
			paint.act_add({cmd="layer_del"})
		elseif m.keyname=="4" then
			paint.act_add({cmd="layer_add"})
		end

	end


	if m.class=="key" and m.action==1  and not main.keys.any then
	
		if m.keyname=="return" or m.keyname=="keypad enter" then -- OK request

			if gui.request_window then -- close a request if one is visible
				gui.request_window.close_request("yes")
			end

		elseif m.keyname=="escape" then -- toggle all window visibility

			if gui.request_window then -- close a request if one is visible
				gui.request_window.close_request("no")
			else
				gui.screen:windows_toggle()
			end


		-- rejigle view center
		elseif m.keyname=="n" then

--			local lw,lh=images.get().layers:size()
			local _,_,_,lw,lh,_=images.get().grd.layers:area()
			gui.data.focus_x:value( paint.x-math.floor(lw/2)  )
			gui.data.focus_y:value( paint.y-math.floor(lh/2) )
			main.remouse_fix=true
		end
		
		local function jiggle(x,y)
		
			gui.data.focus_x:value( gui.data.focus_x:value()+x  )
			gui.data.focus_y:value( gui.data.focus_y:value()+y  )
			main.remouse_fix=true
		end
		
		if     m.keyname=="up"    then jiggle( 0,-gui.data.snapy:value())
		elseif m.keyname=="down"  then jiggle( 0, gui.data.snapy:value())
		elseif m.keyname=="left"  then jiggle(-gui.data.snapx:value(), 0)
		elseif m.keyname=="right" then jiggle( gui.data.snapx:value(), 0)
		end

		if m.keyname=="[" then
			gui.color_dec()
		elseif m.keyname=="]" then
			gui.color_inc()
		end

		if m.keyname=="{" then
			gui.color_dec(gui.color_bg)
		elseif m.keyname=="}" then
			gui.color_inc(gui.color_bg)
		end

		if m.keyname=="," then -- grab the color under the cursor
			paint.mode="pipette"
			gui.widget_refresh_required=true
		end

-- image select 5/6
		if m.keyname=="5" then
			images.select_prev()
		end
		if m.keyname=="6" then
			images.select_next()
		end

-- layer select 3/4/5 (4 toggles visibility all/this layer)
		if ({["3"]=true,["4"]=true,["e"]=true})[m.keyname] then -- layer select
			if m.keyname=="e" then -- toggle viz
				local w=gui.master.ids.layer_show
				if w.state=="selected" then w.state="none" else w.state="selected" end
			else
				local n,x=images.select_layer()
				local t=gui.numlist(gui.data.layer_key_list:value())
				if #t>1 then -- special order
					local a=gui.data.layer_key_list_idx:value()
					if t[a] ~= n then
						for i,v in ipairs(t) do if n==v then a=i break end end
					end
					if m.keyname=="3" then -- back
						a=a-1
					end
					if m.keyname=="4" then -- forward
						a=a+1
					end
					if a<1 then a=#t end
					if a>#t then a=1 end
					n=t[a]
					gui.data.layer_key_list_idx:value(a)
				else
					if m.keyname=="3" then -- back
						n=n-1
					end
					if m.keyname=="4" then -- forward
						n=n+1
					end
				end
				if n<0 then n=x end
				if n>x then n=0 end
				gui.data.layer_idx:value(n)
			end
		end

-- frame select 1/2		
		if ({["1"]=true,["2"]=true,["q"]=true})[m.keyname] then -- frame select
			if m.keyname=="q" then -- toggle viz
				local w=gui.master.ids.frame_show
--				if w.state=="selected" then w.state="none" else w.state="selected" end
			else
				local n,x=images.select_frame()
				local t=gui.numlist(gui.data.frame_key_list:value())
				if #t>1 then -- special order
					local a=gui.data.frame_key_list_idx:value()
					if t[a] ~= n then
						for i,v in ipairs(t) do if n==v then a=i break end end
					end
					if m.keyname=="1" then -- back
						a=a-1
					end
					if m.keyname=="2" then -- forward
						a=a+1
					end
					if a<1 then a=#t end
					if a>#t then a=1 end
					n=t[a]
					gui.data.frame_key_list_idx:value(a)
				else
					if m.keyname=="1" then -- back
						n=n-1
					end
					if m.keyname=="2" then -- forward
						n=n+1
					end
				end
				if n<1 then n=x end
				if n>x then n=1 end
				gui.data.frame_idx:value(n)
			end
		end

		if m.keyname=="p" then -- toggle processing
			local w=gui.master.ids.process_show
			if w.state=="selected" then w.state="none" else w.state="selected" end
			gui.widget_refresh_required=true
		end

		if m.keyname=="f1" then -- pixel brush
			paint.brushmode="paint"
			gui.widget_refresh_required=true
		end
		if m.keyname=="f2" then -- pixel brush
			paint.brushmode="color"
			gui.widget_refresh_required=true
		end
		if m.keyname=="f3" then -- pixel brush
			paint.brushmode="replace"
			gui.widget_refresh_required=true
		end
		
--		print(wstr.dump(m))
		
		-- maginfy toggle
		if m.keyname=="m" then
			if views[1].scale==1 then
				views[1].scale=8
			else
				views[1].scale=1
			end
			gui.data.zoom_idx:value(math.log(views[1].scale)/math.log(2))

			main.remouse_fix=true
		end
	end
	end
	
	gui.master:msg(m)
	if m.class=="mouse" then
		if gui.master.over~=gui.master then return true end
		if gui.master.focus then return true end -- a text input has focus
	end
	
	return false

end



function gui.fixup_widget(w)

	local p
	local idx_to_argb=function(idx)
		if not p then p=images.get().grd:palette(0,256) end -- autofetch palette
		local id=(idx)*4
		local argb
		if p and p[id+1] then
			local r,g,b,a=p[1+id],p[2+id],p[3+id],p[4+id]
			argb=a*0x1000000 + r*0x10000 + g*0x100 + b 
		else
			argb=0xff000000
		end
		return argb
	end	
	local image=images.get()
	
	local change=function(it)
		local dirty=false
		for n,v in pairs(it) do
			if w[n]~=v then
				w[n]=v
				dirty=true
			end
		end
		if dirty and w.set_dirty then
			w:set_dirty()
		end
	end

--		w.skin=w.skin or "swanky" -- force swanky skin

	local it=gui.lookup[w.id]
	if it and w.user and it[w.user] then it=it[w.user] end
	if it then
		change{info=it}
		if it.idx and w.hx and  w.hx==w.hy then --must be square
			change{
				sheet_id=it.idx,
				text=false,
				sheet_over="imgs/icons",
				sheet_px=w.hx/2,
				sheet_py=w.hy/2,
				sheet_hx=w.hx*1.0,
				sheet_hy=w.hy*1.0,
			}
		end
	end


	if w.id=="color" or w.id=="color_pick" then
		local idx=w.user
		if w.id=="color" then idx=idx+gui.base_idx end
		change{
			color=idx_to_argb(idx),
			state="none",
		}

		if idx==gui.color_fg.i and idx==gui.color_bg.i then
			change{
				outline_size=2,
				outline_color=0xffffffff,
				outline_fade_color=0xff000000,
			}
		elseif idx==gui.color_fg.i then
			change{
				outline_size=-1,
				outline_color=0xffffffff,
				outline_fade_color=0xffffffff,
			}
		elseif idx==gui.color_bg.i then
			change{
				outline_size=-1,
				outline_color=0xff000000,
				outline_fade_color=0xff000000,
			}
		else
			change{
				outline_size=false,
				outline_color=false,
				outline_fade_color=false,
			}
		end

	elseif w.id=="fg_color" then
		change{ color=idx_to_argb(gui.color_fg.i) }
	elseif w.id=="bg_color" then
		change{ color=idx_to_argb(gui.color_bg.i) }
	elseif w.id=="snap" then
		if paint.snap then change{ state="selected" } else change { state="none" } end
	elseif w.id=="fatslidex" then
		change{ text=tostring(gui.data.fatpix:value()).."x" }
	elseif w.id=="fatslidey" then			
		change{ text=tostring(gui.data.fatpiy:value()).."y" }
	elseif w.id=="keys" then
		if gui.showkeys then change{ state="selected" } else change { state="none" } end
	elseif w.id=="fill" then
		if paint.mode=="fill" then change{ state="selected" } else change { state="none" } end
	elseif w.id=="pickup" then
		if paint.mode=="pickup" then change{ state="selected" } else change { state="none" } end
	elseif w.id=="scroll" then
		if paint.mode=="scroll" then change{ state="selected" } else change { state="none" } end
	elseif w.id=="paint" then
		if paint.mode=="brush" then change{ state="selected" } else change { state="none" } end
	elseif w.id=="paint_dot" then
		local pba=paint.pbrush_area
		if paint.mode=="pbrush" and pba[1]==0 and pba[2]==0 then 
			change{ state="selected" } else change { state="none" } end
	elseif w.id=="paint_circle" then
		local pba=paint.pbrush_area
		if paint.mode=="pbrush" and pba[1]==56 and pba[2]==8 then 
			change{ state="selected" } else change { state="none" } end
	elseif w.id=="paint_block" then
		local pba=paint.pbrush_area
		if paint.mode=="pbrush" and pba[1]==56 and pba[2]==0 then 
			change{ state="selected" } else change { state="none" } end
	elseif w.id=="paint_dash" then
		local pba=paint.pbrush_area
		if paint.mode=="pbrush" and pba[1]==56 and pba[2]==16 then 
			change{ state="selected" } else change { state="none" } end
	elseif w.id=="paint_line" then
		local pba=paint.pbrush_area
		if paint.mode=="pbrush" and pba[1]==56 and pba[2]==24 then 
			change{ state="selected" } else change { state="none" } end
	elseif w.id=="brushmode" then
		if paint.brushmode==w.user then change{ state="selected" } else change { state="none" } end
	elseif w.id=="color_copy" then
		if gui.color_mode=="copy" then change{ state="selected" } else change { state="none" } end
	elseif w.id=="color_swap" then
		if gui.color_mode=="swap" then change{ state="selected" } else change { state="none" } end
	elseif w.id=="color_blend" then
		if gui.color_mode=="blend" then change{ state="selected" } else change { state="none" } end
	elseif w.id=="color_select" then
		if gui.color_mode=="select" then change{ state="selected" } else change { state="none" } end
	elseif w.id=="dither_page_rgba" then
		change{ hidden=not image.grd_rgba and true or false }
	elseif w.id=="dither_page_indexed" then
		change{ hidden=image.grd_rgba and true or false }
	elseif w.id=="mainmode" then
		if w.hx and  w.hx==w.hy then --must be square		
			local idx=1
			if paint.autohand then
				idx=39
			elseif paint.mode=="scroll" then
				idx=39
			elseif paint.mode=="pickup" then
				idx=8
			elseif paint.mode=="fill" then
				idx=32
			elseif paint.mode=="pipette" then
				idx=37
			elseif paint.brushmode=="paint" then
				idx=23
			elseif paint.brushmode=="replace" then
				idx=24
			elseif paint.brushmode=="color" then
				idx=31
			end
			change{
				sheet_id=idx,
				text=false,
				sheet_over="imgs/icons",
				sheet_px=w.hx/2,
				sheet_py=w.hy/2,
				sheet_hx=w.hx*1.0,
				sheet_hy=w.hy*1.0,
			}
		end
	end
end


-- update gui data from current values
gui.data_refresh_memory=function()

	local image=images.get()

	local m=""
	local n,vcount,vmin=image.grd.history:get_memory()
	
	if n<1024*1024 then
		m=string.format("%.3f kilobytes",n/1024)
	else
		m=string.format("%.3f megabytes",n/(1024*1024))
	end

	gui.data.undo_memory:value("using "..m.." of memory",true)
	gui.data.undo_index:set(image.grd.history.index,vmin,image.grd.history.length,true)
	

end
-- update gui data from current values
gui.data_refresh=function()
	if not gui.data then return end

	local image=images.get()

	gui.data.frame_idx:set(image.grd.layers.frame+1,1,image.grd.depth)
	if image.grd.layers.count==1 then
		gui.data.layer_idx:set(0,0,0) -- no layers
	else
		gui.data.layer_idx:set(image.grd.layers.index,0,image.grd.layers.count)
	end
	
	gui.data.size_fx:value( gui.data.size_hx:value() * gui.data.size_lx:value() )
	gui.data.size_fy:value( gui.data.size_hy:value() * gui.data.size_ly:value() )

	gui.data.layer_xy:value( gui.data.layer_x:value() * gui.data.layer_y:value() )

	gui.data.layer_w:value( image.grd.width  / gui.data.layer_x:value() )
	gui.data.layer_h:value( image.grd.height / gui.data.layer_y:value() )


	local g=gui.color_fg
	gui.data.cr:value(g.r,true)
	gui.data.cg:value(g.g,true)
	gui.data.cb:value(g.b,true)
	gui.data.ca:value(g.a,true)
	gui.data.color:value( g.a*0x1000000 + g.r*0x10000 + g.g*0x100 + g.b ,true)

	gui.data.fatpix:value(      image.json and image.json.swanky and image.json.swanky.fatpix      or 3 )
	gui.data.fatpiy:value(      image.json and image.json.swanky and image.json.swanky.fatpiy      or 3 )

	gui.data_refresh_memory()

end

-- update gui widgets from current values
function gui.widget_refresh()

	if not gui.master then return end

--print("fixbuts",nohook)

-- make sure we have the right colors from the image
	gui.color_refresh(gui.color_bg)
	gui.color_refresh(gui.color_fg)
	
	gui.master:call_descendents(gui.fixup_widget)
	
	paint.act_add({
		cmd="redraw",
		})
end

function gui.color_inc(g,n)
	g=g or gui.color_fg
	gui.color_set(g,g.i+(n or 1))
	gui.data_refresh_required=true
--	gui.fixbuts()
end
function gui.color_dec(g,n)
	g=g or gui.color_fg
	gui.color_set(g,g.i-(n or 1))
	gui.data_refresh_required=true
--	gui.fixbuts()
end
-- apply the image color to the gui 
function gui.color_refresh(g)
	if not g then return end
	local p=images.get().grd:palette(0,256)
	local i=g.i
	if p and p[i*4+1] then
		g.r=p[i*4+1]
		g.g=p[i*4+2]
		g.b=p[i*4+3]
		g.a=p[i*4+4]
		g.argb=g.a*0x1000000 + g.r*0x10000 + g.g*0x100 + g.b
	end
end
function gui.color_set(g,i,nohook)
	if i>255 then i=255 end
	if i<0 then i=0 end
	g.i=i
	gui.color_refresh(g)
	gui.widget_refresh_required=true
end
function gui.set_rgba(i,r,g,b,a,nohook)
--print("set color",i,r,g,b,a,nohook)
	local p={r,g,b,a}
	paint.act_add({
		cmd="pal_begin",
	},{
		cmd="pal_set",
		args={i,1,p},
	},{
		cmd="pal_save",
	})
--	images.get().grd:palette(i,1,p)
	gui.master:call_descendents(function(w) -- this is display only
		if w.id=="color" then
			if w.user==i then
				w.color=p[4]*0x1000000 + math.floor(p[1]*p[4]/255)*0x10000 + math.floor(p[2]*p[4]/255)*0x100 + math.floor(p[3]*p[4]/255) 
			end
		end
	end)
end

function gui.load_grd(fname)
	local suc,err=xpcall(
		function() images.load_grd( fname ) end,
		function(...) print(table.concat({...,debug.traceback()},"\n")) return ... end
	)
	if suc then
		gui.widget_refresh_required=true
	else
		print(err)
		local opts={}
		opts.lines={"Error!",""}
		for _,line in ipairs(wstr.smart_wrap(tostring(err),32)) do
			opts.lines[#opts.lines+1]=line
		end
		opts.lines[#opts.lines+1]=""
		opts.sorry=function() end
		gui.show_request(opts)
	end
	
	return suc
end

function gui.save_grd(fname,overwrite)

	fname=fname or images.get_filename() -- use current filename if none given

	local do_save=function()

		local suc,err=xpcall(
			function() images.save_grd( fname ) end,
			function(...) print(table.concat({...,debug.traceback()},"\n")) return ... end
		)
		if suc then
			gui.set_infostring("File saved OK")
		else
			print(err)
			local opts={}
			opts.lines={"Error!",""}
			for _,line in ipairs(wstr.smart_wrap(tostring(err),32)) do
				opts.lines[#opts.lines+1]=line
			end
			opts.lines[#opts.lines+1]=""
			opts.sorry=function() end
			gui.show_request(opts)
		end

	end

	if not force_replace then -- need to test if file exists first
		local fp=io.open(fname,"r")
		if fp then
			fp:close()
			local fnameonly=fname:match( "([^\\/]+)$" )
			local opts={}
			opts.lines={"",fnameonly,"","File exists, replace?",""}
			opts.yes=function() do_save() end
			opts.no=function() gui.master.ids.window_save.window_hooks("win_show") end
			gui.show_request(opts)
		else
			do_save()
		end
	else
		do_save()
	end

end

function gui.export_grd(fname,force_replace)

	local do_export=function()
	
		local suc,err=xpcall(
			function() images.export_grd( fname ) end,
			function(...) print(table.concat({...,debug.traceback()},"\n")) return ... end
		)
		if suc then
			gui.set_infostring("File exported OK")
		else
			print(err)
			local opts={}
			opts.lines={"Error!",""}
			for _,line in ipairs(wstr.smart_wrap(tostring(err),32)) do
				opts.lines[#opts.lines+1]=line
			end
			opts.lines[#opts.lines+1]=""
			opts.sorry=function() end
			gui.show_request(opts)
		end

	end
	
	if not force_replace then -- need to test if file exists first
		local fp=io.open(fname,"r")
		if fp then
			fp:close()
			local fnameonly=fname:match( "([^\\/]+)$" )
			local opts={}
			opts.lines={"",fnameonly,"","File exists, replace?",""}
			opts.yes=function() do_export() end
			opts.no=function() gui.master.ids.window_save.window_hooks("win_show") end
			gui.show_request(opts)
		else
			do_export()
		end
	else
		do_export()
	end

end

	return gui
end
