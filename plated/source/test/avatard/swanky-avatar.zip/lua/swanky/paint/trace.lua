--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local wgrd   =require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")

local wzips=require("wetgenes.zips")


local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,trace)
	local trace=trace or {}
	trace.oven=oven
	
	trace.modname=M.modname

--do return trace end

	local cake=oven.cake
	local win=oven.win
	local opts=oven.opts
	local canvas=cake.canvas
	local images=cake.images
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	local framebuffers=cake.framebuffers

	local main=oven.rebake(oven.modname..".main")
	local gui=oven.rebake(oven.modname..".gui")
	local textures=oven.rebake(oven.modname..".textures")
	


trace.loads=function()

	local filename="lua/"..(oven.modname..".trace"):gsub("%.","/")..".glsl"
	gl.shader_sources( wzips.readfile(filename) , filename )

end

trace.setup=function()
	trace.loads()
	
	trace.texture_id=assert(gl.GenTexture())
	gl.ActiveTexture(gl.TEXTURE0)
	gl.BindTexture( gl.TEXTURE_2D , trace.texture_id )
	gl.TexImage2D(
		gl.TEXTURE_2D,
		0,
		gl.RGBA,
		8,
		8,
		0,
		gl.RGBA,
		gl.UNSIGNED_BYTE,string.char(0):rep(8*8*4) )
	gl.GenerateMipmap(gl.TEXTURE_2D)	
end

trace.clean=function()
end

trace.change=function(name)
	print("loading trace image "..name)

	local grd=assert(wgrd.create())
	local d=assert(wzips.readfile(name),"Failed to load "..name)
	grd:load_data(d)
	
	assert(grd:convert(wgrd.U8_RGBA_PREMULT))
	
	print(grd.width,grd.height,grd.depth,grd.format)

	gl.ActiveTexture(gl.TEXTURE0)
	gl.BindTexture( gl.TEXTURE_2D , trace.texture_id )

	gl.TexImage2D(
		gl.TEXTURE_2D,
		0,
		gl.RGBA,
		grd.width,
		grd.height,
		0,
		gl.RGBA,
		gl.UNSIGNED_BYTE,
		pack.tolightuserdata( grd.data , 0 ) )

	gl.TexParameter(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);

	gl.TexParameter(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
	gl.TexParameter(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

end

trace.draw_under=function(view,a)

	if not view then return end
	if a<0 then return end
	if a> 1 then a=1 end

	local data={
		view.pos[1],				view.pos[2],				0,		0,				0,
		view.pos[1]+view.siz[1],	view.pos[2],				0,		view.siz[1],	0,
		view.pos[1],				view.pos[2]+view.siz[2],	0,		0,				view.siz[2],
		view.pos[1]+view.siz[1],	view.pos[2]+view.siz[2],	0,		view.siz[1],	view.siz[2],
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p=gl.program("swpaint_trace_under")	
	gl.UseProgram( p[0] )

	local vertexarray
	if gl.BindVertexArray then
		vertexarray=gl.GenVertexArray()
		gl.BindVertexArray(vertexarray)
	end

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.Uniform1i( p:uniform("tex0"), 0 )

	gl.ActiveTexture(gl.TEXTURE0)
	gl.BindTexture( gl.TEXTURE_2D , trace.texture_id )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

	gl.Uniform4f( p:uniform("color"), a,a,a,a )
	
	local t=textures.get()
	local w=t.width
	local h=t.height
	local lx,ly=w,h
	if t.layers then
		if t.layers.index==0 or t.layers.count==1 then
			lx=t.layers.x
			ly=t.layers.y
			lx=math.floor(w/lx)
			ly=math.floor(h/ly)
	--		print(lx,ly)--,gui.data.layer_x:value(),gui.data.layer_y:value())
		else
			w,h=t.layers:size()
			lx,ly=w,h
		end
	end
	

	gl.Uniform4f( p:uniform("img_siz"), w,h,lx,ly )
	gl.Uniform4f( p:uniform("img_pos"), view.offset[1],view.offset[2],view.scalex,view.scaley )

	do
		local br=(gui.data and gui.data.back_r and gui.data.back_r:value() or 0)/255
		local bg=(gui.data and gui.data.back_g and gui.data.back_g:value() or 0)/255
		local bb=(gui.data and gui.data.back_b and gui.data.back_b:value() or 0)/255
		local ba=(gui.data and gui.data.back_a and gui.data.back_a:value() or 0)/255
		gl.Uniform4f( p:uniform("img_alpha_color"), br,bg,bb,1.0-ba )
	end
	gl.Uniform4f( p:uniform("img_flags"),view.grid,gui.data.snapx:value(),gui.data.snapy:value(),(main.drawframe%4096)/4096 )

	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)

	if gl.BindVertexArray then
		gl.BindVertexArray(0)
		gl.DeleteVertexArray(vertexarray)
	end

end

trace.draw_over=function(view,a)

	if not view then return end
	if a<=1 then return end
	a=a-1
	if a> 1 then a=1 end

	local data={
		view.pos[1],				view.pos[2],				0,		0,				0,
		view.pos[1]+view.siz[1],	view.pos[2],				0,		view.siz[1],	0,
		view.pos[1],				view.pos[2]+view.siz[2],	0,		0,				view.siz[2],
		view.pos[1]+view.siz[1],	view.pos[2]+view.siz[2],	0,		view.siz[1],	view.siz[2],
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p=gl.program("swpaint_trace_over")	
	gl.UseProgram( p[0] )

	local vertexarray
	if gl.BindVertexArray then
		vertexarray=gl.GenVertexArray()
		gl.BindVertexArray(vertexarray)
	end

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.Uniform1i( p:uniform("tex0"), 0 )

	gl.ActiveTexture(gl.TEXTURE0)
	gl.BindTexture( gl.TEXTURE_2D , trace.texture_id )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

	gl.Uniform4f( p:uniform("color"), a,a,a,a )
	
	local t=textures.get()
	local w=t.width
	local h=t.height
	if t.layers then
		w,h=t.layers:size()
	end
	
	gl.Uniform4f( p:uniform("img_siz"), w,h,0,0 )
	gl.Uniform4f( p:uniform("img_pos"), view.offset[1],view.offset[2],view.scalex,view.scaley )

	gl.Uniform4f( p:uniform("img_flags"),view.grid,gui.data.snapx:value(),gui.data.snapy:value(),(main.drawframe%4096)/4096 )

	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)

	if gl.BindVertexArray then
		gl.BindVertexArray(0)
		gl.DeleteVertexArray(vertexarray)
	end

end

trace.draw_grid=function(view)

	if not view then return end

	local data={
		view.pos[1],				view.pos[2],				0,		0,				0,
		view.pos[1]+view.siz[1],	view.pos[2],				0,		view.siz[1],	0,
		view.pos[1],				view.pos[2]+view.siz[2],	0,		0,				view.siz[2],
		view.pos[1]+view.siz[1],	view.pos[2]+view.siz[2],	0,		view.siz[1],	view.siz[2],
	}

	local datalen=#data
	local datasize=datalen*4 -- we need this much vdat memory
	canvas.vdat_check(datasize) -- make sure we have space in the buffer
	
	pack.save_array(data,"f32",0,datalen,canvas.vdat)

	local p=gl.program("swpaint_trace_grid")	
	gl.UseProgram( p[0] )

	local vertexarray
	if gl.BindVertexArray then
		vertexarray=gl.GenVertexArray()
		gl.BindVertexArray(vertexarray)
	end

	gl.BindBuffer(gl.ARRAY_BUFFER,canvas.get_vb())
	gl.BufferData(gl.ARRAY_BUFFER,datasize,canvas.vdat,gl.DYNAMIC_DRAW)

	gl.Uniform1i( p:uniform("tex0"), 0 )

	gl.ActiveTexture(gl.TEXTURE0)
	gl.BindTexture( gl.TEXTURE_2D , trace.texture_id )

	gl.UniformMatrix4f(p:uniform("modelview"), gl.matrix(gl.MODELVIEW) )
	gl.UniformMatrix4f(p:uniform("projection"), gl.matrix(gl.PROJECTION) )

--	local a=gui.data.trace_alpha:value()/255
--	gl.Uniform4f( p:uniform("color"), a,a,a,a )
	
	local t=textures.get()
	local w=t.width
	local h=t.height
	if t.layers then
--		w,h=t.layers:size()
		local _,_,_,lw,lh,_=t.layers:area()
		w,h=lw,lh
	end
	
	gl.Uniform4f( p:uniform("img_siz"), w,h,0,0 )
	gl.Uniform4f( p:uniform("img_pos"), view.offset[1],view.offset[2],view.scalex,view.scaley )

	gl.Uniform4f( p:uniform("img_flags"),view.grid,gui.data.snapx:value(),gui.data.snapy:value(),(main.drawframe%4096)/4096 )

	gl.Uniform4f( p:uniform("img_lines"), view.lines[1],view.lines[2],view.lines[3],view.lines[4] )
	
	local c=math.abs((main.drawframe%64)-32)/32
	c=((c*c)/2)+0.25
	gl.Uniform4f( p:uniform("img_line_color"), c,c,c,1 )

	gl.VertexAttribPointer(p:attrib("a_vertex"),3,gl.FLOAT,gl.FALSE,20,0)
	gl.EnableVertexAttribArray(p:attrib("a_vertex"))
	
	gl.VertexAttribPointer(p:attrib("a_texcoord"),2,gl.FLOAT,gl.FALSE,20,12)
	gl.EnableVertexAttribArray(p:attrib("a_texcoord"))

	gl.DrawArrays(gl.TRIANGLE_STRIP,0,4)

	if gl.BindVertexArray then
		gl.BindVertexArray(0)
		gl.DeleteVertexArray(vertexarray)
	end

end

	return trace
end
