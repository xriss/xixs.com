--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math

local wgrd   =require("wetgenes.grd")
local wgrdmap=require("wetgenes.grdmap")
local wgrdpaint=require("wetgenes.grdpaint")
local wgrdsvg=require("wetgenes.grdsvg")

local zips=require("wetgenes.zips")


local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,image)
	local image=image or {}
	image.oven=oven
	
	image.modname=M.modname

	local cake=oven.cake
	local win=oven.win
	local opts=oven.opts
	local canvas=cake.canvas
	local images=cake.images
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	local framebuffers=cake.framebuffers
	
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")

	local gui=oven.rebake(oven.modname..".gui")
	local main=oven.rebake(oven.modname..".main")
	local textures=oven.rebake(oven.modname..".textures")
--	local gfile=oven.rebake("swanky.gui_file")
	local paint=oven.rebake(oven.modname..".main_paint")
	local swimages=oven.rebake(oven.modname..".images")


	image.wrap=false
	image.modified=false

image.save_grd=function(name)

	image.filename=name

	image.modified=false
--[[
	if image.spare then -- stop being spare if we save the image?
		image.spare=false
		swimages.spare_idx=nil
	end
]]

	local dest
	if type(name)=="table" then
		dest=name
		name=dest.name
	else
		dest={}
		dest.name=name
	end

	dest.g=image.grd

	if name and image.grd  then
		local undo=image.grd.history:save()
		assert(dest.g:save({filename=name,json=image.json,undo=undo}))
print("save",name,#undo)
	end
	
	return dest
end

image.export_grd=function(name)

	local dest
	if type(name)=="table" then
		dest=name
		name=dest.name
	else
		dest={}
		dest.name=name
	end

-- save as history animation
	if ( name and name:sub(-12)==".history.gif" ) or ( name and name==".HISTORY.GIF" ) then
print("HISTORY.GIF export",name)
		if image.grd and image.grd.history then -- sanity
	
			local sx,sy=gui.data.fatpix:value(),gui.data.fatpiy:value()

			local history=image.grd.history
			local ga=image.grd

			local getpal=function(g) -- get a modified palette from this grd
				local p=g:palette(0,256)
				for j=0,255*4,4 do
					p[j+4]=255 -- set all colors to not transparent as gif are not so happy and with such things really
				end
				return p
			end

-- make base empty image to start stream with

			local n,vcount,vmin=history:get_memory()
			

			local oldidx=history.index

			local hx=1
			local hy=1
			
			for i=vmin,history.length do -- work out the maximum size of image we need to export
				history:goto(i)
				local ax,ay,az,bx,by,bz=history.grd.layers:area(1)
				if bx>hx then hx=bx end
				if by>hy then hy=by end
			end

			local gb=wgrd.create(wgrd.U8_INDEXED,hx*sx,hy*sy,1)
			gb:palette(0,256,getpal(ga))
			local stream=gb:stream({filename=name})

			for idx=vmin,history.length+16 do -- iterate over frames holding the last frame for a while

--print(idx.."/"..history.length)
				local i=idx
				if i>history.length then i=history.length end -- hold the last frame
				history:goto(i)
				
				local gc=history.grd.layers:flatten_frame()

				local gb=wgrd.create(wgrd.U8_INDEXED,hx,hy,1)
				gb:palette(0,256,getpal(gc))

--print(history.grd.layers.frame,history.grd.depth)
if history.grd.layers.frame >= history.grd.depth then history.grd.layers.frame = history.grd.depth-1 end -- bug hax fix
if history.grd.layers.frame < 0 then history.grd.layers.frame = 0 end

				gb:pixels(0,0,0,gc.width,gc.height,1,gc)
				gb:scale(gb.width*sx,gb.height*sy,gb.depth) -- scale up
				
				stream:write(gb)
			end
			stream:close()

			history:goto(oldidx) -- return to original point in history
			
		end		
		return dest
	end


	if ( name and name:sub(-4)==".svg" ) or ( name and name==".SVG" ) then
	
print("SVG export",name)

		local d=wgrdsvg.string(image.grd,{
			skip_transparent_pixels=true,
			scalex=gui.data.fatpix:value(),
			scaley=gui.data.fatpiy:value(),
		})

		local fp=io.open(name,"wb")
		fp:write(d)
		fp:close()
	
		return dest
	end


	if image.grd  and image.grd.depth>1 or name==".GIF" then -- animations can only fatpixel
		local ga=image.grd
		local gb=image.layers_flat() -- assert(wgrd.create(ga))
		gb:scale(gb.width*gui.data.fatpix:value(),gb.height*gui.data.fatpiy:value(),gb.depth)
		gb:palette(0,256,ga:palette(0,256)) -- copy cmap which got lost in the scale (BUG)
		
		dest.g=gb
		
	elseif image.grd  then
	
		local g=image.grd
		local lw,lh=image.grd.layers:size()
		local v={
			scalex=gui.data.fatpix:value(),
			scaley=gui.data.fatpiy:value(),
			offset={0,0},
			siz={lw,lh},
			pos={0,0},
			grid=0,
			lines={-1,-1,-1,-1},
		}
		v.siz[1]=v.siz[1]*v.scalex
		v.siz[2]=v.siz[2]*v.scaley
		v.export=true
		
		local fbo=framebuffers.create(v.siz[1],v.siz[2],0)

			fbo:bind_frame()
			cake.views.push_and_apply_fbo(fbo)

			gl.MatrixMode(gl.PROJECTION)
			gl.PushMatrix()
			gl.MatrixMode(gl.MODELVIEW)
			gl.PushMatrix()

			gl.ClearColor(0,0,0,0)
			gl.Clear(gl.COLOR_BUFFER_BIT+gl.DEPTH_BUFFER_BIT)

-- draw...
	textures.get().draw(v)
	if gui.data.bloom:value() > 0 then -- add bloom effect
		textures.get().draw_bloom(v)
	end


			gl.BindFramebuffer(gl.FRAMEBUFFER, 0)

			gl.MatrixMode(gl.PROJECTION)
			gl.PopMatrix()			
			gl.MatrixMode(gl.MODELVIEW)
			gl.PopMatrix()
			
		cake.views.pop_and_apply()
			
		dest.g=fbo:download()
	end

	if dest.g then
		if name and name~=".GIF" then -- fileout
			assert(dest.g:save({filename=name}))
print("export",name)
		end
	end
	
	return dest
end

image.new_grd=function(gwidth,gheight,gdepth)

print("new",gwidth,gheight,gdepth)

	if not gdepth or gdepth<1 then gdepth=1 end
	
	if gwidth and gwidth>1 and gheight and gheight>1 then
--print(gwidth,gheight)
		image.load_grd(nil,gwidth,gheight,gdepth)
	end
end

-- pick a new palette
image.adjust_pal=function(count)
	if image.grd_rgba then
		local g=image.grd_rgba:duplicate()

		g:adjust_rgb(gui.data.dither_adjust_red:value()/100,gui.data.dither_adjust_grn:value()/100,gui.data.dither_adjust_blu:value()/100)
		g:adjust_hsv(gui.data.dither_adjust_hue:value()    ,gui.data.dither_adjust_sat:value()/100,gui.data.dither_adjust_val:value()/100)
		g:adjust_contrast(128,gui.data.dither_contrast:value()/100)

		g:quant(count,0)
		g:sort_cmap()
		
		image.set_grd(g)
	end
end

-- apply the current gui color adjustment and convert to an editable image
image.adjust_grd=function(final)
	if image.grd_rgba then
		local g

		if final then -- are we keeping the original RGBA ?
			g=image.grd_rgba
			image.grd_rgba=nil
		else
			g=image.grd_rgba:duplicate()
			g.image=image
		end
		

		local scale=gui.data.dither_scale:value()
		local w=math.floor(0.5+(g.width* scale/100))
		local h=math.floor(0.5+(g.height*scale/100))
		local d=g.depth
--		if w~=g.width or h~=g.height then -- scale
			g:scale(w,h,d)
			image.grd:resize(w,h,d)
--		end

		g:adjust_rgb(gui.data.dither_adjust_red:value()/100,gui.data.dither_adjust_grn:value()/100,gui.data.dither_adjust_blu:value()/100)
		g:adjust_hsv(gui.data.dither_adjust_hue:value()    ,gui.data.dither_adjust_sat:value()/100,gui.data.dither_adjust_val:value()/100)
		g:adjust_contrast(128,gui.data.dither_contrast:value()/100)

		local wpr=gui.master and gui.master.ids and gui.master.ids.process_show
		if wpr and wpr.state=="selected" or final then

			g:remap(image.grd,0,gui.data.dither_patterns:value())
			textures.get().upload(image.grd,image.grd.layers.frame)

		else
			textures.get().upload(g,image.grd.layers.frame)
		
		end

		
		image.layers_config()
				
		if final then
			image.pick_fgbg()
		end
	end
end

image.load_grd=function(name,gwidth,gheight,gdepth)

	image.modified=false
	image.grd_rgba=false -- flag that this is not an indexed image

	local source
	if type(name)=="table" then
		source=name
		name=source.name
	else
		source={}
		source.name=name
	end

	local loaded={} -- where to load
		
	if name then
		local g=assert(wgrd.create())
		local d=assert(zips.readfile(name),"Failed to load "..name)
		if assert(g:load_data(d)) then
			loaded.json=g.json
			loaded.undo=g.undo
			loaded.grd=g
			loaded.grd.image=image
			loaded.filename=name
			g.undo=nil
		end
	elseif source.data then -- load data
		local g=assert(wgrd.create())
		if assert(g:load_data(source.data)) then
			loaded.json=g.json
			loaded.undo=g.undo
			loaded.grd=g
			loaded.filename=source.name or paint.basedir.."/"..os.date("s%Y%m%dp%H%M%S.png")
			g.undo=nil
		end
	end
	
	if not loaded.grd then -- create default
		loaded.filename=paint.basedir.."/"..os.date("s%Y%m%dp%H%M%S.png")
		loaded.grd=assert(wgrd.create(wgrd.U8_INDEXED,gwidth,gheight,gdepth or 1))
		loaded.grd:clear(0)
		for i=0,255 do
			loaded.grd:palette(i,1,{0x00,0x00,0x00,0x00})
		end
		
		
		loaded.json={swanky={}}
		
		local preset_name=gui.get_list("presets") or ""
		local palette_name=gui.get_list("palettes") or ""

		local preset=gui.presets and gui.presets.presets  and gui.presets.presets[preset_name]
		local colors=gui.presets and gui.presets.palettes and gui.presets.palettes[palette_name]

		if preset then
			for n,v in pairs(preset) do
				loaded.json.swanky[n]=v
			end
--			loaded.json.fatpix=preset.fatpix
--			loaded.json.fatpiy=preset.fatpiy
--			gui.data.fatpix:value(      preset.fatpix      or 3)
--			gui.data.fatpiy:value(      preset.fatpiy      or 3)
		end
		
		if colors then
			loaded.grd:palette(0,#colors/4,colors)
		else -- swanky32 default

			loaded.grd:palette(0,32,swimages.swanky32_colors)
		end

--		loaded.layer_xy={x=gui.data and gui.data.layer_x:value(),y=gui.data and gui.data.layer_y:value()}
			
	end
	
	if not loaded.grd.cmap then -- remap
		loaded.grd_rgba=loaded.grd:convert(wgrd.U8_RGBA) -- flag this as an rgba image and force 32bit
		loaded.grd_rgba.image=image

		local g=loaded.grd_rgba
		local r=wgrd.create(wgrd.U8_INDEXED,g.width,g.height,g.depth)
		r:palette(0,32,swimages.swanky32_colors)
		loaded.grd=r

		if gui.master and gui.master.ids.window_dither then
			gui.master.ids.window_dither.window_hooks("win_show") -- show dither window
		end

	end

-- copy from loaded into image (the above code may have asserted so this keeps things clean)

	image.filename=loaded.filename
	image.json=loaded.json
	image.set_grd(loaded.grd)
	image.grd.layers.frame=loaded.frame or 0
	image.grd_rgba=loaded.grd_rgba
	
	if loaded.undo then
--		print("loaded.undo",#loaded.undo)
		image.grd.history:load(loaded.undo)
	end
	
	if image.grd_rgba then image.adjust_grd() end	
--	if gui.data then image.layers_config(loaded.layer_xy) end

-- and finish setup

	gui.image_refresh_required=true
	gui.data_refresh_required=true
	gui.widget_refresh_required=true

	image.layers_config()
	
	image.pick_fgbg()

	if not loaded.undo then -- set starting history json state 
		image.grd.history:draw_begin(0,0,0,1,1,1)
		image.grd.history:draw_save(loaded.json)
		image.grd.history:draw_end()
	end

	image.set_json_data(nil,true) -- this will fix the layers without adjusting the gui values

end

-- set a grd, this will destroy all undo history
image.set_grd=function(g)

	image.grd=g
	image.grd.image=image -- keep custom the link back to image

-- wrap this grd with extra state or use what it already has
	if not g.history then wgrdpaint.history(g) end
	if not g.layers  then wgrdpaint.layers(g) end
	if not g.canvas  then wgrdpaint.canvas(g) end
	
-- force removal of all undo history
	image.grd.history:reset()

	return g
end

-- set a grd and perform data rejiggle and texture update 
image.force_grd=function(g)
	image.set_grd(g)
	gui.image_refresh_required=true
	image.layers_config()
end

-- apply configuraton to current layer settings
image.layers_config=function(opts)
	opts=opts or {}
	image.grd.layers:config(opts.x,opts.y,opts.count)
end
image.layers_update=function(opts)
end
-- get a temporary grd clipped to this layer (TODO: to fix args)
image.layers_grd=function(idx,grd,frame)
	grd=grd or image.grd
	return grd:clip(image.grd.layers:area(idx,frame))
end
image.layers_area=function(idx,grd,frame)
	return image.grd.layers:area(idx,frame)
end
-- get a grd of all layers merged
image.layers_flat=function()
	return image.grd.layers:flatten_grd()
end

image.pick_fgbg=function(bg,fg)

	local ps=image.grd:palette(0,image.grd.colors)
	local function best(p)
		local b=0
		local d=256*256*4*4
		for i=0,image.grd.colors-1 do
			local d1=ps[1+i*4]-p[1]
			local d2=ps[2+i*4]-p[2]
			local d3=ps[3+i*4]-p[3]
			local d4=ps[4+i*4]-p[4]
			local dd=d1*d1+d2*d2+d3*d3+d4*d4*2
			if dd<d then
				d=dd
				b=i
			end
		end
		return b
	end
				
	bg=bg or {0,0,0,0}
	fg=fg or {255,255,255,255}

	if gui.color_bg and gui.color_fg then
		gui.color_set(gui.color_bg,best(bg))
		gui.color_set(gui.color_fg,best(fg))
	end
end

image.loads=function()


end

image.setup=function()

	image.new_grd(64,64,1) -- 64,64 default image
	image.grd.layers.frame=0
	
end

image.resize=function(w,h,d)
	image.grd:resize(w,h,d)
	image.layers_config()
-- force removal of all undo history
	image.grd.history:reset()
end

image.relayer=function(x,y,count)

	image.layers_config({x=x,y=y,count=count})

end


image.clean=function()

	if image.spare then -- the spare has been deleted?
		image.spare=false
		swimages.spare_idx=nil
	end

end

image.msg=function(m)

--	if m.class=="mouse" then
--		image.mx=m.x
--		image.my=m.y
--	end

end



image.update=function()
end

image.draw=function(view)
end


local image_simple_data_copy_names={
		"escher",
		"grid",
		"bloom",
		"snapx","snapy",
		"fatpix","fatpiy",
		"colors",
		"attr_width","attr_height","attr_redux","attr_sub","attr_back",
		"wrap_active",
		"zoom_idx",
		"focus_x","focus_y",
	}


-- these settings should be saved alongside the image data as they are
-- related I'm going to squirt them into a PNG text chunk tagged as JSON
-- which I think covers us,
-- after all with APNG support then PNG is the only format we really need...

-- get a json structure of the current image GUI values
-- pass in a table to update/merge it
image.get_json_data=function(json,ignore)
	ignore=ignore or {}
	json=json or image.json or {}
	if type(json)~="table" then print("badjson : "..tostring(json)) json={} end
	image.json=json
	json.swanky=json.swanky or {} --  use a swanky subtable incase anyone else wants to use the JSON tag...
	local it=json.swanky -- fill this in
	
	-- merge file history
--	it.file_history=it.file_history or {}
--	for n,v in pairs(gui.data.file_history) do
--		it.file_history[n]=v
--	end

	-- read basic values
	for i,v in ipairs(image_simple_data_copy_names) do
		if not ignore[v] then -- ignore these ones
			if gui.data and gui.data[v] then
				it[v]=gui.data[v]:value()
--print("SAVE",v,it[v])
			else
				print("warning unknown data value called "..v)
			end
		end
	end
	
	
-- save layers and frame info
	it.layer_x=image.grd.layers.x
	it.layer_y=image.grd.layers.y
	it.layer_index=image.grd.layers.index
	it.layer_count=image.grd.layers.count
	it.frame_index=image.grd.layers.frame

	return json
end

-- set GUI values from a previously saved json structure
image.set_json_data=function(json,ignore)
	ignore=ignore or {}
	json=json or image.json
	local it=json and json.swanky or {}

--print(wstr.dump(it))
	-- merge file history
--	for n,v in pairs(it.file_history or {}) do
--		gui.data.file_history[n]=v
--	end

	-- read basic values
	if type(ignore)=="table" then
		for i,v in ipairs(image_simple_data_copy_names) do
			if not ignore[v] then -- ignore these ones
				if (type(it[v])~="nil") and gui.data and gui.data[v] then
					gui.data[v]:value(it[v],false)
	--print("LOAD",v,it[v])
				end
			end
		end
	else
		ignore={}
	end
	
-- load layers and frame info
	if it.layer_x and not ignore.layer_x then image.grd.layers.x=math.floor(it.layer_x) end
	if it.layer_y and not ignore.layer_y then image.grd.layers.y=math.floor(it.layer_y) end 
 	if it.layer_count and not ignore.layer_count then
		image.grd.layers.count=math.floor(it.layer_count)
 	elseif it.layer_x and it.layer_y and not ignore.layer_x and not ignore.layer_y then
		image.grd.layers.count=math.floor(it.layer_x)*math.floor(it.layer_y)
	end
	if it.layer_index and not ignore.layer_index then image.grd.layers.index=math.floor(it.layer_index) end
	if it.frame_index and not ignore.frame_index then image.grd.layers.frame=math.floor(it.frame_index) end

	if image.grd.layers.index>image.grd.layers.count then image.grd.layers.index=image.grd.layers.count end
	if image.grd.layers.index<0 then image.grd.layers.index=0 end
	if image.grd.layers.frame>=image.grd.depth then image.grd.layers.frame=image.grd.depth-1 end
	if image.grd.layers.frame<0 then image.grd.layers.frame=0 end
end



	return image
end
