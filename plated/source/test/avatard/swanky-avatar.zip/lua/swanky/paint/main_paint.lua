--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local bit=require("bit")
local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local wgrd=require("wetgenes.grd")
local wgrdpaint=require("wetgenes.grdpaint")
local zips=require("wetgenes.zips")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wsbox=require("wetgenes.sandbox")
local _,lfs=pcall( function() return require("lfs") end )



local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,paint)
	local paint=paint or {}
	paint.oven=oven
	
	paint.modname=M.modname

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets
	
--	local sgui=oven.rebake("wetgenes.gamecake.spew.gui")

	local main=oven.rebake(oven.modname..".main")
	local textures=oven.rebake(oven.modname..".textures")
	local bloom=oven.rebake(oven.modname..".bloom")
	local views=oven.rebake(oven.modname..".views")
	local images=oven.rebake(oven.modname..".images")
	local gui=oven.rebake(oven.modname..".gui")
	local trace=oven.rebake(oven.modname..".trace")
	local uvmap=oven.rebake(oven.modname..".uvmap")



paint.loads=function()

	textures.loads()
	if bloom.loads then
		bloom.loads()
	end
end
		
paint.setup=function()

local loadpng
local setcd
	if not paint.done_setup then

		paint.file_history={} -- a list of recently used dirs for fast switch in file requester

		local dd="./"
		
		if lfs and lfs.currentdir then
			local t=(lfs.currentdir()) -- add current dir to history
			if t then
				paint.file_history[t]=true
			end

			for i,v in ipairs(oven.opts.args) do -- add passed in values to file history if they end with a /
				if "--"~=v:sub(1,2) then
					if v:sub(-1)=="/" then
						paint.file_history[v:sub(1,-2)]=true -- skip trailing slash
						setcd=v
					elseif v:sub(-4)==".png" then
						loadpng=v
						setcd=v:match("(.-)([^\\/]-%.?([^%.\\/]*))$")
					end
				end
			end

		end
		
		if wwin.flavour=="nacl" then -- nofilesystem
		
		elseif wwin.flavour=="android" then -- android locations are a bit poopy
		
			dd="/sdcard/Pictures/swankypaint"
			if lfs then lfs.mkdir(dd) end
			
			paint.file_history[dd]=true
			paint.file_history["/sdcard/Pictures"]=true
			paint.file_history["/sdcard"]=true

		else

			if oven.homedir then
				dd=oven.homedir.."Pictures/swankypaint" -- if we already have a Pictures then add a swankypaint
				if lfs then lfs.mkdir(dd) end
				
				paint.file_history[dd]=true
				paint.file_history[oven.homedir.."Pictures"]=true
				paint.file_history[oven.homedir.."Desktop"]=true
			end

		end
		
		paint.basedir=setcd or dd
		paint.basepath=paint.basedir.."/"..os.date("s%Y%m%dp%H%M%S.png") -- string.format("px%08x.png",os.time())

-- single setup
		textures.setup()
		if bloom.setup then
		bloom.setup()
		end
		images.setup()
		views.setup()

		local loaded_png=false
		if loadpng then
			images.get().load_grd(loadpng)
			loaded_png=true
		end
		if not loaded_png then
			local image=images.get()
			image.load_grd(oven.opts.splash)
			image.force_grd( image.grd.layers:flatten_frame(0) )
			image.modified="repme"
			image.filename=paint.basepath
		end

		paint.act_add({cmd="begin"})
		paint.act_add({cmd="end"})
		
		paint.done_setup=true
	end
	
	local fname="data/imgs/pbrush.png"
	local g=assert(wgrd.create())
	local d=assert(zips.readfile(fname),"Failed to load "..fname)
	assert(g:load_data(d,"png")) -- skip extension period

	paint.pbrush=g
	paint.pbrush_area={0,0,8,8}

	paint.brush=wgrd.create() -- make sure we always have a brush
	paint.brushmode="paint"
--	paint.brush_undo=paint.brush -- snapshot to revert brush

	paint.grd_temp=paint.grd_temp or wgrd.create(wgrd.U8_INDEXED,1,1,1)
	paint.grd_undo=paint.grd_undo or wgrd.create(wgrd.U8_INDEXED,1,1,1)
	paint.grd_spare=paint.grd_spare or wgrd.create(wgrd.U8_INDEXED,1,1,1)

	paint.x=0
	paint.y=0
	paint.hx=0.5 -- handle
	paint.hy=0.5
	paint.set_pbrush("dot")
	
	paint.snap=false

	
	paint.area={x=0,y=0,w=256,h=256}
	
	gui.setup()
	

	gui.image_refresh_required=true

	trace.setup()
	uvmap.setup()
	if paint.setup_conf then
		paint.configure(paint.setup_conf)
		paint.setup_conf=nil
	end
end

paint.clean=function()

	textures.clean()
	views.clean()
	images.clean()
	trace.clean()
	uvmap.clean()
end



paint.configure=function(conf)

	if type(conf)=="string" then conf=wsbox.lson(conf) end
	
	if not paint.done_setup then -- save for recall after we are setup
		paint.setup_conf=conf
		return
	end

	if conf.pix then
		images.new_grd( conf.pix.width , conf.pix.height , conf.pix.depth )

		gui.data.fatpix:value(conf.fat.width)
		gui.data.fatpiy:value(conf.fat.height)
		gui.data.bloom:value(conf.fat.bloom)
		gui.data.escher:value(conf.fat.escher or "pixel" ) -- can choose strange pixels
		
		local g=images.get().grd
		
		local p=conf.pal
		local t={}
		for i=1,256 do
			local c=p[i] or 0
			t[#t+1]=bit.band(bit.rshift(c,16),0xff)
			t[#t+1]=bit.band(bit.rshift(c, 8),0xff)
			t[#t+1]=bit.band(c,0xff)
			t[#t+1]=bit.band(bit.rshift(c,24),0xff)
		end
		g:palette(0,256,t)
		
		gui.color_set(gui.color_bg,0)
		gui.color_set(gui.color_fg,1)
	end
	
	gui.widget_refresh()
	gui.side_page_next="tools"
	
	if paint.setup_load_this_img then
		images.load_grd(paint.setup_load_this_img)
		paint.setup_load_this_img=nil
	else
		paint.act_add({cmd="begin"})
		paint.act_add({cmd="clear"})
		paint.act_add({cmd="end"})
	end

end



paint.msg=function(m)

	if m.class=="close" then
--		gui.side_page_next="quit"
		gui.show_quit_request()
	end

	if not views.grabmouse then
		if gui.msg(m) then
			if paint.inside or paint.preview then
				paint.preview=false
				paint.inside=false
				gui.image_refresh_required=true
			end
			return
		end
	end
	if not gui.master.menu then
		if views.msg(m) then return end
	else
		if paint.inside or paint.preview then
			paint.preview=false
			paint.inside=false
			gui.image_refresh_required=true
		end
	end
end


local pclip=function(g,px,py,hx,hy,ps)

	pcall(function()
		g:pixels(px,py,hx,hy,ps)
	end)
end



paint.set_pbrush=function(n)

	local pba=paint.pbrush_area

	if n=="dot" then
		paint.mode="pbrush"
		pba[1]=0
		pba[2]=0
		pba[3]=8
		pba[4]=8
	elseif n=="block" then
		paint.mode="pbrush"
		pba[1]=56
		pba[2]=0
		pba[3]=8
		pba[4]=8
	elseif n=="circle" then
		paint.mode="pbrush"
		pba[1]=56
		pba[2]=8
		pba[3]=8
		pba[4]=8
	elseif n=="dash" then
		paint.mode="pbrush"
		pba[1]=56
		pba[2]=16
		pba[3]=8
		pba[4]=8
	elseif n=="line" then
		paint.mode="pbrush"
		pba[1]=56
		pba[2]=24
		pba[3]=8
		pba[4]=8
	elseif n=="shrink" then
		paint.mode="pbrush"
		if pba[1]>0 then pba[1]=pba[1]-8 end
		if pba[1]<0 then pba[1]=0 end
	elseif n=="grow" then
		paint.mode="pbrush"
		if pba[1]<56 then pba[1]=pba[1]+8 end
		if pba[1]>56 then pba[1]=56 end
	elseif n=="prev" then
		paint.mode="pbrush"
		if pba[2]>0 then pba[2]=pba[2]-8 end
		if pba[2]<0 then pba[2]=0 end
	elseif n=="next" then
		paint.mode="pbrush"
		if pba[2]<24 then pba[2]=pba[2]+8 end
		if pba[2]>24 then pba[2]=24 end
	end

	gui.widget_refresh()
end

local mouse_down=false
paint.msg_mouse=function(m,info)

	local img=images.get()
--	local ga=img.grd.layers_grd()
--	local gb=paint.grd
	local pba=paint.pbrush_area
	local dirty={grd=img.grd,frame=img.grd.layers.frame}
	
--	gb:resize(ga.width,ga.height,1)

	paint.x=info.x
	paint.y=info.y
	
	local _,_,_,lw,lh,_=img.grd.layers:area()
--	local lw,lh=img.grd.layers.size()
	if paint.x>=0 and paint.y>=0 and paint.x<lw and paint.y<lh then
		if not paint.inside then
			gui.image_refresh_required=true
			paint.inside=true
		end
	else
		if paint.inside or paint.preview then
			paint.preview=false
			paint.inside=false
			gui.image_refresh_required=true
		end
	end

--print(m.keyname)

	if m.class=="mouse" then

--if m.action==-1 then dprint(m) end

		if m.keyname=="wheel_add" or m.keyname=="wheel_sub" then -- scroll buttons hack to create fake clicks
			if m.action==-1 then
				if m.keyname=="wheel_add" then
					gui.hooks("click",{id="magnify"})
				else
					gui.hooks("click",{id="magnify_right"})
				end
			end
			return -- and be ignored
		end

		if paint.inside then
			gui.infomode="mouse" -- display mouse
		end
		
		local function clearlines()
			for i=1,2 do local v=views[i]
				v.lines[1]=-1
				v.lines[2]=-1
				v.lines[3]=-1
				v.lines[4]=-1
			end
		end
		if paint.mode~="pickup" then
			clearlines()
		end

		if m.action==1 then
			mouse_down=m.keyname
			views.grabmouse=true -- paint has claimed all future mouse msgs
		end
		if m.action==-1 then
			views.grabmouse=false
		end

local function add_begin()
	if not paint.down then
		paint.down=true
		paint.act_add({cmd="begin"})
	end
end
local function add_end()
	if paint.down then
		paint.down=false
		paint.act_add({cmd="end"})
	end
end
		
		
		local pm={wgrd.PAINT_MODE_TRANS,gui.color_bg.i,gui.color_fg.i}

		if paint.brushmode=="paint" then
			pm[1]=wgrd.PAINT_MODE_TRANS
		elseif paint.brushmode=="color" then
			pm[1]=wgrd.PAINT_MODE_COLOR
		elseif paint.brushmode=="replace" then
			pm[1]=wgrd.PAINT_MODE_COPY
		end

		if mouse_down=="right" then -- right button
			pm[1]=wgrd.PAINT_MODE_COLOR
			pm[3]=pm[2]
		end

		if paint.snap then
			paint.x=math.floor(0.5+(paint.x/gui.data.snapx:value()))*gui.data.snapx:value()
			paint.y=math.floor(0.5+(paint.y/gui.data.snapy:value()))*gui.data.snapx:value()
		end
		
		if paint.mode=="scroll" or
			info.view==views[2] or -- miniview
			paint.autohand or -- spacebar
			(info.m.class=="mouse" and info.m.keyname=="middle") or  -- middle mouse
			img.grd_rgba then -- a 32bit image can only scroll

			local v=paint.scroll and paint.scroll[3] or info.view
			local vx=((info.m.x-v.pos[1])/v.scalex)
			local vy=((info.m.y-v.pos[2])/v.scaley)
			
			if paint.preview then
				paint.act_add({
					cmd="redraw",
					})
				paint.preview=false
			end
			if m.action==1 and not paint.scroll then
				paint.scroll={vx,vy,v,paint.mode}
				paint.mode="scroll"
			end
			if paint.scroll then
				local ps=paint.scroll
				local dx=vx-ps[1]
				local dy=vy-ps[2]
				ps[1]=vx
				ps[2]=vy
				gui.data.focus_x:value( gui.data.focus_x:value()-dx )
				gui.data.focus_y:value( gui.data.focus_y:value()-dy )
--				for i=1,2 do
--					views[i].focus[1]=views[i].focus[1]-dx
--					views[i].focus[2]=views[i].focus[2]-dy
--				end
			end
			if m.action==-1 and paint.scroll then
				paint.mode=paint.scroll[4] -- restore previous mode
				paint.scroll=nil
			end
			
		elseif paint.mode=="pipette" and paint.inside then
			if paint.preview then
				paint.act_add({
					cmd="redraw",
					})
				paint.preview=false
			end
			if mouse_down then
				local t,p=pcall(function() return img.layers_grd(nil,nil,img.grd.layers.frame):pixels(paint.x,paint.y,0,1,1,1) end)
				if t and p and #p==1 then -- index
					if m.keyname=="right" then
						gui.color_set(gui.color_bg,p[1])
					elseif m.keyname=="left" then
						gui.color_set(gui.color_fg,p[1])
					end
				end
			end
			if m.action==-1 then
				paint.set_pbrush("dot")
			end
		elseif paint.mode=="pickup" then
			if paint.preview then
				paint.act_add({
					cmd="redraw",
					})
				paint.preview=false
			end
			if m.action==1 then
				paint.pickup={paint.x,paint.y,paint.x,paint.y}
				for i=1,2 do local v=views[i]
					v.lines[1]=paint.x
					v.lines[2]=paint.y
				end
			elseif m.action==-1 and paint.pickup then
				local pp=paint.pickup
				pp[3]=paint.x
				pp[4]=paint.y
				paint.mode="brush"
				
				paint.hx=1 -- brush handle
				paint.hy=1
				
				if pp[3]<pp[1] then
					pp[3],pp[1]=pp[1],pp[3]
					paint.hx=0
				end
				if pp[4]<pp[2] then
					pp[4],pp[2]=pp[2],pp[4]
					paint.hy=0
				end
				pp[3]=1+pp[3]-pp[1]
				pp[4]=1+pp[4]-pp[2]
				
				if paint.snap then
					pp[3]=pp[3]-1
					pp[4]=pp[4]-1
				end
				
				-- clip
				if pp[1] < 0 then
					pp[3]=pp[3]+pp[1]
					pp[1]=0
				end
				if pp[2] < 0 then
					pp[4]=pp[4]+pp[2]
					pp[2]=0
				end
				
				local _,_,_,aw,ah,ad=img.grd.layers:area()
				if pp[1]+pp[3] > lw then
					pp[3]=aw-pp[1]
				end
				if pp[2]+pp[4] > lh then
					pp[4]=ah-pp[2]
				end
				
				if pp[3]>=0 and pp[4]>=0 then -- only if something to pickup
				
					local bclear=(m.keyname=="right")
					paint.act_add({cmd="begin"})
					paint.act_add({
						cmd="pickup",
						args={pp[1],pp[2],pp[3],pp[4],bclear},
						})
					paint.act_add({cmd="end"})

				end
				
				clearlines()
				gui.widget_refresh()
			else
				for i=1,2 do local v=views[i]
					v.lines[3]=paint.x
					v.lines[4]=paint.y
				end
			end
		elseif paint.mode=="brush" then
			if not paint.brush then paint.set_pbrush("dot") else
				local x=paint.x-math.floor((paint.brush.width-1)*paint.hx)
				local y=paint.y-math.floor((paint.brush.height-1)*paint.hy)
				if paint.snap then
					x=math.floor(x/gui.data.snapx:value())*gui.data.snapx:value()
					y=math.floor(y/gui.data.snapy:value())*gui.data.snapy:value()
				end
				if mouse_down then
					add_begin()
					paint.act_add({
						cmd="paint",
						args={paint.brush,x,y,0,0,paint.brush.width,paint.brush.height,pm[1],pm[2],pm[3]},
						})
				else
					paint.act_add({
						preview=true,
						cmd="paint",
						args={paint.brush,x,y,0,0,paint.brush.width,paint.brush.height,pm[1],pm[2],pm[3]},
						})
				end
			end
		elseif paint.mode=="pbrush" then
			local x=paint.x-math.floor((pba[3]-2)/2)
			local y=paint.y-math.floor((pba[4]-2)/2)
			if mouse_down then
				add_begin()
				paint.act_add({
					cmd="paint",
					args={paint.pbrush,x,y,pba[1],pba[2],pba[3],pba[4],wgrd.PAINT_MODE_COLOR,0,pm[3]},
					})
			else
				paint.act_add({
					preview=true,
					cmd="paint",
					args={paint.pbrush,x,y,pba[1],pba[2],pba[3],pba[4],wgrd.PAINT_MODE_COLOR,0,pm[3]},
					})
			end
		elseif paint.mode=="fill" then
			if m.action==1 then -- just first click
--				add_begin()
				paint.act_add({
					cmd="fill",
					args={paint.x,paint.y,pm[3]},
					})
			end
		end

		
		
		if m.action==-1 then
			mouse_down=false
			add_end()
		end
						
	end
	
end


local history_ignore_json={
	focus_x=true,
	focus_y=true,
	zoom_idx=true,
	layer_index=true, -- these are handled by history
	layer_frame=true,
	layer_count=true,
	layer_x=true,
	layer_y=true,
}
paint.history_ignore_json=history_ignore_json
	
-- handle paint actions
paint.acts={}
paint.act=function(a)

	local img=images.get()
	local grd=img.grd
	local history=img.grd.history
	local layers=img.grd.layers
	local grd_img=img.grd
	local grd_temp=paint.grd_temp
--	local grd_spare=paint.grd_spare

	local pba=paint.pbrush_area

	local history_draw_save=function()
		history:draw_save(img.get_json_data({},history_ignore_json))

		local kmax=gui.data and gui.data.undo_kmax and gui.data.undo_kmax:value()	
		if kmax and history.index==history.length and history.memory>kmax*1024 then		
			history:reduce_memory(kmax*1024) -- safe to reduce as we are at the end
		end

	end
	
--print(a.cmd,a.preview)

-- keep all grds the same size
	if grd_img.width~=grd_temp.width  or grd_img.height~=grd_temp.height  then grd_temp:resize(grd_img.width,grd_img.height,1)  end

	if a.preview then
		if a.cmd=="paint" then
			gui.image_refresh_required=true
			grd_temp:copy_data_layer(grd_img,0,img.grd.layers.frame)
			grd_temp.image=img
			if gui.data.wrap_active:value()>0 then
				wgrdpaint.paintwrap((img.layers_grd(nil,grd_temp,0)),unpack(a.args))
			else
				img.layers_grd(nil,grd_temp,0):paint(unpack(a.args))
			end
			paint.preview=true
		end
	else
		paint.preview=false
		if a.cmd=="begin" then
			history:draw_begin( img.layers_area() )
		elseif a.cmd=="end" then
			history_draw_save()
			gui.data_refresh_required=true
		elseif a.cmd=="pal_begin" then -- begin editing palette
--print("pal_begin")
			history:draw_begin( 0,0,0 , 0,0,0 )
		elseif a.cmd=="pal_set" then -- palette change only
--print("pal_set")
			img.grd:palette(unpack(a.args))
			img.modified=true
			gui.image_refresh_required=true
		elseif a.cmd=="pal_save" then -- finish editing pal and possibly merge with previous state
			history_draw_save()
			gui.widget_refresh_required=true
		elseif a.cmd=="pal_end" then -- finish editing pal+merge and prevent any future merges
			history_draw_save()
			history:draw_end()
			gui.widget_refresh_required=true
			gui.data_refresh_required=true
		elseif a.cmd=="redraw" then
			gui.image_refresh_required=true
		elseif a.cmd=="clear" then
			history:draw_get():clear(gui.color_bg.i)
			img.modified=true
			gui.image_refresh_required=true
		elseif a.cmd=="redoundo" then
			if not history:redo() then history:undo() end -- redo or undo
			img.set_json_data(history:get_json(),history_ignore_json)
			img.modified=true
			gui.full_refresh_required=true
		elseif a.cmd=="gotoundo" then
			history:goto(unpack(a.args))
			img.set_json_data(history:get_json(),history_ignore_json)
			img.modified=true
			gui.full_refresh_required=true
		elseif a.cmd=="undo" then
			history:undo()
			img.set_json_data(history:get_json(),history_ignore_json)
			img.modified=true
			gui.full_refresh_required=true
		elseif a.cmd=="redo" then
			history:redo()
			img.set_json_data(history:get_json(),history_ignore_json)
			img.modified=true
			gui.full_refresh_required=true
		elseif a.cmd=="pickup" then
			local pp=a.args
			paint.brush=wgrd.create(wgrd.U8_INDEXED,pp[3],pp[4],1)
--			paint.brush_undo=paint.brush
			paint.brush.x=pp[1] -- remember where brush was picked up from 
			paint.brush.y=pp[2]
			paint.brush:palette(0,256,grd_img:palette(0,256)) -- always force pal
			paint.brush:paint(history:draw_get(),0,0,pp[1],pp[2],pp[3],pp[4],wgrd.PAINT_MODE_COPY,0,0)
			if pp[5] then -- delete old brush area
				history:draw_get():clip(pp[1],pp[2],0,pp[3],pp[4],1):clear(gui.color_bg.i)
				img.modified=true
				gui.image_refresh_required=true
			end
		elseif a.cmd=="paint" then
			if gui.data.wrap_active:value()>0 then
				wgrdpaint.paintwrap((history:draw_get()),unpack(a.args))
			else
				history:draw_get():paint(unpack(a.args))
			end
			img.modified=true
			gui.image_refresh_required=true

		elseif a.cmd=="layer_add" then
		
			local i=img.grd.layers.index
			if i<1 then i=1 end

			history:push_layers(i,1)
			img.modified=true
			gui.full_refresh_required=true

		elseif a.cmd=="layer_del" then

			if img.grd.layers.count > 1 then

				local i=img.grd.layers.index
				if i<1 then i=1 end

				history:push_layers(i,-1)
				img.modified=true
				gui.full_refresh_required=true
			end

		elseif a.cmd=="frame_add" then
	
			if not img.spare then -- spare has no frames
				history:push_frames(img.grd.layers.frame+1,1) -- add a frame after this frame
				
				local lastframe=img.grd.layers:clip()
				img.grd.layers.frame=img.grd.layers.frame+1 -- select next frame

				history:draw_begin( img.grd.layers:area() )
				local nextframe=history:draw_get()
				nextframe:pixels(0,0,0,lastframe.width,lastframe.height,1,lastframe) -- duplicate last frame to next frame
				history_draw_save()
				
				img.modified=true
				gui.full_refresh_required=true
			end
			
		elseif a.cmd=="frame_del" then
	
			if not img.spare then -- spare has no frames
				if img.grd.depth > 1 then
					history:push_frames(img.grd.layers.frame,-1)

					img.grd.layers.frame=img.grd.layers.frame-1 -- select prev frame
					if img.grd.layers.frame<0 then img.grd.layers.frame=0 end

					img.modified=true
					gui.full_refresh_required=true
				end
			end
			
		elseif a.cmd=="swap_frames_layers" then
		
			history:push_swap_layers_with_frames()

--			img.grd.layers.swap_with_frames()

			img.modified=true
			gui.full_refresh_required=true
			

		elseif a.cmd=="fill" then
			history:draw_begin( img.layers_area() )
			local pp=a.args
			local b=wgrdpaint.fill_mask(history:draw_get(),pp[1],pp[2])
			if b then
				history:draw_get():paint(b,0,0,0,0,b.width,b.height,wgrd.PAINT_MODE_COLOR,0,pp[3])
				img.modified=true
			end
			history_draw_save()
			img.modified=true
			gui.image_refresh_required=true


		elseif a.cmd=="replace" then -- new grd with auto history bump

			local ga=img.grd -- old grd
			local gb=a.args[1] -- new grd
		
			history:draw_begin( 0,0,0, gb.width,gb.height,gb.depth )

			ga:palette(0,256,string.rep(string.char(0,0,0,0),256)) -- make sure it is empty
			ga:palette(0,256,gb)
			ga:pixels(0,0,0,gb.width,gb.height,gb.depth,gb)
			
			history_draw_save()


			img.modified=true
			gui.full_refresh_required=true

		end
	end


end
paint.act_loop=function()

	while #paint.acts > 0 do
		paint.act( table.remove(paint.acts,1) )
	end
	
end
paint.act_add=function(...)
	for i,v in ipairs{...} do
		paint.acts[#paint.acts+1]=v
	end
end



paint.update=function()


	paint.act_loop()

	local x1,y1=gui.draw_area:get_master_xy(0,0)
	local x2,y2=gui.draw_area:get_master_xy(gui.draw_area.hx,gui.draw_area.hy)

--		x1,y1=gui.master:get_master_xy(0,0)
--		x2,y2=gui.master:get_master_xy(gui.master.hx,gui.master.hy)

	paint.area.x=x1
	paint.area.y=y1
	paint.area.w=x2-x1
	paint.area.h=y2-y1

	textures.update()
	views.update()
	images.update()
	gui.update()
	

-- short hand for all the other refresh flags
	if gui.full_refresh_required then
		gui.image_refresh_required=true
		gui.data_refresh_required=true
		gui.widget_refresh_required=true
		gui.full_refresh_required=false
	end

-- refresh the image currently drawn on the screen	
	if gui.image_refresh_required then
		local image=images.get()

		local flat=false -- only show one layer unless flat is true
		if gui.master.ids.layer_show and gui.master.ids.layer_show.state=="selected" then flat=true end


		if not image.grd_rgba then -- not rgba
			local layers=image.grd.layers
			if flat and layers.count>1 then
				if paint.preview and paint.grd_temp then

					local gf=layers:flatten_frame( 0 , paint.grd_temp )
					if layers.index==0 then -- special preview
						paint.grd_temp:pixels(0,0,0,gf.width,gf.height,gf.depth,gf)
						textures.get().upload( paint.grd_temp , 0 ) -- show preview of brush painting
					else
						textures.get().upload( gf , 0 ) -- show real image
					end

				else
					local gf=layers:flatten_frame( layers.frame , image.grd )
					if layers.index==0 then -- special preview
						paint.grd_temp:copy_data_layer(image.grd,0,layers.frame)
						paint.grd_temp:pixels(0,0,0,gf.width,gf.height,gf.depth,gf)
						textures.get().upload( paint.grd_temp , 0 ) -- show real image
					else
						textures.get().upload( gf , 0 ) -- show real image
					end

				end
			else
				if paint.preview and paint.grd_temp then
					textures.get().upload(paint.grd_temp,0) -- show preview of brush painting
				else
					textures.get().upload(image.grd,image.grd.layers.frame) -- show real image
				end
			end
		else
			image.adjust_grd()
		end

		gui.image_refresh_required=false
	end

-- refresh the widgets data to reflect current state
	if gui.data_refresh_required then
		gui.data_refresh()
		gui.data_refresh_required=false
	end

-- refresh the visible widgets to reflect current state
	if gui.widget_refresh_required then
		gui.widget_refresh()
		gui.widget_refresh_required=false
	end
	
end

paint.draw=function()


	views.draw()
	gui.draw()

	
end

paint.quicksave=function()
	if paint.quicksave_hook then
		paint.quicksave_hook()
	else
		gui.save_grd() -- this will ask if you want to replace
	end
end

	return paint
end
