--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local bitsynth=require("wetgenes.gamecake.fun.bitsynth")
local _,lfs=pcall( function() return require("lfs") end ) ; lfs=_ and lfs

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")
--	local beep=oven.rebake(oven.modname..".beep")


gui.widgets_of_dat_id=function(id)
	local its={}
	local idx=0
	gui.master:call_descendents(function(w)
		if	( w.data and w.data.id==id ) or
			( w.datx and w.datx.id==id ) or
			( w.daty and w.daty.id==id ) then
			its[w]=w
		end
	end)
	return pairs(its)
end




function gui.hooks(act,w,dat)


	if act=="file_name_click" then

		local path=dat.path
		w.master.later_append(function()
			local f=io.open(path,"rb")
			local d=f:read("*a")
			gui.texteditor.txt.set_text(d,path)
			gui.texteditor.txt.set_lexer()
			f:close()
		end)

	elseif act=="click" then

--print("CLICK",w.id)

		if w.id=="font_size" then
		
			gui.font_size=w.user

		elseif w.id=="quit" then
		
			oven.next=true
		
		elseif w.id=="load" then
		
			gui.screen.dialogs:show({
				lines={"Load..."
				},
				file={},
--				sorry=function()end,
				hooks=function(act,it)
					if act=="file_name_click" then
						local req=it ; while not req.close_request do req=req.parent end
						local path=req.file:path()
						req.master.later_append(function()
							local f=io.open(path,"rb")
							local d=f:read("*a")
							gui.texteditor.txt.set_text(d,path)
							gui.texteditor.txt.set_lexer()
							f:close()
						end)

						req:close_request()
					end
				end
			})

		elseif w.id=="save" then
		

		elseif w.id=="dialog" then
			gui.screen.dialogs:show({
				lines={"Save..."
				},
				file={},
				sorry=function()end
			})
		end


	end


	if act=="value" then

--print("VALUE",w.id)

	end

	
end

	return gui
end
