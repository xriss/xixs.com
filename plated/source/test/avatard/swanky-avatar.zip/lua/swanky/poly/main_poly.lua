--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local bit=require("bit")
local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local wgrd=require("wetgenes.grd")
local zips=require("wetgenes.zips")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wsbox=require("wetgenes.sandbox")



local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,poly)
	local poly=poly or {}
	poly.oven=oven
	
	poly.modname=M.modname

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl
	local sheets=cake.sheets

	local main=oven.rebake(oven.modname..".main")
	local gui=oven.rebake(oven.modname..".gui")

	local meshs=oven.rebake(oven.modname..".meshs")
	local geom=oven.rebake("wetgenes.gamecake.spew.geom")



poly.loads=function()

end
		
poly.setup=function()

	if not poly.done_setup then
-- single setup
		poly.done_setup=true
	end
	
	poly.edit="verts"
	poly.mouse1="pan"
--	poly.mouse1="box"

	poly.xyz={0,0,0}

	poly.pos={0,0,0}
	poly.rot={-10,20,0}
	poly.box=nil -- box select/draw
	
	poly.light={0,-1,1}
	
	gui.setup()
	
	meshs.setup()
	meshs.create()
	
--	textures.get().upload( images.get().grd , images.get().frame )

	if poly.setup_conf then
		poly.configure(poly.setup_conf)
		poly.setup_conf=nil
	end
	
	local ss=128
	
	poly.gridx=geom.grid(nil,0,16,16):adjust_scale(ss*8):adjust_position(0,-ss*4,-ss*4)
	poly.gridy=geom.grid(nil,16,0,16):adjust_scale(ss*8):adjust_position(-ss*4,0,-ss*4)
	poly.gridz=geom.grid(nil,16,16,0):adjust_scale(ss*8):adjust_position(-ss*4,-ss*4,0)
	poly.crosshair=geom.crosshair(nil):adjust_scale(ss*8)
end

poly.clean=function()

--	textures.clean()
--	views.clean()
--	images.clean()

end



poly.configure=function(conf)

	if type(conf)=="string" then conf=wsbox.lson(conf) end
	
	if not poly.done_setup then -- save for recall after we are setup
		poly.setup_conf=conf
		return
	end


	gui.fixbuts()
	gui.side_page_next="tools"
	
	poly.act_add({cmd="begin"})
	poly.act_add({cmd="clear"})
	poly.act_add({cmd="end"})

end



poly.msg=function(m)

	if m.class=="mouse" then
		poly.msg_mouse(m)
	end


--	if not views.grabmouse then
		if gui.msg(m) then return end
--	end
--	if views.msg(m) then return end

	
end



local mouse_down=false
poly.msg_mouse=function(m)

--print(poly.view_drag)

	local view=nil
	local view_mode=nil
	local mouse_mode=nil
	local t=nil

	if not mouse_mode then
		if poly.view_drag then
			view=poly.view_drag
			mouse_mode="drag"
			view_mode=poly.view_drag.user
		end
	end

	if not mouse_mode then
		local m=gui.master.over
		if m and m.id=="view" then
			view=m
			mouse_mode="over"
			view_mode=m.user
		end
	end


	local x,y,z = poly.xyzview(view,m.x,m.y)

--print(x,y,z)

	poly.xyz[1]=x
	poly.xyz[2]=y
	poly.xyz[3]=z
	
	
	if view_mode=="xy" then
		poly.light[1]=poly.xyz[1]
		poly.light[2]=poly.xyz[2]
		poly.light[3]=poly.xyz[3]+128
	elseif view_mode=="xz" then
		poly.light[1]=poly.xyz[1]
		poly.light[2]=poly.xyz[2]-128
		poly.light[3]=poly.xyz[3]
	elseif view_mode=="zy" then
		poly.light[1]=poly.xyz[1]+128
		poly.light[2]=poly.xyz[2]
		poly.light[3]=poly.xyz[3]
	else
--		poly.light[1]=0
--		poly.light[2]=-1
--		poly.light[3]=1
	end

	
	if view_mode then
	
		if poly.mouse1=="pan" or view_mode=="pp" then -- drag the window position around
		
			poly.xyz[1]=-poly.pos[1]
			poly.xyz[2]=-poly.pos[2]
			poly.xyz[3]=-poly.pos[3]

			if mouse_mode=="drag" then -- clicking and dragging in a view

				if not poly.view_pos then
					poly.view_pos={poly.pos[1],poly.pos[2],poly.pos[3],x=m.x,y=m.y}
					poly.view_rot={poly.rot[1],poly.rot[2],poly.rot[3],x=m.x,y=m.y}
				end

				if view_mode=="xy" then
					poly.pos[1]=poly.view_pos[1] + (m.x-poly.view_pos.x)
					poly.pos[2]=poly.view_pos[2] + (m.y-poly.view_pos.y)
					poly.pos[3]=poly.view_pos[3]
				elseif view_mode=="xz" then
					poly.pos[1]=poly.view_pos[1] + (m.x-poly.view_pos.x)
					poly.pos[2]=poly.view_pos[2]
					poly.pos[3]=poly.view_pos[3] + (m.y-poly.view_pos.y)
				elseif view_mode=="zy" then
					poly.pos[1]=poly.view_pos[1]
					poly.pos[2]=poly.view_pos[2] + (m.y-poly.view_pos.y)
					poly.pos[3]=poly.view_pos[3] - (m.x-poly.view_pos.x)
				elseif view_mode=="pp" then
					poly.rot[1]=poly.view_rot[1] + (m.x-poly.view_rot.x)
					poly.rot[2]=poly.view_rot[2] + (m.y-poly.view_rot.y)
					poly.rot[3]=poly.view_rot[3]
				end
				
			end

			for i,v in ipairs(gui.view_widgets) do v:set_dirty() end

		elseif poly.mouse1=="light" then -- adjust light
			if mouse_mode=="drag" then
			
				if view_mode=="xy" then
					poly.light[1]=poly.xyz[1]
					poly.light[2]=poly.xyz[2]
					poly.light[3]=poly.xyz[3]+128
				elseif view_mode=="xz" then
					poly.light[1]=poly.xyz[1]
					poly.light[2]=poly.xyz[2]-128
					poly.light[3]=poly.xyz[3]
				elseif view_mode=="zy" then
					poly.light[1]=poly.xyz[1]+128
					poly.light[2]=poly.xyz[2]
					poly.light[3]=poly.xyz[3]
				end

				for i,v in ipairs(gui.view_widgets) do v:set_dirty() end

			end

		elseif poly.mouse1=="move" then -- move some points

			if mouse_mode=="drag" then
				
				if not poly.move then
					poly.mask_save_verts()
					poly.move={{poly.xyz[1],poly.xyz[2],poly.xyz[3]},{poly.xyz[1],poly.xyz[2],poly.xyz[3]}}
				end

				if view_mode=="xy" then
					poly.move[2][1]=poly.xyz[1]
					poly.move[2][2]=poly.xyz[2]
				elseif view_mode=="xz" then
					poly.move[2][1]=poly.xyz[1]
					poly.move[2][3]=poly.xyz[3]
				elseif view_mode=="zy" then
					poly.move[2][2]=poly.xyz[2]
					poly.move[2][3]=poly.xyz[3]
				end
				
				poly.mask_load_verts()
				poly.mask_move_verts({	poly.move[2][1]-poly.move[1][1],
										poly.move[2][2]-poly.move[1][2],
										poly.move[2][3]-poly.move[1][3]})
				poly.clear_predraw()

				if m.class=="mouse" and m.action==-1 then
					poly.move=nil
				end


			else
			
			end

			for i,v in ipairs(gui.view_widgets) do v:set_dirty() end

			poly.xyz[1]=-poly.pos[1]
			poly.xyz[2]=-poly.pos[2]
			poly.xyz[3]=-poly.pos[3]

		elseif poly.mouse1=="select" then -- area select, add or remove

			if mouse_mode=="drag" then
				
				if not poly.box then
					poly.box={{poly.xyz[1],poly.xyz[2],poly.xyz[3]},{poly.xyz[1],poly.xyz[2],poly.xyz[3]}}
				end

				if view_mode=="xy" then
					poly.box[2][1]=poly.xyz[1]
					poly.box[2][2]=poly.xyz[2]
				elseif view_mode=="xz" then
					poly.box[2][1]=poly.xyz[1]
					poly.box[2][3]=poly.xyz[3]
				elseif view_mode=="zy" then
					poly.box[2][2]=poly.xyz[2]
					poly.box[2][3]=poly.xyz[3]
				end
				

				if m.class=="mouse" and m.action==-1 then
					poly.mask_select_box_verts(poly.box)
					poly.box=nil
					poly.clear_predraw()
					gui.fixbuts()
				end


			else
			
			end

			for i,v in ipairs(gui.view_widgets) do v:set_dirty() end

		elseif poly.mouse1=="box" then -- select a box area within a window

			if m.action==1 then
			
				if poly.box then -- pick closest corner to adjust
				

					if (poly.box[1][1]-   poly.xyz[1])^2 < (poly.box[2][1]-   poly.xyz[1])^2 then
						poly.box[1][1],poly.box[2][1]    =  poly.box[2][1],poly.box[1][1]
					end

					if (poly.box[1][2]-   poly.xyz[2])^2 < (poly.box[2][2]-   poly.xyz[2])^2 then
						poly.box[1][2],poly.box[2][2]    =  poly.box[2][2],poly.box[1][2]
					end

					if (poly.box[1][3]-   poly.xyz[3])^2 < (poly.box[2][3]-   poly.xyz[3])^2 then
						poly.box[1][3],poly.box[2][3]    =  poly.box[2][3],poly.box[1][3]
					end

				end
			
			end

			if mouse_mode=="drag" then
				
				if not poly.box then
					poly.box={{poly.xyz[1],poly.xyz[2],poly.xyz[3]},{poly.xyz[1],poly.xyz[2],poly.xyz[3]}}
				end

				if view_mode=="xy" then
					poly.box[2][1]=poly.xyz[1]
					poly.box[2][2]=poly.xyz[2]
				elseif view_mode=="xz" then
					poly.box[2][1]=poly.xyz[1]
					poly.box[2][3]=poly.xyz[3]
				elseif view_mode=="zy" then
					poly.box[2][2]=poly.xyz[2]
					poly.box[2][3]=poly.xyz[3]
				end
				
			else
			
			end

			for i,v in ipairs(gui.view_widgets) do v:set_dirty() end

		end

	end
	
	if poly.mouse1=="select" then
	
		if m.class=="mouse" and m.action==-1 then
			poly.box=nil
		end

	elseif poly.mouse1~="box" then 
		poly.box=nil
	end
	
-- clear everything
	if m.class=="mouse" and m.action==-1 then
		poly.view_drag=nil
		poly.view_pos=nil
	end


--	local img=images.get()
--	local ga=img.layers_grd()
--	local gb=poly.grd
--	local pba=poly.pbrush_area
--	local dirty={grd=img.grd,frame=img.frame}
	
--	gb:resize(ga.width,ga.height,1)


	
--	if poly.x>=0 and poly.y>=0 and poly.x<img.layers.width and poly.y<img.layers.height then
--		poly.inside=true
--	else
--		poly.inside=false
--	end

--print(m.keyname)

	if m.class=="mouse" then

--[[
		if m.keycode==4 or m.keycode==5 then -- scroll buttons hack to create fake clicks
			if m.action==-1 then
				if m.keycode==4 then
					gui.hooks("click",{id="magnify"})
				else
					gui.hooks("click",{id="magnify_right"})
				end
			end
			return -- and be ignored
		end
]]

		gui.infomode="mouse" -- display mouse

		if m.action==1 then
			mouse_down=m.keyname
--			views.grabmouse=true -- poly has claimed all future mouse msgs
		end
		if m.action==-1 then
--			views.grabmouse=false
		end

local function add_begin()
	if not poly.down then
		poly.down=true
		poly.act_add({cmd="begin"})
	end
end
local function add_end()
	if poly.down then
		poly.down=false
		poly.act_add({cmd="end"})
	end
end


		if poly.mouse1=="scroll" then
		end
		
		if m.action==-1 then
			mouse_down=false
			add_end()
		end
						
	end
	
end


-- handle poly actions
poly.acts={}
poly.act=function(a)

	if a.preview then
	else
		if a.cmd=="begin" then
		elseif a.cmd=="end" then
		elseif a.cmd=="redraw" then
		elseif a.cmd=="clear" then
		elseif a.cmd=="undo" then
		end
	end


end
poly.act_loop=function()

	while #poly.acts > 0 do
		poly.act( table.remove(poly.acts,1) )
	end

	if poly.dirty then
--		textures.get().upload(poly.dirty.grd,poly.dirty.frame)
--		poly.dirty=nil
	end
	
end
poly.act_add=function(a)
	poly.acts[#poly.acts+1]=a
end



poly.update=function()

	poly.act_loop()

--	local x1,y1=gui.draw_area:get_master_xy(0,0)
--	local x2,y2=gui.draw_area:get_master_xy(gui.draw_area.hx,gui.draw_area.hy)
--[[
	poly.area.x=x1
	poly.area.y=y1
	poly.area.w=x2-x1
	poly.area.h=y2-y1
]]

--	views.update()
	gui.update()
	
end

poly.draw=function()

--	views.draw()
	gui.draw()
	
end

poly.quicksave=function()
	if poly.quicksave_hook then
		poly.quicksave_hook()
	else
		if oven.opts.bake.smell~="thin" then
			gui.side_page_next="save"
		end
--	images.save_grd( gfile.dir:value() .."/".. gfile.file:value() )
	end
end

-- get an xyz out of a mouse in a widgets x,y
-- this obviously depends upon the widget we are over
poly.xyzview=function(widget,x,y)

	if widget and widget.id=="view" then
		local lx,ly=widget:get_local_xy(x,y)

--print(x,y,lx,ly)
		lx=lx-(widget.hx/2)
		ly=ly-(widget.hy/2)

-- lx,ly is relative to the center of the view, the center of the view is at poly.pos

			if		widget.user=="pp" then
				
				return -poly.pos[1] , -poly.pos[2] , -poly.pos[3]  

			elseif	widget.user=="xy" then

				return -poly.pos[1] + lx , -poly.pos[2] + ly , -poly.pos[3]  

		
			elseif	widget.user=="xz" then

				return -poly.pos[1] +lx , -poly.pos[2] , -poly.pos[3] + ly 

			elseif	widget.user=="zy" then

				return -poly.pos[1] , -poly.pos[2] + ly , -poly.pos[3] - lx  

			end
	end

	return -poly.pos[1] , -poly.pos[2] , -poly.pos[3]  

end


poly.mask_count_verts=function()
	local r=0
	if meshs[1] and meshs[1].geoms then
		for i,v in ipairs(meshs[1].geoms) do
			r=r+v:mask_count_verts()
		end
	end
	return r
end

poly.mask_count_lines=function()
	local r=0
	if meshs[1] and meshs[1].geoms then
		for i,v in ipairs(meshs[1].geoms) do
			r=r+v:mask_count_lines()
		end
	end
	return r
end

poly.mask_count_polys=function()
	local r=0
	if meshs[1] and meshs[1].geoms then
		for i,v in ipairs(meshs[1].geoms) do
			r=r+v:mask_count_polys()
		end
	end
	return r
end

poly.mask_select_box_verts=function(box,mode)
	if meshs[1] and meshs[1].geoms then
		for i,v in ipairs(meshs[1].geoms) do
			v:mask_select_box_verts(box,mode)
		end
	end
end

poly.clear_predraw=function()
	if meshs[1] and meshs[1].geoms then
		for i,v in ipairs(meshs[1].geoms) do
			v:clear_predraw()
		end
	end
end

poly.mask_save_verts=function()
	if meshs[1] and meshs[1].geoms then
		for i,v in ipairs(meshs[1].geoms) do
			v:mask_save_verts()
		end
	end
end

poly.mask_load_verts=function()
	if meshs[1] and meshs[1].geoms then
		for i,v in ipairs(meshs[1].geoms) do
			v:mask_load_verts()
		end
	end
end

poly.mask_move_verts=function(d)
	if meshs[1] and meshs[1].geoms then
		for i,v in ipairs(meshs[1].geoms) do
			v:mask_move_verts(d)
		end
	end
end

poly.drawview=function(widget)

--print( poly.pos[1] , poly.pos[2] , poly.pos[3] )

--print("draw",widget)
--if widget.dirty then print(widget.dirty) end

	local mode=widget.user

	widget:draw_base(function(widget)
	
		gl.Color(gl.C8(widget.color))
		canvas.flat.quad(	0,				0,
							widget.hx,		0,
							widget.hx,		widget.hy,
							0,				widget.hy)



		gl.PushMatrix()
		gl.Translate(widget.hx/2,widget.hy/2,0)
		
		if		mode=="pp" then			gl.Rotate( poly.rot[1],0,1,0)	gl.Rotate(-poly.rot[2],1,0,0)
		elseif	mode=="xy" then
		elseif	mode=="xz" then			gl.Rotate(-90,1,0,0)
		elseif	mode=="zy" then			gl.Rotate(-90,0,1,0)
		end
	
		gl.Translate( poly.pos[1] , poly.pos[2] , poly.pos[3] )
		
		meshs[1]:draw()

		gl.Color(gl.C8(0x88888888))

--		gl.DepthMask(gl.FALSE)
--		gl.Enable(gl.DEPTH_TEST)
		gl.state.set({
			[gl.DEPTH_WRITEMASK]			=	gl.FALSE,
			[gl.DEPTH_TEST]					=	gl.TRUE,
		})

		if		mode=="pp" then			poly.gridy:draw_lines("xyz",function(p)end)
		elseif	mode=="xy" then			poly.gridz:draw_lines("xyz",function(p)end)
		elseif	mode=="xz" then			poly.gridy:draw_lines("xyz",function(p)end)
		elseif	mode=="zy" then			poly.gridx:draw_lines("xyz",function(p)end)
		end

--		gl.Disable(gl.DEPTH_TEST)
--		gl.DepthMask(gl.TRUE)
		gl.state.set({
			[gl.DEPTH_WRITEMASK]			=	gl.TRUE,
			[gl.DEPTH_TEST]					=	gl.FALSE,
		})


-- selection box
		if poly.box and poly.box[2] then
		
			local flat= (poly.box[1][1]==poly.box[2][1]) or
						(poly.box[1][2]==poly.box[2][2]) or
						(poly.box[1][3]==poly.box[2][3])

		
			if not flat then
--				gl.DepthMask(gl.FALSE)
--				gl.Enable(gl.DEPTH_TEST)
				gl.state.set({
					[gl.DEPTH_WRITEMASK]			=	gl.FALSE,
					[gl.DEPTH_TEST]					=	gl.TRUE,
				})
			end
			gl.Color(gl.C8(0x88884400))
			local box=geom.box(nil,poly.box)
			box.vb=false
			box:draw("xyz",function(p)end)
			if not flat then
--				gl.Disable(gl.DEPTH_TEST)
--				gl.DepthMask(gl.TRUE)
				gl.state.set({
					[gl.DEPTH_WRITEMASK]			=	gl.TRUE,
					[gl.DEPTH_TEST]					=	gl.FALSE,
				})
			end
		end


		gl.Enable(gl.DEPTH_TEST)
		gl.DepthMask(gl.FALSE)

		gl.Color(gl.C8(0xffffff00))
		gl.PushMatrix()
		gl.Translate(poly.xyz[1] ,  poly.xyz[2] , poly.xyz[3] )
		poly.crosshair:draw_lines("xyz",function(p)end)
		gl.PopMatrix()

		gl.Disable(gl.DEPTH_TEST)
		gl.DepthMask(gl.TRUE)


		gl.PopMatrix()

		
		
	end)

end

	return poly
end
