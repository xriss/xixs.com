--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,main)
	main=main or {}
	main.modname=M.modname
	
	oven.modname="swanky.poly"
	
	local gl=oven.gl
	local cake=oven.cake
	local sheets=cake.sheets
	local opts=oven.opts
	local canvas=cake.canvas
	local views=cake.views
	local font=canvas.font
	local flat=canvas.flat

--	local layout=layouts.push_child{} -- we shall have a child layout to fiddle with
--	local layout=cake.layouts.create{overscale=opts.overscale}

	local view=views.create({
		parent=views.get(),
		mode="raw",
		vx=opts.width,
		vy=opts.height,
		vz=opts.height*4,
		fov=1/4,
	})

	local skeys=oven.rebake("wetgenes.gamecake.spew.keys")
	local srecaps=oven.rebake("wetgenes.gamecake.spew.recaps")
	skeys.setup({max_up=1}) -- also calls srecaps.setup
	
main.start=function()
	main.loads()
end

main.loads=function()

	oven.cake.fonts.loads({1,"Vera",--[["FiraSans-Regular"]]}) -- load 1st builtin font, a basic 8x8 font

	sheets.loads_and_chops({
--		{"imgs/icons",1/8,1/8,1/16,1/16},
	})
	
--	oven.rebake(oven.modname..".main_paint").loads()
	
end
		
main.setup=function()

	main.loads()
	
	main.last=nil
	main.now=nil
	main.next=nil
	
	main.drawframe=0
	
	main.next=oven.rebake(oven.modname..".main_poly")
	
	main.change()
end

function main.change()

-- handle state changes

	if main.next then
	
		if main.now and main.now.clean then
			main.now.clean()
		end
		
		main.last=main.now
		main.now=main.next
		main.next=nil
		
		if main.now and main.now.setup then
			main.now.setup()
		end
		
	end
	
end		

main.clean=function()

	if main.now and main.now.clean then
		main.now.clean()
	end

end

-- push the last known mouse position back through the msg loop
local oldmouse={x=0,y=0}
main.remouse=function()

	main.msg{
		xraw=oldmouse.x,
		yraw=oldmouse.y,
		class="mouse",
		keycode=0,
		action=0,
		time=os.time(),
		}
end

main.msg=function(m)
--	print(wstr.dump(m))

	if m.xraw and m.yraw then	-- we need to fix raw x,y numbers
		oldmouse.x=m.xraw
		oldmouse.y=m.yraw

--		m.x,m.y=layout.xyscale(m.xraw,m.yraw)	-- local coords, 0,0 is center of screen
		view.msg(m)


--		m.x=m.x+oven.win.width*0.5
--		m.y=m.y+oven.win.height*0.5
	end

	if skeys.msg(m) then m.skeys=true end -- flag this msg as handled by skeys

	if main.now and main.now.msg then
		main.now.msg(m)
	end
	
end

main.update=function()

	main.change()
	srecaps.step()

	if main.now and main.now.update then
		main.now.update()
	end

--	if main.remouse_fix then main.remouse() end
main.remouse()
end

main.draw=function()

	main.drawframe=main.drawframe+1
	
	views.push_and_apply(view)
--	layout.apply( opts.width,opts.height,1/4,opts.height*4 )
--	layout.apply()
	canvas.gl_default() -- reset gl state
		
	gl.ClearColor(pack.argb4_pmf4(0xf444))
	gl.Clear(gl.COLOR_BUFFER_BIT+gl.DEPTH_BUFFER_BIT)

	gl.PushMatrix()
	
	font.set(cake.fonts.get("Vera")) -- default font
	font.set_size(32,0) -- 32 pixels high

	if main.now and main.now.draw then
		main.now.draw()
	end
	
	gl.PopMatrix()

	views.pop_and_apply()
	
end
		
	return main
end

