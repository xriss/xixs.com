--
-- (C) 2013 Kriss@XIXs.com
--
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local wgrd=require("wetgenes.grd")
local wzips=require("wetgenes.zips")
local bitdown=require("wetgenes.gamecake.fun.bitdown")
local bitsynth=require("wetgenes.gamecake.fun.bitsynth")
local _,lfs=pcall( function() return require("lfs") end )

local function dprint(a) print(wstr.dump(a)) end


--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.fill=function(gui)

	local oven=gui.oven

	local cake=oven.cake
	local opts=oven.opts
	local canvas=cake.canvas
	local font=canvas.font
	local flat=canvas.flat
	local gl=oven.gl


	local datas=gui.master.datas

	local wdata=oven.rebake("wetgenes.gamecake.widgets.data")

datas.set_infos({

	{
		id="test",
		help="This is a test.",
	},
	
})


-- create data
gui.data_setup=function()
	if not gui.datas then -- only setup once
	
		gui.datas=datas

		datas.new({id="display_offset",class="number",hooks=gui.hooks,num=0,min=0,max=48000,step=800,
			tostring=function(dat,num) return string.format("%0.3f",math.floor(1000*(num)/48000)/1000) end})

--		datas.new({id="base_type"  ,class="list",  hooks=gui.hooks,num=1,list={
--			{str="Wave"},
--			{str="FMod"},
--		}})

		datas.new({id="fm_active"  ,class="list",  hooks=gui.hooks,num=1,list={
			{str="Disabled"},
			{str="Active"},
		}})

		datas.new({id="filter_active"  ,class="list",  hooks=gui.hooks,num=2,list={
			{str="Disabled"},
			{str="Active"},
		}})

		datas.new({id="base_wave"  ,class="list",  hooks=gui.hooks,num=5,list={
			{str="Sine"},
			{str="Triangle"},
			{str="Sawtooth"},
			{str="Toothsaw"},
			{str="Square"},
			{str="Whitenoise"},
		}})
		
		datas.new({id="base_note"  ,class="list",  hooks=gui.hooks,num=1,list={
			{str="C"},
			{str="C#"},
			{str="D"},
			{str="D#"},
			{str="E"},
			{str="F"},
			{str="F#"},
			{str="G"},
			{str="G#"},
			{str="A"},
			{str="A#"},
			{str="B"},
		}})

		datas.new({id="base_octave"  ,class="list",  hooks=gui.hooks,num=4,list={
			{str="1"},
			{str="2"},
			{str="3"},
			{str="4"},
			{str="5"},
			{str="6"},
			{str="7"},
			{str="8"},
		}})

		datas.new({id="base_duty",class="number",hooks=gui.hooks,num=0.5,min=0,max=1,step=0.01})

		datas.new({id="base_sustain_level",class="number",hooks=gui.hooks,num=1,min=0,max=1,step=1/100})

		datas.new({id="base_attack",class="number",hooks=gui.hooks,num=0,min=0,max=10,step=1/10})
		datas.new({id="base_decay",class="number",hooks=gui.hooks,num=0,min=0,max=10,step=1/10})
		datas.new({id="base_sustain",class="number",hooks=gui.hooks,num=0.8,min=0,max=10,step=1/10})
		datas.new({id="base_release",class="number",hooks=gui.hooks,num=0.2,min=0,max=10,step=1/10})

		datas.new({id="fm_wave"  ,class="list",  hooks=gui.hooks,num=1,list={
			{str="Sine"},
			{str="Triangle"},
			{str="Sawtooth"},
			{str="Toothsaw"},
			{str="Square"},
			{str="Whitenoise"},
			{str="Minus"},
			{str="Zero"},
			{str="One"},
		}})
		datas.new({id="fm_duty",class="number",hooks=gui.hooks,num=0.5,min=0,max=1,step=0.01})

		datas.new({id="fm_wave_rez",class="number",hooks=gui.hooks,num=0,min=0,max=64,step=1})
		datas.new({id="fm_white_steps",class="number",hooks=gui.hooks,num=16,min=1,max=64,step=1})
		datas.new({id="fm_white_seed",class="number",hooks=gui.hooks,num=437,min=1,max=65536,step=1})

		datas.new({id="fm_frequency_root",class="number",hooks=gui.hooks,num=4,min=0.1,max=16,step=1/10,
			tostring=function(dat,num) return tostring(math.floor((num*num)*100)/100) end})

		datas.new({id="fm_slide",class="number",hooks=gui.hooks,num=0,min=-32,max=32,step=0.1,
			tostring=function(dat,num) local sign=num<0 and -1 or 1 return tostring(sign*math.floor((num*num)*100)/100) end})

		datas.new({id="fm_min_note"  ,class="list",  hooks=gui.hooks,num=1,list={
			{str="C"},
			{str="C#"},
			{str="D"},
			{str="D#"},
			{str="E"},
			{str="F"},
			{str="F#"},
			{str="G"},
			{str="G#"},
			{str="A"},
			{str="A#"},
			{str="B"},
		}})

		datas.new({id="fm_min_octave"  ,class="list",  hooks=gui.hooks,num=3,list={
			{str="1"},
			{str="2"},
			{str="3"},
			{str="4"},
			{str="5"},
			{str="6"},
			{str="7"},
			{str="8"},
		}})

		datas.new({id="fm_max_note"  ,class="list",  hooks=gui.hooks,num=1,list={
			{str="C"},
			{str="C#"},
			{str="D"},
			{str="D#"},
			{str="E"},
			{str="F"},
			{str="F#"},
			{str="G"},
			{str="G#"},
			{str="A"},
			{str="A#"},
			{str="B"},
		}})

		datas.new({id="fm_max_octave"  ,class="list",  hooks=gui.hooks,num=5,list={
			{str="1"},
			{str="2"},
			{str="3"},
			{str="4"},
			{str="5"},
			{str="6"},
			{str="7"},
			{str="8"},
		}})

		datas.new({id="filter_1",class="number",hooks=gui.hooks,num=1,min=0,max=2,step=0.01})
		datas.new({id="filter_2",class="number",hooks=gui.hooks,num=1,min=0,max=2,step=0.01})
		datas.new({id="filter_3",class="number",hooks=gui.hooks,num=1,min=0,max=2,step=0.01})
		datas.new({id="filter_4",class="number",hooks=gui.hooks,num=1,min=0,max=2,step=0.01})
		datas.new({id="filter_5",class="number",hooks=gui.hooks,num=1,min=0,max=2,step=0.01})
		datas.new({id="filter_6",class="number",hooks=gui.hooks,num=1,min=0,max=2,step=0.01})
		datas.new({id="filter_7",class="number",hooks=gui.hooks,num=1,min=0,max=2,step=0.01})
		datas.new({id="filter_8",class="number",hooks=gui.hooks,num=1,min=0,max=2,step=0.01})
		datas.new({id="filter_9",class="number",hooks=gui.hooks,num=1,min=0,max=2,step=0.01})
		datas.new({id="filter_10",class="number",hooks=gui.hooks,num=1,min=0,max=2,step=0.01})

	end
end



	return gui
end
