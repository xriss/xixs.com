#!/usr/local/bin/gamecake

-- copy all globals into locals, some locals are prefixed with a G to reduce name clashes
local coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,Gload,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require=coroutine,package,string,table,math,io,os,debug,assert,dofile,error,_G,getfenv,getmetatable,ipairs,load,loadfile,loadstring,next,pairs,pcall,print,rawequal,rawget,rawset,select,setfenv,setmetatable,tonumber,tostring,type,unpack,_VERSION,xpcall,module,require

-- setup some default search paths,
local apps=require("apps")
apps.default_paths()

local wzips=require("wetgenes.zips")
local wjson=require("wetgenes.json")

local pack=require("wetgenes.pack")
local wwin=require("wetgenes.win")
local wxox=require("wetgenes.xox")
local wstr=require("wetgenes.string")
local tardis=require("wetgenes.tardis")	-- matrix/vector math
local V2,V3,V4,M2,M3,M4,Q4=tardis:export("V2","V3","V4","M2","M3","M4","Q4")

local function dprint(a) print(wstr.dump(a)) end

--module
local M={ modname=(...) } ; package.loaded[M.modname]=M

M.bake=function(oven,avatar)
	avatar=avatar or {}
	avatar.modname=M.modname
	
	local gl=oven.gl
	local cake=oven.cake
	local sheets=cake.sheets
	local opts=oven.opts
	local canvas=cake.canvas
	local views=cake.views
	local font=canvas.font
	local flat=canvas.flat


	local framebuffers=oven.rebake("wetgenes.gamecake.framebuffers")

	local wgeoms=oven.rebake("wetgenes.gamecake.spew.geoms")
	local wgeoms_avatar=oven.rebake("wetgenes.gamecake.spew.geoms_avatar")
	local geom=oven.rebake("wetgenes.gamecake.spew.geom")
	local geom_dae=oven.rebake("wetgenes.gamecake.spew.geom_dae")
	local geom_gltf=oven.rebake("wetgenes.gamecake.spew.geom_gltf")

	local gui=oven.rebake(oven.modname..".gui")

	avatar.filename="/sync/kriss/blender/avatar/avatar" -- try and use latest version



-- the available mesh names of an avatar

	avatar.mesh_names={

		{"hat_baseball",		group=1,									},
		{"hat_kerchief",		group=1,									},
		{"hat_pirate",			group=1,									},

		{"hair_base",			group=0,									},
		{"hair_basic",			group=1,									},
		{"hair_spiky",			group=1,									},
		{"hair_back",			group=1,									},
		{"hair_bob",			group=1,									},
		{"hair_flattop",		group=1,									},
		{"hair_shoulder",		group=1,									},
		{"hair_afro",			group=1,									},
		{"hair_quiff",			group=1,									},
		{"hair_hedgehog",		group=1,									},
		{"hair_top_spiked",		group=1,									},
		{"hair_moflop_left",	group=1,									},
		{"hair_goth",			group=1,									},
		{"hair_mess",			group=1,									},

		{"hair_fringe",			group=2,									},
		{"hair_bunches",		group=2,									},
		{"hair_pigtails",		group=2,									},

		{"head_base",			group=1,									},
		{"head_skull",			group=0,									},

		{"eyebrow_base",		group=1,									},
		{"eyebrow_block",		group=1,									},

		{"eye_base",			group=1,									},
		{"eye_lash",			group=1,									},

		{"eyeball_base",		group=1,									},
		{"eyeball_cat",			group=1,									},

		{"eyewear_glasses",		group=1,									},

		{"mouth_base",			group=1,									},
		{"mouth_jaw",			group=0,									},

		{"beard_goatbraid",		group=1,									},
		{"beard_goatee",		group=1,									},
		{"beard_tash",			group=1,									},
		{"beard_whiskers",		group=1,									},

		{"ear_base",			group=1,									},
		{"ear_bunny",			group=0,									},

		{"nose_base",			group=1,									},
		{"nose_piggy",			group=0,									},
		{"nose_clown",			group=0,									},

		{"body_belly",			group=1,									},
		{"body_belly_boob",		group=1,									},
		{"body_bone",			group=0,									},
		{"body_boob",			group=1,									},
		{"body_chest",			group=1,									},
		{"body_tshirt",			group=1,									},
		{"body_tshirt_boob",	group=1,									},
		{"body_bodice",			group=1,									},
		{"body_vest",			group=1,									},

		{"body_printer_support",group=0,									},
		{"body_tie",			group=0,									},
		{"body_tie_belly",		group=0,									},
		{"body_tie_boob",		group=0,									},
		{"body_coat",			group=0,									},
		{"body_coat_boob",		group=0,									},

		{"hand_base",			group=1,									},
		{"hand_bone",			group=0,									},

		{"tail_bunny",			group=0,									},
		{"tail_devil",			group=0,									},

		{"foot_bare",			group=1,									},
		{"foot_bone",			group=0,									},
		{"foot_slipper",		group=1,									},
		{"foot_flipflop",		group=1,									},
		{"foot_shoe",			group=1,									},
		{"foot_boot",			group=1,									},
		{"foot_heel",			group=1,									},

		{"item_hammer",			group=1,									},
	}

-- the base part names of an avatar
	avatar.part_names={
		"hat",
		"hair",
		"head",
		"eye",
		"eyeball",
		"eyebrow",
		"eyewear",
		"ear",
		"nose",
		"mouth",
		"beard",
		"body",
		"hand",
		"tail",
		"foot",
		"item",
	}

-- the base part names of an avatar and current number of dropdowns for each
	avatar.part_counts={
		hat=1,
		hair=3,
		head=1,
		eye=1,
		eyeball=1,
		eyebrow=1,
		eyewear=1,
		ear=1,
		nose=1,
		mouth=1,
		beard=1,
		body=2,
		hand=1,
		tail=1,
		foot=1,
		item=1,
	}

-- the material names of an avatar in texture order
	avatar.material_names={
		"black",
		"skin",
		"lips",
		"hair",
		"iris",
		"eye",
		"red",
		"orange",
		"yellow",
		"green",
		"blue",
		"cyan",
		"pink",
		"brown",
		"grey",
		"white",
	}
-- the tweak part names of an avatar
	avatar.tweak_names={
		"hat",
		"hair",
		"head",
		"eyebrow",
		"eye",
		"ear",
		"nose",
		"cheek",
		"mouth",
		"body",
		"boob",
		"hand",
		"tail",
		"foot",
	}

-- the animation names
	avatar.pose_names={
		"breath",
		"walk",
		"relax",
		"fist",
		"reset",
	}

	avatar.soul={
		tweaks={
		},
		parts={
			["hair"]=		{"hair_base"},
			["head"]=		{"head_base"},
			["body"]=		{"body_belly"},
			["hand"]=		{"hand_base"},
			["foot"]=		{"foot_bare"},
			["mouth"]=		{"mouth_base"},
			["nose"]=		{"nose_base"},
			["ear"]=		{"ear_base"},
			["eye"]=		{"eye_base"},
			["eyeball"]=	{"eyeball_base"},
			["eyebrow"]=	{"eyebrow_base"},
		},
		materials={
			["skin"]=	{
							ramp={0x00dd8877,0x80ee9988,0xffffaa99},
						},
			["lips"]=	{
							ramp={0x00cc7777,0x80dd8888,0xffee9999},
						},
			["hair"]=	{
							ramp={0x00773333,0x80884444,0xff995555},
						},
			["eye"]=	{
							ramp={0x00bbbbbb,0x80cccccc,0xffdddddd},
						},
			["iris"]=	{
							ramp={0x00333377,0x80444488,0xff555599},
						},
			["black"]=	{
							ramp={0x00000000,0x80000000,0xff000000},
						},
			["red"]=	{
							ramp={0x00bb3333,0x80cc4444,0xffdd5555},
						},
			["orange"]=	{
							ramp={0x00bb7733,0x80cc8844,0xffdd9955},
						},
			["yellow"]=	{
							ramp={0x00bbbb33,0x80cccc44,0xffdddd55},
						},
			["green"]=	{
							ramp={0x0033bb33,0x8044cc44,0xff55dd55},
						},
			["blue"]=	{
							ramp={0x003333bb,0x804444cc,0xff5555dd},
						},
			["cyan"]=	{
							ramp={0x0033bbbb,0x8044cccc,0xff55dddd},
						},
			["pink"]=	{
							ramp={0x00bb7777,0x80cc8888,0xffdd9999},
						},
			["brown"]=	{
							ramp={0x00773333,0x80884444,0xff995555},
						},
			["grey"]=	{
							ramp={0x00777777,0x80888888,0xff999999},
						},
			["white"]=	{
							ramp={0x00bbbbbb,0x80cccccc,0xffdddddd},
						},
		},
	}

	avatar.filter={}

	avatar.filter.tweaks={}
	
	avatar.filter.materials={}

	avatar.loads=function()
	
--		if not io.open(avatar.filename..".glb","r") then avatar.filename="data/dae/avatar" end -- the gc will close the file...
--		avatar.gs=geom_dae.load({filename=avatar.filename..".dae",mirror=1,filter=avatar.filter})


		local filename="lua/"..(M.modname):gsub("%.","/")..".glsl"
		gl.shader_sources( assert(wzips.readfile(filename),"file not found: "..filename) , filename )

		
		wgeoms_avatar.loads()
	end
			
	avatar.setup=function()

		avatar.mstate={}
		avatar.view_position=V3{0,0,0}
		avatar.view_scale=V3{1,1,1}
		avatar.view_orbit=V3{0,0,0}

		avatar.fbo=framebuffers.create(2048,2048,1)
		avatar.view=views.create({
			mode="fbo",
			fbo=avatar.fbo,
		})
		avatar.fbo:bind_texture()
		gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST)
		gl.TexParameter(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST)

		avatar.fbo_bloom1=framebuffers.create(avatar.fbo.w/8,avatar.fbo.h/8,0)
		avatar.fbo_bloom2=framebuffers.create(avatar.fbo.w/8,avatar.fbo.h/8,0)

	end


	avatar.clean=function()

	end

	avatar.msg=function(m)

	end

	
	avatar.frame=0
	avatar.pose="breath"
	avatar.update=function()
	
--[[
		avatar.pose=gui.datas.get_string("pose") 
		avatar.anim=avatar.gs.anims[avatar.pose]
		avatar.frame=avatar.frame+0.2
		
		if avatar.anim then
			if avatar.frame>=avatar.anim.time_end then avatar.frame=avatar.frame%avatar.anim.time_end end
		end
]]

		avatar.soul.pose=gui.datas.get_string("pose")

		wgeoms_avatar.update(avatar.soul)


--[[
oven.console.display("...")
local windump=function(window)
if window then
	oven.console.display(window.id or "?",window.px,window.py,window.hx,window.hy)
end
end
windump(gui.master.ids.screen)
windump(gui.master.ids.screen.splits)
windump(gui.master.ids.screen.splits and gui.master.ids.screen.splits[1])
windump(gui.master.ids.screen.splits and gui.master.ids.screen.splits[2])
windump(gui.master.ids.window_color)
]]

	end
	
	avatar.msg=function(w,m)

		if m.class=="mouse" then
		
			if m.keyname=="wheel_add" then
				if m.action==-1 then
					local s=avatar.view_scale[1]*1.10
					avatar.view_scale={s,s,s}
				end
			elseif m.keyname=="wheel_sub" then
				if m.action==-1 then
					local s=avatar.view_scale[1]*0.90
					avatar.view_scale={s,s,s}
				end
			elseif m.keyname=="left" then -- click
			
				if m.action==1 then		avatar.mstate={"left",m.x,m.y}
				elseif m.action==-1 then	avatar.mstate={}
				end
				
			elseif m.keyname=="right" then -- click

				if m.action==1 then		avatar.mstate={"right",m.x,m.y}
				elseif m.action==-1 then	avatar.mstate={}
				end

			else

				if m.action==0 then -- drag
					if avatar.mstate[1]=="left" then
						local rs=1/2
						avatar.view_orbit[1]=avatar.view_orbit[1]+(m.x-avatar.mstate[2])*rs
						avatar.view_orbit[2]=avatar.view_orbit[2]+(m.y-avatar.mstate[3])*rs
						
						while avatar.view_orbit[1] >  180 do avatar.view_orbit[1]=avatar.view_orbit[1]-360 end
						while avatar.view_orbit[1] < -180 do avatar.view_orbit[1]=avatar.view_orbit[1]+360 end

						while avatar.view_orbit[2] >  180 do avatar.view_orbit[2]= 180 end
						while avatar.view_orbit[2] < -180 do avatar.view_orbit[2]=-180 end
						
						avatar.mstate[2]=m.x
						avatar.mstate[3]=m.y
					elseif avatar.mstate[1]=="right" then

						avatar.view_position:add( V3{m.x-avatar.mstate[2],m.y-avatar.mstate[3],0 } )
						avatar.mstate[2]=m.x
						avatar.mstate[3]=m.y
					end
				end
			
			end
			
		
		end

	end

	avatar.draw=function()
		avatar.draw_bloom()
	end
	
	
	avatar.draw_base=function()

		gl.state.set({
			[gl.CULL_FACE]					=	gl.FALSE,
			[gl.DEPTH_TEST]					=	gl.TRUE,
		})

		gl.PushMatrix()

		gl.Scale(128,128,128)
		gl.Rotate(-90,1,0,0)
		gl.Rotate(180,0,1,0)

		gl.Translate(avatar.view_position[1]/-50,avatar.view_position[3]/-50,avatar.view_position[2]/-50)
		gl.Scale(avatar.view_scale[1],avatar.view_scale[2],avatar.view_scale[3])
		gl.Rotate( avatar.view_orbit[1] ,  0, 0, -1 )
		gl.Rotate( avatar.view_orbit[2] ,  1, 0, 0 )
	
		wgeoms_avatar.draw()

		gl.PopMatrix()

		gl.state.set({
			[gl.DEPTH_TEST]					=	gl.FALSE,
		})

	end
	
	avatar.draw_bloom=function()
--print(frame)

		gl.PushMatrix()
		avatar.fbo:bind_frame()
		views.push_and_apply(avatar.view)
		gl.state.push(gl.state_defaults)

--		gl.state.set({
--			[gl.CULL_FACE]					=	gl.TRUE,
--			[gl.DEPTH_TEST]					=	gl.TRUE,
--		})
		
		gl.ClearColor(0,0,0,1)
		gl.Clear(gl.COLOR_BUFFER_BIT+gl.DEPTH_BUFFER_BIT)

		gl.Translate(0.5*2048,0.75*2048,0)

		gl.state.set({
			[gl.CULL_FACE]					=	gl.FALSE,
			[gl.DEPTH_TEST]					=	gl.TRUE,
		})

		gl.Scale(128,128,128)
		gl.Rotate(-90,1,0,0)
		gl.Rotate(180,0,1,0)

		gl.PushMatrix()

		gl.Translate(avatar.view_position[1]/-50,avatar.view_position[3]/-50,avatar.view_position[2]/-50)
		gl.Scale(avatar.view_scale[1],avatar.view_scale[2],avatar.view_scale[3])
		gl.Rotate( avatar.view_orbit[1] ,  0, 0, -1 )
		gl.Rotate( avatar.view_orbit[2] ,  1, 0, 0 )
	
		wgeoms_avatar.draw()

		gl.PopMatrix()

		gl.state.pop()
		views.pop_and_apply()
		gl.BindFramebuffer(gl.FRAMEBUFFER, 0)
		gl.PopMatrix()

		gl.state.set({
			[gl.CULL_FACE]					=	gl.FALSE,
			[gl.DEPTH_TEST]					=	gl.FALSE,
			[gl.DEPTH_WRITEMASK]			=	gl.FALSE,
		})

		local v1=gl.apply_modelview( {	-512,	512,		0,1} )
		local v2=gl.apply_modelview( {	-512,	-512,		0,1} )
		local v3=gl.apply_modelview( {	512,	512,		0,1} )
		local v4=gl.apply_modelview( {	512,	-512,		0,1} )
		local t={
			v1[1],	v1[2],	v1[3],	0,				0, 			
			v2[1],	v2[2],	v2[3],	0,				avatar.fbo.uvh,
			v3[1],	v3[2],	v3[3],	avatar.fbo.uvw,	0, 			
			v4[1],	v4[2],	v4[3],	avatar.fbo.uvw,	avatar.fbo.uvh,
		}

		flat.tristrip("rawuv",t,"raw_tex",function(p)
			avatar.fbo:bind_texture()
		end)

		
--		local g=avatar.fbo:download()
--		g:save("test.png")

		local v=gui.datas.get_value("bloom_pick")
		avatar.fbo:mipmap()
		framebuffers.pingpong( avatar.fbo , avatar.fbo_bloom1 , "avatar_bloom_pick" , function(p)
			gl.Uniform4f( p:uniform("bloom_pick"), v,0,0,0 )
		end)

		framebuffers.pingpong( avatar.fbo_bloom1 , avatar.fbo_bloom2 , "avatar_bloom_blur" , function(p)
			gl.Uniform4f( p:uniform("pix_siz"), avatar.fbo_bloom1.uvw/avatar.fbo_bloom1.w/1,0,0,1 )
		end)

		framebuffers.pingpong( avatar.fbo_bloom2 , avatar.fbo_bloom1 , "avatar_bloom_blur" , function(p)
			gl.Uniform4f( p:uniform("pix_siz"), 0,avatar.fbo_bloom1.uvh/avatar.fbo_bloom1.h/1,0,1 )
		end)

--		gl.Translate(64,0,0)
		local v1=gl.apply_modelview( {	-512,	512,		0,1} )
		local v2=gl.apply_modelview( {	-512,	-512,		0,1} )
		local v3=gl.apply_modelview( {	512,	512,		0,1} )
		local v4=gl.apply_modelview( {	512,	-512,		0,1} )
		local t={
			v1[1],	v1[2],	v1[3],	0,				0, 			
			v2[1],	v2[2],	v2[3],	0,				avatar.fbo.uvh,
			v3[1],	v3[2],	v3[3],	avatar.fbo.uvw,	0, 			
			v4[1],	v4[2],	v4[3],	avatar.fbo.uvw,	avatar.fbo.uvh,
		}
		
--[[
		gl.state.push({
			[gl.BLEND_EQUATION_RGB]					=	gl.MAX,
			[gl.BLEND_EQUATION_ALPHA]				=	gl.MAX,
		})
]]
		local v=gui.datas.get_value("bloom_add")
		gl.Color(v,v,v,0)
		flat.tristrip("rawuv",t,"avatar_bloom_add",function(p)
			avatar.fbo_bloom1:bind_texture()
		end)
		gl.Color(1,1,1,1)
--		gl.state.pop()


	end


	avatar.rebuild=function(name)
	
		wgeoms_avatar.rebuild(avatar.soul,name)

	end

	avatar.random=function(opts)
	
		local rnd=function(a,b)
			local r=math.random()
			return a + ((b-a)*r)
		end
	
		local soul={}
		
		soul.tweaks={}
		soul.parts={}
		soul.materials={}

		for i,name in ipairs( avatar.part_names ) do
		
			local chance=1.0
			if name=="hat" or name=="eyewear" or name=="beard" or name=="tail" or name=="item" then
				chance=0.1
			end
			
			local r=math.random()

--print( name, r , chance , r < chance )

			if r < chance then -- object
			
				local poss={}
				
				for _,v in ipairs( avatar.mesh_names ) do
				
					local s=v[1]
					if s:sub(1,#name)==name then
						if v.group==1 then
							poss[#poss+1]=v[1]
						end
					end
				end
				
				if #poss>0 then
					local i=math.random(1,#poss)
					soul.parts[name]={poss[i]}
				else
					soul.parts[name]={}
				end

			else
				soul.parts[name]={}
			end

		end

		local cmap={
			0x11000000,
			0x11ee9988,
			0x11dd8888,
			0x11884444,
			0x11444488,
			0x11cccccc,
			0x11cc4444,
			0x11cc8844,
			0x11cccc44,
			0x1144cc44,
			0x114444cc,
			0x1144cccc,
			0x11cc8888,
			0x11884444,
			0x11888888,
			0x11cccccc,
		}
		for i,name in ipairs( avatar.material_names ) do
		
			local r,g,b,a=pack.argb8_b4(cmap[i])
						
			r=r+rnd(-64,64)
			g=g+rnd(-64,64)
			b=b+rnd(-64,64)
			a=a+rnd(-16,64)
			
			local ramp=avatar.simp_to_ramp(r,g,b,a)

			soul.materials[name]={ ramp=ramp }
		
		end
		
		for i,name in ipairs( avatar.tweak_names ) do
			local tweak={}
			soul.tweaks[name]=tweak
			tweak.scale={}
			tweak.scale[1]    =rnd(0.95,1.05)
			tweak.scale[2]    =rnd(0.95,1.05)
			tweak.scale[3]    =rnd(0.95,1.05)
			tweak.rotate={}
			tweak.rotate[1]   =rnd(-3,3)
			tweak.rotate[2]   =rnd(-3,3)
			tweak.rotate[3]   =rnd(-3,3)
			tweak.translate={}
			tweak.translate[1]=rnd(-0.003,0.003)
			tweak.translate[2]=rnd(-0.003,0.003)
			tweak.translate[3]=rnd(-0.003,0.003)

			if name=="eye" or name=="ear" or name=="mouth" or name=="cheek" or name=="boob" then
				local r=rnd(0.75,1.25)
				tweak.scale[1]    =r*tweak.scale[1]
				tweak.scale[2]    =r*tweak.scale[2]
				tweak.scale[3]    =r*tweak.scale[3]
			end

		end

		avatar.soul=soul
		gui.data_load("all")
	end


	avatar.load=function(filename)

		local fp=io.open(filename,"r")

		if not fp then
			gui.show_request({
				lines={
					"Could not open file",
					filename,
				},
				ok=function()end,
			})
		else
		
			local s=fp:read("*all")
			fp:close()
			
			local tab=wjson.decode(s)
--[[
			avatar.soul={}

			for n1,v1 in pairs(tab) do
				for n2,v2 in pairs(v1) do
					avatar.soul[n1]=avatar.soul[n1] or {}
					avatar.soul[n1][n2]=v2
				end
			end
]]
			avatar.soul=tab
			
			if avatar.soul.parts then
				for n,v in pairs(avatar.soul.parts) do
					if type(v)=="string" then -- promote to table
						avatar.soul.parts[n]={v}
					end
				end
				local hair={}
				if not avatar.soul.parts.hair then
					if avatar.soul.parts.hair1 then hair[#hair+1]=avatar.soul.parts.hair1 end
					if avatar.soul.parts.hair2 then hair[#hair+1]=avatar.soul.parts.hair2 end
					if avatar.soul.parts.hair3 then hair[#hair+1]=avatar.soul.parts.hair3 end
					avatar.soul.parts.hair=hair
				end
			end
			
			gui.data_load("all")

		end
	end

	avatar.save=function(filename,overwrite)
	
		if not overwrite then
		
			local fp=io.open(filename,"r")
			if fp then
				fp:close()

				gui.show_request({
					lines={
						"File already exists",
						filename,
						"Overwrite?",
					},
					yes=function() avatar.save(filename,true) end,
					no=function()end,
				})
				
			else
				overwrite=true
			end

				
		
		end

		if overwrite then -- do save

			local fp=io.open(filename,"w")
			if not fp then
				gui.show_request({
					lines={
						"Could not open file",
						filename,
					},
					ok=function()end,
				})
			else
				if not fp:write(wjson.encode(avatar.soul,{pretty="\t"})) then
					gui.show_request({
						lines={
							"Could not write to file",
							filename,
						},
						ok=function()end,
					})
				end
				fp:close()
				
				wgeoms_avatar.map:save(filename..".png")
			end
		
		end

	end
	
	
	avatar.simp_to_ramp=function(cr,cg,cb,ca)
		
		if cr<0   then cr=0   end
		if cr>255 then cr=255 end
		if cg<0   then cg=0   end
		if cg>255 then cg=255 end
		if cb<0   then cb=0   end
		if cb>255 then cb=255 end
		if ca<0   then ca=0   end
		if ca>255 then ca=255 end

		local crl=cr-ca
		local cgl=cg-ca
		local cbl=cb-ca
		
		if crl<0   then crl=0   end
		if crl>255 then crl=255 end
		if cgl<0   then cgl=0   end
		if cgl>255 then cgl=255 end
		if cbl<0   then cbl=0   end
		if cbl>255 then cbl=255 end
		
		local crh=cr+ca
		local cgh=cg+ca
		local cbh=cb+ca
		
		if crh<0   then crh=0   end
		if crh>255 then crh=255 end
		if cgh<0   then cgh=0   end
		if cgh>255 then cgh=255 end
		if cbh<0   then cbh=0   end
		if cbh>255 then cbh=255 end
		
		local ramp={}
		ramp[1]=pack.b4_argb8(crl,cgl,cbl,0x00)
		ramp[2]=pack.b4_argb8(cr,cg,cb,0x80)
		ramp[3]=pack.b4_argb8(crh,cgh,cbh,0xff)

		return ramp
	end


	avatar.ramp_to_simp=function(ramp)

		local crl,cgl,cbl,cal=pack.argb8_b4( ramp[1] or 0x00000000 )
		local cr,cg,cb,ca=pack.argb8_b4( ramp[2] or 0x00000000 )
		local crh,cgh,cbh,cah=pack.argb8_b4( ramp[3] or 0x00000000 )

		ca=0

		if cr-crl > ca then ca=cr-crl end
		if cg-cgl > ca then ca=cg-cgl end
		if cb-cbl > ca then ca=cb-cbl end

		if crh-cr > ca then ca=crh-cr end
		if cgh-cg > ca then ca=cgh-cg end
		if cbh-cb > ca then ca=cbh-cb end

		return cr,cg,cb,ca
	end

	avatar.ramp_is_simp=function(ramp)
	
		if #ramp ~= 3 then return false end
	
		local cr,cg,cb,ca = avatar.ramp_to_simp(ramp)
		
		local temp = avatar.simp_to_ramp(cr,cg,cb,ca)
		
		if temp[1] ~= ramp[1] then return false end
		if temp[2] ~= ramp[2] then return false end
		if temp[3] ~= ramp[3] then return false end
		
		return true
	end

	return avatar
end

