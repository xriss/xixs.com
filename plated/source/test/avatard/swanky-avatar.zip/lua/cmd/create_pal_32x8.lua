
require("apps").default_paths() -- default search paths so things can easily be found

local wgrd=require("wetgenes.grd")



local g=wgrd.create(wgrd.FMT_U8_INDEXED,32,8,1)


for i=0,255 do

	local y=i%8
	local x=math.floor(i/8)

	g:pixels(x,y,1,1,{i})
	g:palette(i,1,{i,i,i,255})

end

g:save("art/presets/Grey256.pal.png")

