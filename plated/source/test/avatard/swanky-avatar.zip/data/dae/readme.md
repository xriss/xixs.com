
need to export animations from blender using

https://github.com/artellblender/collada-exporter-2.8

