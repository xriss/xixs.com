
	ENDESGA-16.pal.png
	ENDESGA-32.pal.png

The ENDESGA 16 and ~32 color palettes.

	EDG16 or ENDEAGS16
	EDG32 or ENDESGA~32


Included here with kind permission from https://twitter.com/ENDESGA

Checkout their game at -> https://twitter.com/NYKRA

